package Tests;

import FrameWork.helpers.DriverHelper;
import FrameWork.helpers.Helper;
import FrameWork.helpers.ReportHelper;
import Tests.testSteps.st_UBS;
import org.testng.ITestContext;
import org.testng.annotations.*;

import java.lang.reflect.Method;

public class UBS extends DriverHelper {

	@BeforeClass()
	public void LoadDataTestCase() throws Exception {
		Helper.GetDatasource();
		ReportHelper.getgenarateLogTestStart();
	}


	/*@Parameters({"browser", "dataBinder"})
	@Test( description= "Fund Transfer Validation", enabled = true)
	public void fundTransfer_Validate(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
		st_UBS.fundTransfer_Validate();
	}

	@Parameters({"browser", "dataBinder"})
	@Test(description = "Own Fund Transfer And Transfer Within GIB Validation", priority = 1, enabled = true, description = "Fund Transfer Validation")
	public void FT_OwnAndTransferWithinGIB_Validate(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
		st_UBS.FT_OwnAndTransferWithinGIB_Validate();
	}

	@Parameters({"browser", "dataBinder"})
	@Test(testName = "International Fund Transfer Validation", priority = 1, enabled = true, description = "Fund Transfer Validation")
	public void FT_InternationalTransfer_Validate(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
		st_UBS.FT_InternationalTransfer_Validate();
	}*/

/*	@Parameters({"browser", "dataBinder"})
	@Test(testName = "Fund Transfer Validation", priority = 1, enabled = true, description = "Fund Transfer Validation")
	public void International_Transfer(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
		st_UBS.internationalTransfer();
	}

	@Parameters({"browser", "dataBinder"})
	@Test(testName = "Fund Transfer Validation", priority = 1, enabled = true, description = "Fund Transfer Validation")
	public void DomesticTransfer(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
		st_UBS.DomesticTransfer();
	}*/

	@AfterClass
	public void close() throws Exception {
		closeReportAndDriver();
	}

}
