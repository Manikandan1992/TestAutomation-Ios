package Tests;

import FrameWork.helpers.DriverHelper;
import FrameWork.helpers.Helper;
import FrameWork.helpers.ReportHelper;
import Tests.testSteps.st_GTX;
import Tests.testSteps.st_UBS;
import org.testng.ITestContext;
import org.testng.annotations.*;

import java.lang.reflect.Method;

public class GTX extends DriverHelper {

	@BeforeClass()
	public void LoadDataTestCase() throws Exception {
		Helper.GetDatasource();
		ReportHelper.getgenarateLogTestStart();
	}


	@Parameters({"browser", "dataBinder"})
	//@Test(testName = "GTX TRN Status validate", priority = 1, enabled = true, description = "GTX TRN Status validate")
	public void TRN_Status_validate(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {

		st_GTX.GTX_TRN_Status_Validate();
	}


	@AfterClass
	public void close() throws Exception {
		closeReportAndDriver();
	}

}


