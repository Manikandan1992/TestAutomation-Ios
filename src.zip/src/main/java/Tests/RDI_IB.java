package Tests;

import FrameWork.helpers.DriverHelper;
import FrameWork.helpers.Helper;
import FrameWork.helpers.ReportHelper;
import Tests.testSteps.st_RDIIB;
import org.testng.ITestContext;
import org.testng.annotations.*;
import java.lang.reflect.Method;

public class RDI_IB extends DriverHelper {

    @BeforeClass()
    public void LoadDataTestCase() throws Exception {
        //Helper.getDataResultSet();
        Helper.GetDatasource();
        ReportHelper.getgenarateLogTestStart();
    }

    @AfterClass
    public void close() throws Exception {
        DriverHelper.closeReportAndDriver();
    }

}
