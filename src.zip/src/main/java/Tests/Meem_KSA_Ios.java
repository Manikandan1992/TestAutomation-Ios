package Tests;

import POM.functions.*;
import org.testng.ITestContext;
import org.testng.annotations.*;

import java.lang.reflect.Method;

import FrameWork.helpers.DriverHelper;
import FrameWork.helpers.Helper;
import FrameWork.helpers.ReportHelper;
import org.testng.annotations.Test;

import static POM.functions.BeneficiaryPage.InternationalBenDeletion;
import static POM.functions.FundTransfer.emergencyCash;
import static POM.functions.MeemBahrainFundTransfer_Ios.*;
import static POM.functions.MeemKSA_BillPayment.multipleOnlineandOffilePayments;
import static POM.functions.MeemKSA_Profile.limitUpdate;
import static POM.functions.TalkToMeem.deleteComplaint;

public class Meem_KSA_Ios extends DriverHelper {

    @BeforeClass()
    public void LoadDataTestCase() throws Exception {
        //Helper.getDataResultSet();
        Helper.getDataResultSet();
        ReportHelper.getgenarateLogTestStart();
    }


    @Parameters({"browser", "dataBinder"})
    @Test(description = "MeemkSA_login", enabled = true)
    public void LoginValidation(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemKSALogin_Ios.MeemKSA_iosLoginValidation();
    }


    @Parameters({"browser", "dataBinder"})
    @Test(description = "MeemBahrain_login", enabled = true)
    public void InvalidLogin(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemKSALogin_Ios.invalidLogin();
    }


    @Parameters({"browser", "dataBinder"})
    @Test(description = "MeemBahrain_login", enabled = true)
    public void MeemBahrain_OWN_ACC_Transfer(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemBahrainFundTransfer_Ios.WithinOwnAccountsTransfer();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "MeemBahrain_login", enabled = true)
    public void MeemBahrain_WithinMeemTransfer(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemBahrainFundTransfer_Ios.WithinMeemTransfer();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "MeemBahrain_login", enabled = true)
    public void MeemKSA_DFT(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemBahrainFundTransfer_Ios.WithinKSA();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "MeemBahrain_login", enabled = true)
    public void MeemKSA_DFT_BeneficaryRegistration(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        BeneficiaryPage.addBeneficiary_Domestic();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "MeemBahrain_login", enabled = true)
    public void MeemKSA_WithinMeem_BeneficaryRegistration(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        BeneficiaryPage.addBeneficiary_WithinMeem();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "MeemBahrain_login", enabled = true)
    public void MeemKSA_WithinMeem_BeneficaryDeletion(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        BeneficiaryPage.WithinMeemBenDeletion();
    }


    @Parameters({"browser", "dataBinder"})
    @Test(description = "MeemBahrain_login", enabled = true)
    public void MeemKSA_IFT(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemBahrainFundTransfer_Ios.International_fundTransfer();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "MeemKSA_IFT_FCY", enabled = true)
    public void MeemKSA_IFT_FCY(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemBahrainFundTransfer_Ios.International_fundTransfer_FCY();
    }


    @Parameters({"browser", "dataBinder"})
    @Test(description = "MeemBahrain_login", enabled = true)
    public void MeemKSA_DFT_Deletion(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        BeneficiaryPage.domestic_benDeletion();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "MeemBahrain_login", enabled = true)
    public void MeemBahrain_INT_BeneficaryRegistration(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        BeneficiaryPage.addBeneficiary();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "MeemBahrain_login", enabled = true)
    public void MeemBahrain_profileUpdate(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemKSA_Profile.profileUpdate();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "MeemBahrain_login", enabled = true)
    public void StandingInstruction_Own_Account(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemBahrain_StandingInstruction.StandingInstruction();
    }



    @Parameters({"browser", "dataBinder"})
    @Test(description = "MeemBahrain_login", enabled = true)
    public void StandingInstruction_WithinMeem(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemBahrain_StandingInstruction.StandingInstruction();

    }


    @Parameters({"browser", "dataBinder"})
    @Test(description = "MeemBahrain_login", enabled = true)
    public void StandingInstruction_Within_KSA(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemBahrain_StandingInstruction.StandingInstruction();
    }


    @Parameters({"browser", "dataBinder"})
    @Test(description = "MeemBahrain_login", enabled = true)
    public void StandingInstruction_International(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemBahrain_StandingInstruction.StandingInstruction();
    }



    @Parameters({"browser", "dataBinder"})
    @Test(description = "Bill Payment", enabled = true)
    public void AddSADADBiller(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemKSA_BillPayment.addOnline_billPayment();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "Bill Payment", enabled = true)
    public void AddOffline_Biller(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemKSA_BillPayment.addOffline_billPayment();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "Bill Payment", enabled = true)
    public void SingleOnline_Payment(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
       MeemKSA_BillPayment.singleOnlinepayment();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "Bill Payment", enabled = true)
    public void SingleOffline_Payment(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemKSA_BillPayment.singleOffLinepayment();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "Bill Payment", enabled = true)
    public void MultipleOnline_Payment(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        //MeemKSA_BillPayment.bil
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "Bill Payment", enabled = true)
    public void DeleteBiller(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemKSA_BillPayment.deleteBiller();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "Bill Payment", enabled = true)
    public void InvalidOTP(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemKSALogin_Ios.InValidOTP();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "Bill Payment", enabled = true)
    public void FavoriteTransfer(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
            FundTransfer.FavoriteTransfer();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "Bill Payment", enabled = true)
    public void InitiateFavoriteTransfer(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        FundTransfer.initiatefavoriteTransfer();
    }


    @Parameters({"browser", "dataBinder"})
    @Test(description = "Bill Payment", enabled = true)
    public void DeleteFavoriteTransfer(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        FundTransfer.deleteFavoriteTransfer();
    }


    @Parameters({"browser", "dataBinder"})
    @Test(description = "TalkToMeem", enabled = true)
    public void NewComplaint(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        TalkToMeem.newComplaint();
    }


    @Parameters({"browser", "dataBinder"})
    @Test(description = "TalkToMeem", enabled = true)
    public void NewEnquiry(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        TalkToMeem.newEnquiry();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "BillPayment_StandingInstructions", enabled = true)
    public void BillPayment_StandingInstructions(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemKSA_BillPayment.billPayment_StandingInstructions();
    }


    @Parameters({"browser", "dataBinder"})
    @Test(description = "TalkToMeem", enabled = true)
    public void DeleteMail(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        TalkToMeem.deleteMail();
    }


    @Parameters({"browser", "dataBinder"})
    @Test(description = "Profile_PasswordUpdate", enabled = true)
    public void Passwordupdate(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemKSA_Profile.updatePassword();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "Profile_PasswordUpdate", enabled = true)
    public void PasswordUpdateAsOld(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemKSA_Profile.updatePasswordAsOld();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "Profile_PasswordUpdate", enabled = true)
    public void AccountSummaryView(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        AccountSummaryView.accountSummary();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "Profile_PasswordUpdate", enabled = true)
    public void AccountSummaryView_FCY(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        AccountSummaryView.accountSummary_FCY();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "Profile_PasswordUpdate", enabled = true)
    public void InvalidBeneficaryCreation(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        BeneficiaryPage.invalidBeneficary();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "Profile_PasswordUpdate", enabled = true)
    public void FawariTransfer_Insufficient(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemBahrainFundTransfer_Ios.WithinBahrainFawariInvalidBal();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "International Transfer", enabled = true)
    public void InternationalTransfer_Insufficient(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemBahrainFundTransfer_Ios.InternationalInsufficientBalance();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "With Own Transfer", enabled = true)
    public void OwnTransfer_Insufficient(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemBahrainFundTransfer_Ios.WithinOwnAccountsInsufficientBalance();
    }


    @Parameters({"browser", "dataBinder"})
    @Test(description = "Foreign Account Craetion", enabled = true)
    public void FCYAccountCreation(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        AccountSummaryView.FCYCreation();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "Foreign Account Craetion", enabled = true)
    public void FCYAccountClosure(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        AccountSummaryView.FCYClosure();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "Foreign Account Craetion", enabled = true)
    public void FawariPlusTransfer(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        FundTransfer.fawariPlusTransfer();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "Foreign Account Craetion", enabled = true)
    public void InternationalFCY_FCY(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        International_fundTransfer_FCY();
    }


    @Parameters({"browser", "dataBinder"})
    @Test(description = "Foreign Account Craetion", enabled = true)
    public void WithinMeemFCY_BHD(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        WithinMeemTransferFCY_BHD();
    }


    @Parameters({"browser", "dataBinder"})
    @Test(description = "Foreign Account Craetion", enabled = true)
    public void OwnAccountTransferFCY_OnePAck(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        WithinOwnAccountsTransferFCYTOOnepAck();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "Foreign Account Craetion", enabled = true)
    public void OwnAccountTransferFCY_FCY(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        WithinOwnAccountsTransferFCYFCY();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "Foreign Account Craetion", enabled = true)
    public void IFT_BenDeletion(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        InternationalBenDeletion();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "Foreign Account Creation", enabled = true)
    public void MultipleOnlineAndOfflinePayments(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        multipleOnlineandOffilePayments();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "Foreign Account Craetion", enabled = true)
    public void DeleteComplaint(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        deleteComplaint();
    }


    @Parameters({"browser", "dataBinder"})
    @Test(description = "InitiateEmergencyCash", enabled = true)
    public void InitiateEmergencyCash(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        emergencyCash();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "Limitupdate", enabled = true)
    public void Limitupdate(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        limitUpdate();

    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "TDInSARCreation", enabled = true)
    public void TDInSARCreation(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        TermDeposit.termDepositinSARCreation();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "TDInSARCreation", enabled = true)
    public void pwdChangeWithUserName(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        MeemKSA_Profile.pwdChangeWithUserName();
    }

    @Parameters({"browser", "dataBinder"})
    @Test(description = "JAMJAR_Creation", enabled = true)
    public void JamJarCreation(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
      JamJars.jamJarCreation();
    }


    @Parameters({"browser", "dataBinder"})
    @Test(description = "JAMJAR_Creation", enabled = true)
    public void TD_ERFUND(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
        TermDeposit.termDepositERFund();
    }




    @Parameters({"browser", "dataBinder"})
    @Test(description = "Forgot_Password", enabled = true)
    public void ForgotPassword(String browser, String dataBinder, @Optional Method method, @Optional ITestContext iTestContext) throws Throwable {
      MeemKSALogin_Ios.ForgotPassword();
    }






    @AfterClass
    public void close() throws Exception {
        closeReportAndDriver();
    }



/*@AfterSuite
    public void logout(){
		//st_GTBeCorp.all_Logout_GTBeCrop();
		DriverHelper.closeReportAndDriver();
	}*/


}
