package Tests.testSteps;
import FrameWork.helpers.DriverHelper;
import POM.functions.fn_RDI_IB;
import POM.functions.fn_UBS;
import POM.functions.fn_allLogin;

import static FrameWork.library.Util.openUrl;
import static FrameWork.listeners.PreReq.getURL;

public class st_RDIIB {

    public static void Login_FirstAndSecondFA() throws Exception {
        /************Valid Login******/
        DriverHelper.environmentURL="MKR1~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_allLogin.logout_RDI();
        /***********Invalid Login*****/
        DriverHelper.environmentURL="INVMKR1~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
    }

    public static void OTPSMSToMobile() throws Exception {
        DriverHelper.environmentURL="MKR1~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_allLogin.logout_RDI();
    }

    public static void Prof_SecSettng_PwdChnge() throws Exception {
        DriverHelper.environmentURL="MKR1~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.SecSettng_PasswordChnge();
        fn_allLogin.logout_RDI();
    }

    public static void FCYAcct_MoveMoneyfromOnePackToFCY() throws Exception {
        DriverHelper.environmentURL="MKR1~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.FCYAcct_MoveMoneyFromOnePacktoFCY();
        fn_allLogin.logout_RDI();

    }

    public static void FCYAcct_Creation() throws Exception {
        DriverHelper.environmentURL="MKR1~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.FCY_Create();
        fn_allLogin.logout_RDI();

    }

    public static void Bill_Creation() throws Exception {
        DriverHelper.environmentURL="MKR1~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.Bill_Create();
        fn_allLogin.logout_RDI();

    }

    public static void Bill_Deletion() throws Exception {
        DriverHelper.environmentURL="MKR1~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.Bill_Delete();
        fn_allLogin.logout_RDI();

    }

    public static void Beneficiary_Deletion() throws Exception {
        DriverHelper.environmentURL="MKR1~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.Beneficiary_Delete();
        fn_allLogin.logout_RDI();

    }

    public static void OnePackAcctSummary() throws Exception {
        DriverHelper.environmentURL="MKR1~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.OnePack_AccountSumm();
        fn_allLogin.logout_RDI();

        /*****************UBS Login*****************/
        DriverHelper.environmentURL="MKR3~UBS_KSA~T2";
        st_UBS.all_Login_UBS();
        fn_UBS.UBS_SwitchBranch();
        fn_UBS.FastPath();
        fn_UBS.SearchAccNo_RetailIB();
        fn_UBS.SearchAcctSummary_RetailIB();
        fn_allLogin.logout_UBS();

    }

    public static void FCYAcct_MoveMoneyfromFCYToOnePack() throws Exception {
        DriverHelper.environmentURL="MKR1~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.FCYAcct_MoveMoneyFromFCYToOnePack();
        fn_allLogin.logout_RDI();

    }

    public static void FCYAcctSummary() throws Exception {
        DriverHelper.environmentURL="MKR7~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.FCY_AccountSumm();
        fn_allLogin.logout_RDI();

        /*****************UBS Login*****************/
        DriverHelper.environmentURL="MKR1~UBS_KSA~T2";
        st_UBS.all_Login_UBS();
        fn_UBS.UBS_SwitchBranch();
        fn_UBS.FastPath();
        fn_UBS.SearchAccNo_RetailIB();
        fn_UBS.SearchAcctSummary_RetailIB();
        fn_allLogin.logout_UBS();

    }

    public static void FCYAcctClose() throws Exception {
        DriverHelper.environmentURL="MKR1~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.FCYAcct_Close();
        fn_allLogin.logout_RDI();

    }

    public static void Bill_GovtPayment() throws Exception {
        DriverHelper.environmentURL="MKR1~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.Govt_Payment();
        fn_allLogin.logout_RDI();

    }

    public static void Benef_Creation() throws Exception {
        DriverHelper.environmentURL="MKR1~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.Beneficiary_Create();
        fn_allLogin.logout_RDI();

    }

    public static void MFCA_AcctDetails() throws Exception {
        DriverHelper.environmentURL="MKR1~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.CurrenciesCard_AcctDetails();
        fn_allLogin.logout_RDI();

    }

    public static void Prof_CardUpdateLimit() throws Exception {
        DriverHelper.environmentURL="MKR3~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.CardUpdateLimit();
        fn_allLogin.logout_RDI();

    }

    public static void BeneWithinMeem_ValidateLimit() throws Exception {
        DriverHelper.environmentURL="MKR3~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.BeneType_LimitValidation();
        fn_RDI_IB.BeneType_VerifyAcctTransaction();
        fn_allLogin.logout_RDI();

        /*****************UBS Login*****************/
        DriverHelper.environmentURL="MKR1~UBS_KSA~T2";
        st_UBS.all_Login_UBS();
        fn_UBS.UBS_SwitchBranch();
        fn_UBS.FastPath();
        fn_UBS.SearchREFNo_RetailIB();
        fn_UBS.VerifyContractDetails_RetailIB();
        fn_UBS.AccountEntries_BeneWithinMeem();
        fn_UBS.ExitAllActiveWindows2();
        fn_allLogin.logout_UBS();

    }

    public static void BeneWithinKSAandInterntl_SAR_ValidateLimit() throws Exception {
        DriverHelper.environmentURL="MKR3~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.BeneType_LimitValidation();
        fn_RDI_IB.BeneType_VerifyAcctTransaction();
        fn_allLogin.logout_RDI();

        /*****************UBS Login*****************/
        DriverHelper.environmentURL="MKR7~UBS_KSA~T2";
        st_UBS.all_Login_UBS();
        fn_UBS.UBS_SwitchBranch();
        fn_UBS.FastPath();
        fn_UBS.SearchREFNo_RetailIB();
        fn_UBS.VerifyContractDetails_RetailIB();
        fn_UBS.AcctEntries_BeneWithinKSAandInterntl_SAR();
        fn_UBS.ExitAllActiveWindows2();
        fn_allLogin.logout_UBS();

    }

    public static void BeneInterntl_FCY_ValidateLimit() throws Exception {
        DriverHelper.environmentURL="MKR3~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.BeneType_LimitValidation();
        fn_RDI_IB.BeneType_VerifyAcctTransaction();
        fn_allLogin.logout_RDI();

        /*****************UBS Login*****************/
        DriverHelper.environmentURL="MKR7~UBS_KSA~T2";
        st_UBS.all_Login_UBS();
        fn_UBS.UBS_SwitchBranch();
        fn_UBS.FastPath();
        fn_UBS.SearchREFNo_RetailIB();
        fn_UBS.VerifyContractDetails_RetailIB();
        fn_UBS.AcctEntries_BeneInterntl_FCY();
        fn_UBS.ExitAllActiveWindows2();
        fn_allLogin.logout_UBS();

    }

    public static void Budget_GoalCreate() throws Exception {
        DriverHelper.environmentURL="MKR4~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.Goal_Create();
        fn_allLogin.logout_RDI();

    }

    public static void Budget_GoalDelete() throws Exception {
        DriverHelper.environmentURL="MKR4~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.Goal_Delete();
        fn_allLogin.logout_RDI();

    }

    public static void StandingInstructn_SetUp() throws Exception {
        DriverHelper.environmentURL="MKR4~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.SI_SetUp();
        fn_RDI_IB.SI_Verify();
        fn_allLogin.logout_RDI();

    }

    public static void StandingInstructn_Delete() throws Exception {
        DriverHelper.environmentURL="MKR4~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.SI_Delete();
        fn_RDI_IB.SI_Verify();
        fn_allLogin.logout_RDI();

    }

    public static void MFCACreation() throws Exception {
        DriverHelper.environmentURL="MKR4~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.MFCA_Create();
        fn_allLogin.logout_RDI();

    }

    public static void CardResIssuance() throws Exception {
        DriverHelper.environmentURL="MKR8~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.Card_ReIssuance();
        fn_allLogin.logout_RDI();

    }

    public static void RDI_BillPayment_CC() throws Exception {
        DriverHelper.environmentURL="MKR8~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.BillPayment_CreditCard();
        fn_allLogin.logout_RDI();

    }

    public static void CRM_StandingInstructions_Validate() throws Exception {
        DriverHelper.environmentURL="CRM~T2";
        fn_RDI_IB.CRM_Launch();
        fn_RDI_IB.Select_Customer();
        fn_RDI_IB.StandingOrderInstructions_Validate();

    }

    public static void CRM_ContactsInfo_View() throws Exception {
        DriverHelper.environmentURL="CRM~T2";
        fn_RDI_IB.CRM_Launch();
        fn_RDI_IB.Select_Customer();
        fn_RDI_IB.ViewContacts_Info();

    }

    public static void CRM_AccountSync() throws Exception {
        DriverHelper.environmentURL="CRM~T2";
        fn_RDI_IB.CRM_Launch();
        fn_RDI_IB.Select_Customer();
        fn_RDI_IB.CRM_AccountSync();

    }

    public static void CRM_CardSync() throws Exception {
        DriverHelper.environmentURL="CRM~T2";
        fn_RDI_IB.CRM_Launch();
        fn_RDI_IB.Select_Customer();
        fn_RDI_IB.CRM_CardSync();

    }

    public static void CRM_GoalDetails_View() throws Exception {
        DriverHelper.environmentURL="CRM~T2";
        fn_RDI_IB.CRM_Launch();
        fn_RDI_IB.Select_Customer();
        fn_RDI_IB.CRM_GoalDetails_View();

    }

    public static void CRM_EStatement_OnePack() throws Exception {
        DriverHelper.environmentURL="CRM~T2";
        fn_RDI_IB.CRM_Launch();
        fn_RDI_IB.Select_Statement();
        fn_RDI_IB.CRM_EStatement_OnePack();

    }

    public static void CRM_EStatement_CreditCard() throws Exception {
        DriverHelper.environmentURL="CRM~T2";
        fn_RDI_IB.CRM_Launch();
        fn_RDI_IB.Select_Statement();
        fn_RDI_IB.CRM_EStatement_CreditCard();

    }
    public static void BenefCreation_viaCRM() throws Exception {
        DriverHelper.environmentURL="CRM~T2";
        fn_RDI_IB.CRM_Launch();
        fn_RDI_IB.Select_Customer();
        fn_RDI_IB.Select_benefeciaries_Details();
        fn_RDI_IB.Select_benefeciaries_Active();

        //fn_allLogin.logout_RDI();

    }
    public static void BenefCreation_ValidationCRM() throws Exception {
        DriverHelper.environmentURL="CRM~T2";
        fn_RDI_IB.CRM_Launch();
        fn_RDI_IB.Select_Customer();
        fn_RDI_IB.benefeciaries_Validate();

        //fn_allLogin.logout_RDI();

    }


    public static void RDI_Customer_Onboarding() throws Exception{
        DriverHelper.environmentURL="MKR1~RDI_IB~T2";
        fn_RDI_IB.RDI_Launch();
        //fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.RDI_Onboard();
    }
    public static void PF_Online_Onboarding() throws Exception{
        DriverHelper.environmentURL="MKR4~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.PF_Onboarding();

    }
    public static void CreditCard_Onboarding() throws Exception{
        DriverHelper.environmentURL="MKR5~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.CreditCard_creation();

    }
    public static void TermDeposit_Creation() throws Exception {
        DriverHelper.environmentURL="MKR10~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.Select_MenuItem("PRODUCTS");
        fn_RDI_IB.Booking_TermDeposit();
        fn_RDI_IB.IntendedPurchase_TermDeposit();
        fn_RDI_IB.Offer_To_SellCommodities();
        fn_RDI_IB.BankOffer_To_Purchase();
        fn_allLogin.logout_RDI();
    }

    public static void TermDeposit_Cancellation() throws Exception {
        DriverHelper.environmentURL="MKR10~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.Select_TermDeposit();
        fn_RDI_IB.MurabahaDepositDetails();
        fn_RDI_IB.ConfirmMurabahaDepositCancellation();
        fn_allLogin.logout_RDI();
    }

    public static void TermDeposit_EmergencyWithdraw() throws Exception {
        DriverHelper.environmentURL="MKR10~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.Select_TermDeposit();
        fn_RDI_IB.MurabahaEmergencyWithdraw();
        fn_RDI_IB.ConfirmMurabahaDepositEmergencyWithdraw();
        fn_allLogin.logout_RDI();
    }

    public static void EmergencyCash_Initiation() throws Exception {
        DriverHelper.environmentURL="MKR10~RDI_IB~T2";
        fn_RDI_IB.all_Login_RDI();
        fn_RDI_IB.Select_MenuItem("EMERGENCY CASH");
        fn_RDI_IB.EmergencyCashDetails();
        fn_RDI_IB.EmergencyCashPINDetails();
        fn_RDI_IB.EmergencyCashWithdrawalDetails();
        fn_allLogin.logout_RDI();
    }

}
