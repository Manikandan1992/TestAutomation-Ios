package FrameWork.library;

public class Constant {

    public final static String transferMsg="Your transfer was done successfully.";
    public final static String reviewMsg="Please review your selection";
    public final static String  domesticPurpose ="Household";
    public final static String domesticSubPurpose="Rent Payment";
    public final static String termDepositSuccessMSg="Your sale has been successfully done. We are pleased to confirm ";

    public final static String  IntPurpose ="Family";
    public final static String IntSubPurpose="Education";
    public final static String successMsg="";
    public final static String beneSuccessMsg = "You have successfully created a new beneficiary";
    public final static String beneDelMsg = "The beneficiary has been deleted";
    public final static String standInstSuccessMsg = "You have successfully schedule a standing instructions";

    public final static String  jamJarSuccessMsg ="You have successfully created a new Jam Jar";

    public final static String  EMERGENCYCASHREVIEWMSG = "Your PIN will expire in 24h";
    public final static String  EMERGENCYCASHSuccessMSG = "Now you can withdraw your money!";
    public final static String  EMERGENCYFUNDFromTDSuccessMSG = "You retired your emergency withdrawn successfully. It will be";
    public final static String  PWDERRMSG = "Password should not contain username";

    public final static  String billermsg="Your Biller has been successfully added.it is available at biller";
    public final static  String favouriteMsg="Your transfer added to favorite transfers successfully";
    public final static  String deleteMsg="All the bills with this Subscriber ID will be deleted";

    public final static  String authenticationErrorMsg="Sorry the authentication code you entered is incorrect";
    public final static  String  favoriteDelMSG="You have successfully deleted your favorite transfer";
    public final static  String  complaintSucessMSG="Your Complaint has been sent";
    public final static  String  enquirySucessMSG="Your Complaint has been sent";
    public final static  String  updatedPwdMSG="You have updated your new password";
    public final static  String  pwdErrMSG="New Password must be different from Old Password";
    public final static  String  InValidLoginMsg="Please enter a valid Username or password and try again you have";
    public final static  String  InvalidBenErrMSG="The IBAN number you entered is invalid , please check and try ag";
    public final static String FCYMSG="Your New Foreign Currency Account has been created succesfully";
    public final static String FCYClosureMSG="Your account has been successfully closed. We hope to see you ag";
    public final static String beneficaryDeleteMSG="The beneficiary has been deleted";
    public final static String resetPWDSUCESSMSG="You have updated your password correctly!";



}
