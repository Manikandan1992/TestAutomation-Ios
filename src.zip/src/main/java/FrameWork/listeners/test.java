package FrameWork.listeners;

import org.testng.*;

public class test implements ITestListener, ISuiteListener, IExecutionListener, IInvokedMethodListener {
	@Override
	public void onExecutionStart() {

	}

	@Override
	public void onExecutionFinish() {

	}

	@Override
	public void beforeInvocation(IInvokedMethod iInvokedMethod, ITestResult iTestResult) {

	}

	@Override
	public void afterInvocation(IInvokedMethod iInvokedMethod, ITestResult iTestResult) {

	}

	@Override
	public void onStart(ISuite iSuite) {

	}

	@Override
	public void onFinish(ISuite iSuite) {

	}

	@Override
	public void onTestStart(ITestResult iTestResult) {

	}

	@Override
	public void onTestSuccess(ITestResult iTestResult) {

	}

	@Override
	public void onTestFailure(ITestResult iTestResult) {

	}

	@Override
	public void onTestSkipped(ITestResult iTestResult) {

	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult iTestResult) {

	}

	@Override
	public void onStart(ITestContext iTestContext) {

	}

	@Override
	public void onFinish(ITestContext iTestContext) {

	}
}
