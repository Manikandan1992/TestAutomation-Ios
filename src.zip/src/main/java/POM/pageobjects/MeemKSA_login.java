package POM.pageobjects;

import FrameWork.listeners.po_BaseClass;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.iOSFindBy;


public class MeemKSA_login extends po_BaseClass {

    public MeemKSA_login(AppiumDriver<MobileElement> driver) {
        super(driver);
    }


    @iOSFindBy(xpath = "//XCUIElementTypeTextField[@name='txtUsername']")
    public static MobileElement userName;

    @iOSFindBy(xpath = "//XCUIElementTypeButton[@label='Done']")
    public static MobileElement doneBtn;

    @iOSFindBy(xpath = "//XCUIElementTypeSecureTextField[@name='txtPassword']")
    public static MobileElement password;

    @iOSFindBy(xpath = "//XCUIElementTypeButton[@name='btnLogin']")
    public static MobileElement loginBtn;

}
