package POM.functions;

import FrameWork.helpers.ReportHelper;
import FrameWork.library.Constant;
import POM.pageobjects.MeemKSA_login;
import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import static FrameWork.helpers.Helper.getData;
import static FrameWork.helpers.ReportHelper.logReportStatusInBlue;
import static FrameWork.library.Util.*;
import static FrameWork.listeners.po_BaseClass.driver;
import static POM.functions.MeemKSALogin_Ios.*;
import static org.openqa.selenium.support.PageFactory.initElements;

public class AccountSummaryView {

    public static void initPageObjects() {
        try {
            initElements(new AppiumFieldDecorator(driver), MeemKSA_login.class);
            logReportStatusInBlue(LogStatus.INFO, "Method: " + Thread.currentThread().getStackTrace()[2].getMethodName());
            getAppiumDriver();
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to load Page elements");

        }

    }


    public static void accountSummary() {
        try {
            String onePackAccountNo = getData("FromAccount");

            waitForPageToLoad("//XCUIElementTypeTextField[@name='txtUsername']");
            sendkeys("//XCUIElementTypeTextField[@name='txtUsername']", "testuser0429");
            clickDoneBtn();
            sendkeys("//XCUIElementTypeSecureTextField[@name='txtPassword']", "abcd1234");
            clickDoneBtn();
            click("//XCUIElementTypeButton[@name='btnLogin']", "Login");
            Thread.sleep(30000);
            click("//XCUIElementTypeStaticText[@name='lblTotalNumOfAccs']", "total no of Accounts");
            Thread.sleep(3000);
            click("//XCUIElementTypeStaticText[@label='" + onePackAccountNo + "']", onePackAccountNo);
            Thread.sleep(3000);
            String availableBalance = iosGetText("//*[@name='lblAvailableBalance']");
            if (availableBalance.equals(getData("TransferAmount"))) {
                ReportHelper.logReportStatus(LogStatus.PASS, "The Account summary and Available balance has been validated ");
            }


        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to validate  Bahrain Account summary ");

        }


    }

    public static void clickIconbtn() {

        click("//*[@label='R']", "Icon clicked");
    }


    public static void FCYCreation() {
        try {
            waitForPageToLoad("//XCUIElementTypeTextField[@name='txtUsername']");
            sendkeys("//XCUIElementTypeTextField[@name='txtUsername']",getData("UserName"));
            clickDoneBtn();
            sendkeys("//XCUIElementTypeSecureTextField[@name='txtPassword']",getData("Password"));
            clickDoneBtn();
            click("//XCUIElementTypeButton[@name='btnLogin']", "Login");
            waitForPageToLoad("//*[@label='R']");


            String currency = getData("Currency");
            clickIconbtn();
            click("//*[@label='Foreign Currency Account']", "FCY text");
            click("//XCUIElementTypeButton[@label='New Account']", "New Account");
            click("//*[@value='Choose currency']", "Choose currency");
            setValue("//XCUIElementTypePickerWheel", currency);
            clickDoneBtn();
            click("//XCUIElementTypeButton[@label='Monthly']", "Monthly");
            System.out.println(driver.getPageSource());
            click("//XCUIElementTypeImage[@name='imgAcceptTnC']", "Accept");

            clickContinueBtn();
            click("//XCUIElementTypeButton[@label='Confirm']", "Confirm");
            Thread.sleep(4000);

            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblClosureTitle']", Constant.FCYMSG);

            String FCYIBANNo = getText("//XCUIElementTypeStaticText[@name='lblIBAN']");
            ReportHelper.logReportStatus(LogStatus.PASS, "The New Foreign Currency Account num is" + FCYIBANNo);
            ReportHelper.logReportStatus(LogStatus.PASS, "The New Foreign Currency Account num has been created");


        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to create  FCY Account" + e.getMessage());
        }


    }

    public static void accountSummary_FCY() {
        accountSummary();

        try {
            String currency = iosGetText("//*[@name='lblAccName']");

            if (currency.equals(getData("Currency"))) {
                ReportHelper.logReportStatus(LogStatus.PASS, "The foreign currency " + currency + "has been validated ");
            }
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to validate  FCY Account summary " + e.getMessage());

        }

    }

    public static void FCYClosure() {

        try {
            String FromAccount = getData("FromAccount");

            String FCYAccount = getData("ToAccount");
            waitForPageToLoad("//XCUIElementTypeTextField[@name='txtUsername']");
            sendkeys("//XCUIElementTypeTextField[@name='txtUsername']", getData("UserName"));
            clickDoneBtn();
            sendkeys("//XCUIElementTypeSecureTextField[@name='txtPassword']",getData("Password"));
            clickDoneBtn();
            click("//XCUIElementTypeButton[@name='btnLogin']", "Login");
            Thread.sleep(30000);


           // waitForPageToLoad("//*[@name='lblTotalNumOfAccs']");
            click("//XCUIElementTypeStaticText[@label='"+FromAccount+"']", "From Account");
            click("//*[@label='View all accounts']","");

          //System.out.println(driver.getPageSource());
          //  click("//*[@name='lblTotalNumOfAccs']", "total no of Accounts");
            //click("//*[@name='lblTotalNumOfAccs']", "total no of Accounts");
            System.out.println(driver.getPageSource());
            click("//*[contains(@label,'" + FCYAccount + "')]", "");
            clickIconbtn();
            click("//XCUIElementTypeStaticText[@label='Close Account']", "Close Account");
            sendkeys("//*[@value='Closure Reason']", "Card Not in use");
            clickDoneBtn();
            clickContinueBtn();
            clickConfirmBtn();
            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblClosureTitle']", Constant.FCYClosureMSG);
            ReportHelper.logReportStatus(LogStatus.PASS, "The foreign currency account has been closed successfully");
            //clickHomeBtn();
            // clickBurgerMenu();
            // clickLogout();
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to close  FCY Account summary" + e.getMessage());
        }


    }
}
