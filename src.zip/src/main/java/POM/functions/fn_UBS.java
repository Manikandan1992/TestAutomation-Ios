package POM.functions;

import FrameWork.helpers.Helper;
import FrameWork.helpers.ReportHelper;
import FrameWork.helpers.eMailOtpReader;
import FrameWork.listeners.po_BaseClass;
import POM.pageobjects.*;
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.*;

import static FrameWork.helpers.Helper.*;
import static FrameWork.helpers.ReportHelper.logReportStatus;
import static FrameWork.helpers.ReportHelper.logReportStatusInBlue;
import static FrameWork.library.Util.*;
import static FrameWork.library.Util.getLatestDriver;
import static FrameWork.listeners.po_BaseClass.drvr;
import static FrameWork.listeners.po_BaseClass.po_GetDriver;
import static org.openqa.selenium.support.PageFactory.initElements;

import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import sun.util.resources.cldr.hy.CalendarData_hy_AM;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.text.DecimalFormat;
import java.util.List;

public class fn_UBS {

	public static void initPageObjects() throws Exception {
		initElements(drvr, po_UBS.class);
		logReportStatusInBlue(LogStatus.INFO, "Method: " + Thread.currentThread().getStackTrace()[2].getMethodName());
		getLatestDriver();
	}


	// newly added

	public static void ExitAllActiveWindowsall() {

		try {
			WebDriver driver = getLatestDriver();

			List<WebElement> frame2;
			frame2 = driver.findElements(By.cssSelector("#ifr_LaunchWin"));
			for(int i=frame2.size()-1;i>=0;i--)
			{
				driver.switchTo().defaultContent();
				driver.switchTo().frame(frame2.get(i));
				Thread.sleep(3000);
				driver.findElement(By.xpath("//a[@title='Close']")).click();
			}

		} catch (Exception e) {
			logReportStatus(LogStatus.FAIL, "Exit all active windows failed due to '" + e.getMessage() + "'");
		}

	}
	public static void UBS_account() {
		try
		{
			initPageObjects();
			getLatestDriver();
			WebDriver driver3 =getLatestDriver();

			//driver3.switchTo().frame("ifr_LaunchWin");
			driver3.switchTo().frame(driver3.findElement(By.xpath("//iframe[@title='Customer Accounts Summary ']")));
			//driver3.findElement(By.id("//div[@class='DIVText']//input[@id='BLK_CUST_ACCOUNT__BRN']")).sendKeys(getData("BranchCode"));
			driver3.findElement(By.xpath("//div[@class='DIVText']//input[@id='BLK_CUST_ACCOUNT__ACC']")).sendKeys(getData("DebitAccount"));

			WebElement element = driver3.findElement(By.cssSelector("#tblquery_fleft > button:nth-child(3)"));
			JavascriptExecutor executor = (JavascriptExecutor) driver3;
			executor.executeScript("arguments[0].click();", element);
			//driver.findElement(By.xpath("//button[@name='Search']/span/span")).click();
			//driver.findElement(By.xpath("//*[contains(text(),'  Search')]")).click();

			Thread.sleep(5000);
			driver3.findElement(By.cssSelector("#TBL_QryRslts > tbody > tr:nth-child(1) > td:nth-child(3) > a")).click();

			Actions act = new Actions(driver3);
			//act.moveToElement(driver.findElement(By.cssSelector("#TBL_QryRslts > tbody > tr:nth-child(1) > td:nth-child(3) > a"))).doubleClick().build().perform();
			act.moveToElement(driver3.findElement(By.cssSelector("#TBL_QryRslts > tbody > tr:nth-child(1) > td:nth-child(3) > a"))).doubleClick().build().perform();
			driver3.switchTo().defaultContent();
			Thread.sleep(2000);
			driver3.switchTo().frame(po_UBS.Frame2_UBS_Contracts.get(1));
			driver3.findElement(By.xpath("//*[@id='BLK_CUST_ACCOUNT__BTN_AMTDT']")).click();
			waitFor(2000);
			driver3.switchTo().frame(driver3.findElement(By.xpath("//iframe[@title='Amounts And Dates ']")));
			//driver3.switchTo().frame("ifrSubScreen");
			String ubs_availablebalacne=getText(po_UBS.BalanceAvailable);
			System.out.println(ubs_availablebalacne+"//////"+getData("AvailableBalance"));
			if (ubs_availablebalacne.contentEquals(getData("AvailableBalance")))
			{
				logReportStatus(LogStatus.PASS, "Account Summary Data validated with UBS");
				driver3.findElement(By.cssSelector("#BTN_EXIT_IMG")).click();
				driver3.switchTo().defaultContent();

				driver3.switchTo().frame(po_UBS.Frame2_UBS_Contracts.get(1));
				driver3.findElement(By.cssSelector("#BTN_EXIT_IMG")).click();
				driver3.switchTo().defaultContent();

				//driver3.switchTo().frame("ifr_LaunchWin");
				driver3.switchTo().frame(driver3.findElement(By.xpath("//iframe[@title='Customer Accounts Maintenance - Transaction Branch Code ::: 200']")));
				driver3.findElement(By.cssSelector("#BTN_EXIT")).click();
				driver3.switchTo().defaultContent();

			} else {
				logReportStatus(LogStatus.FAIL, "Account Summary data is not matched with UBS Data");
			}

/*			int intDebitAmount=Integer.parseInt(driver3.findElement(By.xpath("//input[@name='DRAMT']")).getAttribute("value"));
			System.out.println(strRefNo+"    "+intDebitAmount);
			System.out.println(getData("UBS_ReferenceNumber")+"    "+getData("PaymentAmount"));
			driver3.switchTo().defaultContent();

			if (strRefNo.equals(getData("UBS_ReferenceNumber")) && (intDebitAmount ==Integer.parseInt(getData("PaymentAmount")))) {
				logReportStatus(LogStatus.PASS, "Transaction has been found in UBS and Payment amount Verified");
			} else {
				logReportStatus(LogStatus.FAIL, "Transaction was not found in UBS and Payment amount not Verified");
			}*/

		} catch(Exception e)
		{
			logReportStatus(LogStatus.FAIL,"Account Sumary UBS valdiation failed: '"+e.getMessage()+"'");
			//e.printStackTrace();
		}
	}

	public static void UBS_account_BAH() {
		try
		{
			initPageObjects();
			getLatestDriver();
			WebDriver driver3 =getLatestDriver();

			//driver3.switchTo().frame("ifr_LaunchWin");
			driver3.switchTo().frame(driver3.findElement(By.xpath("//iframe[@title='Customer Accounts Summary ']")));
			//driver3.findElement(By.id("//div[@class='DIVText']//input[@id='BLK_CUST_ACCOUNT__BRN']")).sendKeys(getData("BranchCode"));
			driver3.findElement(By.xpath("//div[@class='DIVText']//input[@id='BLK_CUST_ACCOUNT__ACC']")).sendKeys(getData("DebitAccount"));

			WebElement element = driver3.findElement(By.cssSelector("#tblquery_fleft > button:nth-child(3)"));
			JavascriptExecutor executor = (JavascriptExecutor) driver3;
			executor.executeScript("arguments[0].click();", element);
			//driver.findElement(By.xpath("//button[@name='Search']/span/span")).click();
			//driver.findElement(By.xpath("//*[contains(text(),'  Search')]")).click();

			Thread.sleep(10000);
			driver3.findElement(By.cssSelector("#TBL_QryRslts > tbody > tr:nth-child(1) > td:nth-child(3) > a")).click();

			Actions act = new Actions(driver3);
			//act.moveToElement(driver.findElement(By.cssSelector("#TBL_QryRslts > tbody > tr:nth-child(1) > td:nth-child(3) > a"))).doubleClick().build().perform();
			act.moveToElement(driver3.findElement(By.cssSelector("#TBL_QryRslts > tbody > tr:nth-child(1) > td:nth-child(3) > a"))).doubleClick().build().perform();
			driver3.switchTo().defaultContent();
			Thread.sleep(5000);
			driver3.switchTo().frame(po_UBS.Frame2_UBS_Contracts.get(1));
			driver3.findElement(By.xpath("//*[@id='BLK_CUST_ACCOUNT__BTN_AMTDT']")).click();
			waitFor(2000);
			driver3.switchTo().frame(driver3.findElement(By.xpath("//iframe[@title='Amounts And Dates ']")));
			//driver3.switchTo().frame("ifrSubScreen");
			String ubs_availablebalacne=getText(po_UBS.BalanceAvailable);
			System.out.println(ubs_availablebalacne+"//////"+getData("AvailableBalance"));
			if (ubs_availablebalacne.contentEquals(getData("AvailableBalance")))
			{
				logReportStatus(LogStatus.PASS, "Account Summary Data validated with UBS");
				driver3.findElement(By.cssSelector("#BTN_EXIT_IMG")).click();
				driver3.switchTo().defaultContent();

				driver3.switchTo().frame(po_UBS.Frame2_UBS_Contracts.get(1));
				driver3.findElement(By.cssSelector("#BTN_EXIT_IMG")).click();
				driver3.switchTo().defaultContent();

				//driver3.switchTo().frame("ifr_LaunchWin");
				driver3.switchTo().frame(driver3.findElement(By.xpath("//iframe[@title='Customer Accounts Maintenance - Transaction Branch Code ::: 301']")));
				driver3.findElement(By.cssSelector("#BTN_EXIT")).click();
				driver3.switchTo().defaultContent();

			} else {
				logReportStatus(LogStatus.FAIL, "Account Summary data is not matched with UBS Data");
			}

/*			int intDebitAmount=Integer.parseInt(driver3.findElement(By.xpath("//input[@name='DRAMT']")).getAttribute("value"));
			System.out.println(strRefNo+"    "+intDebitAmount);
			System.out.println(getData("UBS_ReferenceNumber")+"    "+getData("PaymentAmount"));
			driver3.switchTo().defaultContent();

			if (strRefNo.equals(getData("UBS_ReferenceNumber")) && (intDebitAmount ==Integer.parseInt(getData("PaymentAmount")))) {
				logReportStatus(LogStatus.PASS, "Transaction has been found in UBS and Payment amount Verified");
			} else {
				logReportStatus(LogStatus.FAIL, "Transaction was not found in UBS and Payment amount not Verified");
			}*/

		} catch(Exception e)
		{
			logReportStatus(LogStatus.FAIL,"Account Sumary UBS valdiation failed: '"+e.getMessage()+"'");
			//e.printStackTrace();
		}
	}

	public static void UBS_SwitchBranch() {
		try {
			initPageObjects();
			getLatestDriver();
			WebDriver driver = getLatestDriver();
			driver.switchTo().defaultContent();

			waitFor(2000);
			hover(po_UBS.Image_UBS_BranchIsOnline);
			waitFor(1000);
			click(po_UBS.Select_UBS_SelectBranch);
			waitFor(2000);

			driver.switchTo().frame("ifrSubScreen");
			po_UBS.Input_UBS_BranchCode.clear();
			sendKeys(po_UBS.Input_UBS_BranchCode,getData("BranchCode"));
			ReportHelper.logReportStatus(LogStatus.PASS,"Branch code entered in the Select Branch screen successfully");
			click(po_UBS.Button_UBS_FetchValues);
			waitFor(2000);

			if (elemExist(po_UBS.Table_UBS_SelectBranches)) {
				ReportHelper.logReportStatus(LogStatus.PASS,"Branch code '"+getData("BranchCode")+"' displayed in the record successfully");
				click(po_UBS.Table_UBS_SelectBranches);
				waitFor(2000);
				driver.switchTo().frame("ifr_AlertWin");
				click(po_UBS.Button_UBS_OK);
			} else {
				ReportHelper.logReportStatus(LogStatus.FAIL,"Branch code '"+getData("BranchCode")+"' displayed in the record is not found");
			}

		} catch (Exception e){
			ReportHelper.logReportStatus(LogStatus.FAIL,"Swicth Branch failed due to '"+e.getMessage()+"'");
		}
	}

	public static void FastPath() {

		try {
			initPageObjects();
			getLatestDriver();
			WebDriver driver = getLatestDriver();
			driver.switchTo().defaultContent();

			waitFor(2000);
			sendKeys(po_UBS.Input_UBS_FastPath, getData("FastPath"));
			waitFor(1000);

			click(po_UBS.Button_UBS_FastPathGo);
			waitFor(5000);
			ReportHelper.logReportStatus(LogStatus.PASS,"Fast Path Action Performed'");
		} catch (Exception e) {
			ReportHelper.logReportStatus(LogStatus.FAIL,"Fast Path failed due to '"+e.getMessage()+"'");
		}

	}

	public static void SearchREFNo1() {
		try
		{
			initPageObjects();
			getLatestDriver();
			WebDriver driver3 =getLatestDriver();


			WebElement ContractSwift=driver3.findElement(By.xpath("//iframe[contains(@title,'Contract')]"));
			driver3.switchTo().frame(ContractSwift);

			//driver3.switchTo().frame("ifr_LaunchWin");
			System.out.println(getData("UBS_ReferenceNumber"));
			driver3.findElement(By.xpath("//input[contains(@name,'CONTREFNO')]")).sendKeys(getData("UBS_ReferenceNumber"));
			WebElement element = driver3.findElement(By.cssSelector("#tblquery_fleft > button:nth-child(3)"));
			JavascriptExecutor executor = (JavascriptExecutor) driver3;
			executor.executeScript("arguments[0].click();", element);


			Thread.sleep(2000);
			driver3.findElement(By.cssSelector("#TBL_QryRslts > tbody > tr:nth-child(1) > td:nth-child(3) > a")).click();

			Actions act = new Actions(driver3);
			//act.moveToElement(driver.findElement(By.cssSelector("#TBL_QryRslts > tbody > tr:nth-child(1) > td:nth-child(3) > a"))).doubleClick().build().perform();
			act.moveToElement(driver3.findElement(By.cssSelector("#TBL_QryRslts > tbody > tr:nth-child(1) > td:nth-child(3) > a"))).doubleClick().build().perform();
			driver3.switchTo().defaultContent();
			Thread.sleep(2000);
			driver3.switchTo().frame(po_UBS.Frame2_UBS_Contracts.get(1));
			//switchDFrame(po_UBS.Frame_UBS_Contracts);
			WebElement elem=driver3.findElement(By.cssSelector("#BLK_CONTRACT_DETAILS__CONTREFNO"));
			String strRefNo=driver3.findElement(By.xpath("//*[@id='BLK_CONTRACT_DETAILS__CONTREFNO']")).getAttribute("value");

			Double intDebitAmount=Double.parseDouble(driver3.findElement(By.xpath("//input[@name='DRAMT']")).getAttribute("value"));
			DecimalFormat dformat=new DecimalFormat("0.00");
			String fDebAmt=dformat.format(intDebitAmount);
			System.out.println(strRefNo+"    "+fDebAmt);

			Double intCreditAmount=Double.parseDouble(driver3.findElement(By.xpath("//input[@name='CRAMT']")).getAttribute("value"));
			String fCredAmt=dformat.format(intCreditAmount);
			System.out.println(strRefNo+"    "+fCredAmt);

			//String ChkRefNum =  getData("UBS_ReferenceNumber");
			Double tPayAmt = Double.parseDouble(getData("PaymentAmount"));
			String ChkDebAmt = dformat.format(tPayAmt);

			Double tCredAmt = Double.parseDouble(getData("CreditAmount"));
			String ChkCredAmt = dformat.format(tCredAmt);

			String DRAcct = getText(po_UBS.Input_UBS_DebitAccount);
			String CRAcct = getText(po_UBS.Input_UBS_CreditAccount);
			String DrBrnch = getText(po_UBS.Input_UBS_DebitBranch);
			String CrBrnch = getText(po_UBS.Input_UBS_CreditBranch);

			String IBANNum = getText(po_UBS.Input_UBS_BeneIBANAccount).replace("/","").trim();

			if ( fDebAmt.equals(ChkDebAmt) && DRAcct.equals(getData("DebitAccount"))) {
				ReportHelper.logReportStatus(LogStatus.PASS,"Debit Amount '"+ChkDebAmt+"' of DrAcctNo '"+getData("DebitAccount")+"' verified correctly");
			} else {
				ReportHelper.logReportStatus(LogStatus.FAIL,"Debit Amount '"+ChkDebAmt+"' of DrAcctNo '"+getData("DebitAccount")+"' verified is not correct");
			}

			if (fCredAmt.equals(ChkCredAmt)  && IBANNum.equals(getData("BeneficiaryAccount")) && CRAcct.equals(getData("CreditAccount"))) {
				ReportHelper.logReportStatus(LogStatus.PASS,"Credit Amount '"+ChkCredAmt+"' of CrAcctNo '"+getData("CreditAccount")+"' verified correctly");
			} else {
				ReportHelper.logReportStatus(LogStatus.FAIL,"Credit Amount '"+ChkCredAmt+"' of CrAcctNo '"+getData("CreditAccount")+"' verified is not correct");
			}

			if ( DrBrnch.equals(getData("DebitBranch")) && CrBrnch.equals(getData("CreditBranch"))  ) {
				ReportHelper.logReportStatus(LogStatus.PASS,"Debit Branch '"+DrBrnch+ "' & Credit Branch '"+CrBrnch+ " verified correctly");
			} else {
				ReportHelper.logReportStatus(LogStatus.FAIL,"Debit Branch '"+DrBrnch+ "' & Credit Branch '"+CrBrnch+ " verified is not correct");
			}

			driver3.switchTo().defaultContent();

		} catch(Exception e)
		{
			logReportStatus(LogStatus.FAIL,"Search Transaction Reference Number failed due to '"+e.getMessage()+"'");
			//e.printStackTrace();
		}
	}

	/**********************************************************************************************************************************/
    /*
     * Function Name : OwnFT_SearchREFNo
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

	public static void OwnFT_SearchREFNo() {
		try
		{
			initPageObjects();
			getLatestDriver();
			WebDriver driver3 =getLatestDriver();
			waitFor(7000);
			//driver3.switchTo().frame("ifr_LaunchWin");
			driver3.switchTo().frame(driver3.findElement(By.xpath("//iframe[@title='Retail Teller Transaction Query Summary ']")));

			String UBSRefNo = getData("UBS_ReferenceNumber");
			System.out.println(UBSRefNo);
			if (!UBSRefNo.equalsIgnoreCase("")) {
				driver3.findElement(By.id("DEVWS_RTL_TELLER__FCCREF__FCCREF")).sendKeys(getData("UBS_ReferenceNumber"));
				WebElement element = driver3.findElement(By.cssSelector("#button_row > button:nth-child(2)"));
				JavascriptExecutor executor = (JavascriptExecutor) driver3;
				executor.executeScript("arguments[0].click();", element);
				//driver.findElement(By.xpath("//*[contains(text(),'  Search')]")).click();

				Thread.sleep(2000);
				driver3.findElement(By.cssSelector("#TBL_QryRslts > tbody > tr > td:nth-child(4) > span")).click();

				Actions act = new Actions(driver3);
				//act.moveToElement(driver.findElement(By.cssSelector("#TBL_QryRslts > tbody > tr:nth-child(1) > td:nth-child(3) > a"))).doubleClick().build().perform();
				act.moveToElement(driver3.findElement(By.cssSelector("#TBL_QryRslts > tbody > tr > td:nth-child(4) > span"))).doubleClick().build().perform();
				driver3.switchTo().defaultContent();
				Thread.sleep(2000);
				driver3.switchTo().frame(po_UBS.Frame2_UBS_Contracts.get(1));
				//switchDFrame(po_UBS.Frame_UBS_Contracts);
				WebElement elem = driver3.findElement(By.cssSelector("#RTVWS_TRANSACTION_DETAILS__FCCREF"));
				String strRefNo = driver3.findElement(By.xpath("//*[@id='RTVWS_TRANSACTION_DETAILS__FCCREF']")).getAttribute("value");

				Double intDebitAmount = Double.parseDouble(driver3.findElement(By.xpath("//input[@name='TXNAMT']")).getAttribute("value"));
				DecimalFormat dformat = new DecimalFormat("0.00");
				String fDebAmt = dformat.format(intDebitAmount);
				//System.out.println(strRefNo+"    "+fDebAmt);

				Double intCreditAmount = Double.parseDouble(driver3.findElement(By.xpath("//input[@name='OFFSETAMT']")).getAttribute("value"));
				String fCredAmt = dformat.format(intCreditAmount);
				//System.out.println(strRefNo+"    "+fCredAmt);

				String DRAcct = driver3.findElement(By.xpath("//input[@name='TXNACC']")).getAttribute("value");
				String CRAcct = driver3.findElement(By.xpath("//input[@name='OFFSETACC']")).getAttribute("value");
				String DrBrnch = driver3.findElement(By.xpath("//input[@name='TXNBRN']")).getAttribute("value");
				String CrBrnch = driver3.findElement(By.xpath("//input[@name='OFFSETBRN']")).getAttribute("value");

				String ChkRefNum = getData("UBS_ReferenceNumber");
				Double tPayAmt = 0.0, tCredAmt = 0.0;
				if (getData("TransferType").equalsIgnoreCase("Own")) {
					tPayAmt = Double.parseDouble(getData("PaymentAmount"));
					tCredAmt = Double.parseDouble(getData("CreditAmount"));
				} else if (getData("TransferType").equalsIgnoreCase("Transfer within GIB")) {
					tCredAmt = Double.parseDouble(getData("PaymentAmount"));
					tPayAmt = Double.parseDouble(getData("PaymentAmount"));
				}

				String ChkPayAmt = dformat.format(tPayAmt);
				String ChkCredAmt = dformat.format(tCredAmt);

				//System.out.println(ChkRefNum+"    "+ChkPayAmt);
				driver3.switchTo().defaultContent();

				if (fDebAmt.equals(ChkPayAmt) && DRAcct.equals(getData("DebitAccount"))) {
					ReportHelper.logReportStatus(LogStatus.PASS, "Debit Amount '" + fDebAmt + "' of DrAcctNo '" + getData("DebitAccount") + "' verified correctly");
				} else {
					ReportHelper.logReportStatus(LogStatus.FAIL, "Debit Amount '" + fDebAmt + "' of DrAcctNo '" + getData("DebitAccount") + "' verified is not correct");
				}

				if (fCredAmt.equals(ChkCredAmt) && CRAcct.equals(getData("BeneficiaryAccount"))) {
					ReportHelper.logReportStatus(LogStatus.PASS, "Credit Amount '" + ChkCredAmt + "' of CrAcctNo '" + getData("BeneficiaryAccount") + "' verified correctly");
				} else {
					ReportHelper.logReportStatus(LogStatus.FAIL, "Credit Amount '" + ChkCredAmt + "' of CrAcctNo '" + getData("BeneficiaryAccount") + "' verified is not correct");
				}

				if (DrBrnch.equals(getData("DebitBranch")) && CrBrnch.equals(getData("CreditBranch"))) {
					ReportHelper.logReportStatus(LogStatus.PASS, "Debit Branch '" + DrBrnch + "' & Credit Branch '" + CrBrnch + " verified correctly");
				} else {
					ReportHelper.logReportStatus(LogStatus.FAIL, "Debit Branch '" + DrBrnch + "' & Credit Branch '" + CrBrnch + " verified is not correct");
				}
			} else {

			}
		} catch(Exception e) {
			logReportStatus(LogStatus.FAIL,"Search Transaction Reference Number failed due to '"+e.getMessage()+"'");
		}
	}

	/**********************************************************************************************************************************/
    /*
     * Function Name : VerifyContractDetails_OwnFT
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

	public static void VerifyContractDetails_OwnFT()  {

		try {
			WebDriver driver=getLatestDriver();
			waitFor(5000);
			driver.switchTo().frame(po_UBS.Frame2_UBS_Contracts.get(1));

			driver.findElement(By.xpath("//*[@id='CSCBRENT']/a/span")).click();
			waitFor(5000);

			//driver.switchTo().frame("ifrSubScreen");
			driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@id='ifrSubScreen']")));
			DecimalFormat dformat=new DecimalFormat("0.00");
			Double TxnAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='__LCY_AMOUNTI']")).getAttribute("value"));
			Double OffAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='__LCY_AMOUNTI1']")).getAttribute("value"));

			if((TxnAmt.equals(OffAmt)) ) {
				ReportHelper.updateStatusDescDb=true;
				logReportStatus(LogStatus.PASS, "Account Entries has been verified correctly");
				driver.findElement(By.xpath("//*[@id='BLK_ACVWS_ALL_AC_ENTRIES']//tr[1]/td[4]/input")).click();
				Robot rt = new Robot();
				for (int i=1;i<13;i++) {
					rt.keyPress(KeyEvent.VK_RIGHT);
					rt.keyRelease(KeyEvent.VK_RIGHT);
				}
				logReportStatus(LogStatus.PASS, "Transaction details has been verified correctly");
			} else {
				logReportStatus(LogStatus.FAIL, "Transaction details has not been verified correctly");
			}

			Thread.sleep(2000);
			driver.switchTo().defaultContent();
		} catch (Exception e) {
			logReportStatus(LogStatus.FAIL,"Verification of transaction details failed due to '"+e.getMessage()+"'");
		}

	}

	/**********************************************************************************************************************************/
    /*
     * Function Name : ExitAllActiveWindows_OwnFT
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

	public static void ExitAllActiveWindows_OwnFT()  {

		try {
			WebDriver driver=getLatestDriver();
			driver.switchTo().frame(po_UBS.Frame2_UBS_Contracts.get(1));
			driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@id='ifrSubScreen']")));
			//driver.switchTo().frame("ifrSubScreen");
			driver.findElement(By.cssSelector("#BTN_EXIT_IMG")).click();
			driver.switchTo().defaultContent();

			driver.switchTo().frame(po_UBS.Frame2_UBS_Contracts.get(1));
			driver.findElement(By.cssSelector("#BTN_EXIT_IMG")).click();
			driver.switchTo().defaultContent();
			Thread.sleep(2000);

			//driver.switchTo().frame(driver.findElement(By.cssSelector("#ifr_LaunchWin")));
			driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@title='Retail Teller Transaction Query ']")));
			driver.findElement(By.cssSelector("#BTN_EXIT")).click();
			driver.switchTo().defaultContent();
		} catch (Exception e) {
			logReportStatus(LogStatus.FAIL,"Exit all active windows failed due to '" +e.getMessage()+"'");
		}

	}

	public static void VerifyContractDetails1() throws Exception {

		try {
			WebDriver driver=getLatestDriver();
			waitFor(3000);
			driver.switchTo().frame(po_UBS.Frame2_UBS_Contracts.get(1));
			driver.findElement(By.xpath("//*[@id='CSDEVENT']")).click();
			waitFor(3000);
			driver.switchTo().defaultContent();
			List<WebElement> frame1;
			frame1=driver.findElements(By.cssSelector("#ifr_LaunchWin"));
			driver.switchTo().frame(frame1.get(2));
			//newly copies
			List <WebElement> EventLst = driver.findElements(By.xpath("//div[@id='tableContainer']//tbody/tr/td[4]"));
			int EventCnt = EventLst.size();
			for (int i=1;i<EventCnt+1;i++) {
				String EventCode = driver.findElement(By.xpath("//div[@id='tableContainer']//tbody/tr["+i+"]/td[4]/input")).getAttribute("value");
				System.out.println(EventCode);
				if (EventCode.equals("INIT")) {
					driver.findElement(By.xpath("//div[@id='tableContainer']//tbody/tr["+i+"]/td[4]")).click();
					break;
				}
			}
			waitFor(1000);
			ReportHelper.logReportStatus(LogStatus.PASS,"Event details entered successfully");

			click(po_UBS.Button_UBS_AccountEntries);
			waitFor(2000);
			driver.switchTo().defaultContent();
			//ReportHelper.logReportStatus(LogStatus.PASS,"Account entries displayed in the screen successfully");

			List<WebElement> frame2;
			frame2=driver.findElements(By.cssSelector("#ifr_LaunchWin"));
			driver.switchTo().frame(frame2.get(3));
		//	switchDFrame(po_UBS.Frame2_UBS_Contracts);

			DecimalFormat dformat=new DecimalFormat("0.00");

			/*Double tPaymtAmt=0.0,tConvAmt=0.0;
			tPaymtAmt = Double.parseDouble(getData("PaymentAmount"));
			tConvAmt = Double.parseDouble(getData("ConversionAmount"));*/

			//String ExcRate = po_UBS.Input_UBS_ExcRate.get(1).getAttribute("value");
/*			LCYAmt = Double.parseDouble(po_UBS.Input_UBS_LCYAmt.get(1).getAttribute("value"));
			FCYAmt = Double.parseDouble(po_UBS.Input_UBS_FCYAmt.get(1).getAttribute("value"));
			String AccCcy = po_UBS.Input_UBS_AccCcy.get(1).getAttribute("value");*/

/*			if((tPaymtAmt.equals(FCYAmt)) && (tConvAmt.equals(LCYAmt)) && (AccCcy.equals(Ccy)) && ExcRate.equals(getData("ExchangeRate")) ) {
				ReportHelper.logReportStatus(LogStatus.PASS,"Debit Currency and Credit Currency verified successfully");
				po_UBS.Input_UBS_CrAcct.get(1).click();
				Robot rt = new Robot();
				rt.keyPress(KeyEvent.VK_TAB);
				rt.keyRelease(KeyEvent.VK_TAB);
				rt.keyPress(KeyEvent.VK_TAB);
				rt.keyRelease(KeyEvent.VK_TAB);

				logReportStatus(LogStatus.PASS, "Debit and credit details verified successfully");
			} else {
				logReportStatus(LogStatus.FAIL, "Debit and Credit details verified successfully");
			}*/

			List <WebElement> AccEntLst = driver.findElements(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr/td[4]/input"));
			int AccEntCnt = AccEntLst.size();
			int index=0;
			Robot rt = new Robot();
			for (int i=1;i<AccEntCnt;i++) {
				//String AcctNum = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+i+"]/td[4]")).getText();
				System.out.println(AccEntLst.get(i).getAttribute("value"));
				if (AccEntLst.get(i).getAttribute("value").equals(getData("UBS_ChgeAcctNo"))) {
					index=i+1;
					String CRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
					if (CRTag.equals("C")) {
						ReportHelper.logReportStatus(LogStatus.PASS, "Charge Account and CR Tag verified successfully");
					} else {
						ReportHelper.logReportStatus(LogStatus.FAIL, "Charge Account and CR Tag has not been verified successfully");
					}
					AccEntLst.get(i).click();
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					if (driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value").equals(getData("UBS_CAmount"))) {
						ReportHelper.logReportStatus(LogStatus.PASS, "Fee Charge Amount verified successfully");
					} else {
						ReportHelper.logReportStatus(LogStatus.FAIL, "Fee Charge Amount verification is not successful");
					}
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					waitFor(1000);
				} else if(AccEntLst.get(i).getAttribute("value").equals(getData("UBS_VATAcctNo"))) {
					index=i+1;
					String CRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
					if (CRTag.equals("C")) {
						ReportHelper.logReportStatus(LogStatus.PASS, "VAT Account and CR Tag verified successfully");
					} else {
						ReportHelper.logReportStatus(LogStatus.FAIL, "VAT Account and CR Tag has not been verified successfully");
					}
					AccEntLst.get(i).click();
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					System.out.println(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value")+" ///"+(getData("UBSVATAmt")));
					double VAtamt=Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value"));
					if (VAtamt==Double.parseDouble(getData("UBSVATAmt"))) {
						ReportHelper.logReportStatus(LogStatus.PASS, "VAT Amount verified successfully");
					} else {
						ReportHelper.logReportStatus(LogStatus.FAIL, "VAT Amount verification is not successful");
					}
						rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					waitFor(1000);
				}  else if(AccEntLst.get(i).getAttribute("value").equals(getData("UBSDebitAccount"))) {
					index=i+1;
					String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
					String CcyTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[7]/input")).getAttribute("value");
					if (DRTag.equals("D") && CcyTag.equals(getData("DebitCurrency"))) {
						ReportHelper.logReportStatus(LogStatus.PASS, "Debit Account and DR & Currency Tag verified successfully");
					} else {
						ReportHelper.logReportStatus(LogStatus.FAIL, "Debit Account and DR & Currency Tag has not been verified successfully");
					}
					AccEntLst.get(i).click();
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					Double TotTxnAmt = Double.parseDouble(getData("UBS_CAmount"))+Double.parseDouble(getData("UBSVATAmt"))+Double.parseDouble(getData("CreditAmount"));
					String TotDebAmt = dformat.format(TotTxnAmt);
					if (driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value").equals(TotDebAmt)) {
						ReportHelper.logReportStatus(LogStatus.PASS, "Debit Amount verified successfully");
					} else {
						ReportHelper.logReportStatus(LogStatus.FAIL, "Debit amount verification is not successful");
					}
						rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					waitFor(1000);
				} else if(AccEntLst.get(i).getAttribute("value").equals(getData("UBSCreditAccount"))) {
					index=i+1;
					String CRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
					if (CRTag.equals("C")) {
						ReportHelper.logReportStatus(LogStatus.PASS, "Credit Account and CR & Currency Tag verified successfully");
					} else {
						ReportHelper.logReportStatus(LogStatus.FAIL, "Credit Account and CR & Currency Tag has not been verified successfully");
					}
					AccEntLst.get(i).click();
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					Double creditAmt=Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value"));
					System.out.println(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value") +"///"+(getData("CreditAmount")));
					if (creditAmt==Double.parseDouble(getData("CreditAmount")) ) {
						ReportHelper.logReportStatus(LogStatus.PASS, "Credit Amount verified successfully");
					} else {
						ReportHelper.logReportStatus(LogStatus.FAIL, "Credit amount verification is not successful");
					}
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					waitFor(1000);
				}
			}
//****************************************
/*			List<WebElement> Amt=driver.findElements(By.xpath("//input[@name='LCYAMT']"));
			DecimalFormat dformat=new DecimalFormat("0.0");
			Double TOTAL_AMt=0.0,Calculated_TOTAMt=0.0;
			TOTAL_AMt=Double.parseDouble( Amt.get(0).getAttribute("value"));
			for(int i=1;i<Amt.size();i++)
			{
				Calculated_TOTAMt=Calculated_TOTAMt+ Double.parseDouble( Amt.get(i).getAttribute("value"));
			}*/

/*			if((Calculated_TOTAMt.equals(TOTAL_AMt)) )
			{ReportHelper.updateStatusDescDb=true;
				logReportStatus(LogStatus.PASS, "Transaction Details: Payment Amount & Fees has been verified in UBS");
			} else {
				logReportStatus(LogStatus.FAIL, "Transaction Details: Payment Amount & Fees are not displayed as expected in UBS");
			}*/

/*			if((Calculated_TOTAMt.equals(TOTAL_AMt))) {
				ReportHelper.logReportStatus(LogStatus.PASS,"Debit and Credit account details verified successfully");
				po_UBS.Input_UBS_CrAcct.get(1).click();
				Robot rt = new Robot();
				rt.keyPress(KeyEvent.VK_TAB);
				rt.keyRelease(KeyEvent.VK_TAB);
				rt.keyPress(KeyEvent.VK_TAB);
				rt.keyRelease(KeyEvent.VK_TAB);

				logReportStatus(LogStatus.PASS, "Transaction details verified successfully");
			} else {
				logReportStatus(LogStatus.FAIL, "Transaction details verified successfully");
			}*/

			Thread.sleep(2000);
			driver.switchTo().defaultContent();
		} catch (Exception e) {
			logReportStatus(LogStatus.FAIL,"Verification of transaction details failed due to '"+e.getMessage()+"'");
		}

	}

	public static void ExitAllActiveWindows1()  {

		try {
			WebDriver driver=getLatestDriver();
			List<WebElement> frame2;
			frame2=driver.findElements(By.cssSelector("#ifr_LaunchWin"));

			driver.switchTo().frame(frame2.get(3));
			driver.findElement(By.cssSelector("#BTN_EXIT_IMG")).click();
			driver.switchTo().defaultContent();


			driver.switchTo().frame(po_UBS.Frame2_UBS_Contracts.get(2));
			driver.findElement(By.cssSelector("#BTN_EXIT_IMG")).click();

			driver.switchTo().defaultContent();

			List<WebElement> sam1=driver.findElements(By.xpath("//*[@id='ifr_LaunchWin']"));
			driver.switchTo().frame(sam1.get(1));

			driver.findElement(By.cssSelector("#BTN_EXIT_IMG")).click();
			Thread.sleep(2000);
			driver.switchTo().defaultContent();

			driver.switchTo().frame(driver.findElement(By.cssSelector("#ifr_LaunchWin")));
			driver.findElement(By.cssSelector("#BTN_EXIT")).click();
			driver.switchTo().defaultContent();

		} catch (Exception e) {
			logReportStatus(LogStatus.FAIL,"Exit all active windows failed due to '" +e.getMessage()+"'");
		}

	}

	public static void ExitAllActiveWindows2()  {

		try {
			WebDriver driver=getLatestDriver();

			driver.switchTo().frame(po_UBS.Frame2_UBS_Contracts.get(2));
			driver.findElement(By.cssSelector("#BTN_EXIT_IMG")).click();

			driver.switchTo().defaultContent();

			List<WebElement> sam1=driver.findElements(By.xpath("//*[@id='ifr_LaunchWin']"));
			driver.switchTo().frame(sam1.get(1));

			driver.findElement(By.cssSelector("#BTN_EXIT_IMG")).click();
			Thread.sleep(2000);
			driver.switchTo().defaultContent();

			driver.switchTo().frame(driver.findElement(By.cssSelector("#ifr_LaunchWin")));
			driver.findElement(By.cssSelector("#BTN_EXIT_IMG")).click();
			driver.switchTo().defaultContent();

			waitFor(2000);
			hover(po_UBS.Image_UBS_BranchIsOnline);
			waitFor(1000);
			click(po_UBS.Select_UBS_HomeBranch);
			waitFor(2000);

			//driver.switchTo().frame("ifr_AlertWin");
			driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@title='Information Message']")));
			driver.findElement(By.xpath("//*[@id='BTN_OK']")).click();

		} catch (Exception e) {
			logReportStatus(LogStatus.FAIL,"Exit all active windows failed due to '" +e.getMessage()+"'");
		}

	}

	/**********************************************************************************************************************************/
    /*
     * Function Name : SearchAccNo_RetailIB
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

	public static void SearchAccNo_RetailIB() {
		try {
			initPageObjects();
			getLatestDriver();
			WebDriver driver = getLatestDriver();

			click(po_UBS.Button_UBS_EnterQuery);
			waitFor(1000);

			driver.switchTo().frame("ifr_LaunchWin");

			sendKeys(po_UBS.Input_UBS_RDIAcctNo, getData("AccountNum"));
			waitFor(1000);
			driver.switchTo().defaultContent();

			click(po_UBS.Button_UBS_ExecuteQuery);
			waitFor(5000);
			driver.switchTo().frame("ifr_LaunchWin");

			String CustNo = getText(po_UBS.Input_UBS_RDICustNo);
			if (!CustNo.equals("")) {
				ReportHelper.logReportStatus(LogStatus.PASS,"Customer Account details displayed in the screen successfully");
				saveTestDataToDb("CustomerNo",CustNo);
				driver.switchTo().defaultContent();
			} else {
				ReportHelper.logReportStatus(LogStatus.FAIL,"Customer Account details displayed in the screen is not successful");
			}

		} catch (Exception e) {
			ReportHelper.logReportStatus(LogStatus.FAIL,"Search Account Number failed due to '"+e.getMessage()+"'");
		}
	}

	/**********************************************************************************************************************************/
    /*
     * Function Name : SearchAcctSummary_RetailIB
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

	public static void SearchAcctSummary_RetailIB() {

		try {
			initPageObjects();
			getLatestDriver();
			WebDriver driver = getLatestDriver();

			click(po_UBS.Button_UBS_Customer);
			waitFor(1000);

			String CustID = getData("CustomerNo");
			sendKeys(po_UBS.Input_UBS_SearchCustomerID,CustID);
			waitFor(1000);
			ReportHelper.logReportStatus(LogStatus.PASS,"Customer Number entered in the search successfully");
			click(po_UBS.Button_UBS_Search);

			int waitCust = 15;
			boolean Flag;
			Flag=false;
			for (int i=1;i<waitCust;i++) {
				waitFor(1000);
				if (!po_UBS.Table_UBS_CustomerList.equals("")) {
					ReportHelper.logReportStatus(LogStatus.PASS,"Entered Customer ID is found in the record successfully");
					click(po_UBS.Table_UBS_CustomerList);
					Flag = true;
					break;
				}
			}

			if (Flag=false) {
				ReportHelper.logReportStatus(LogStatus.FAIL,"Entered Customer ID is not found in the record successfully");
			}

			int waitAcct = 20;
			boolean Flag2;
			Flag2=false;
			for (int i=1;i<waitAcct;i++) {
				waitFor(1000);
				if (!driver.findElement(By.xpath("//div[@id='ListofAccDiv']//tbody/tr[1]/td[1]/a")).getText().equals("")) {
					ReportHelper.logReportStatus(LogStatus.PASS,"Accounts displayed in the list successfully");
					Flag2 = true;
					break;
				}
			}

			if (Flag2=false) {
				ReportHelper.logReportStatus(LogStatus.FAIL,"Entered Customer ID is not found in the record successfully");
			}

			//div[@id='ListofAccDiv']//a[contains(.,'29900186629')]
			driver.findElement(By.xpath("//div[@id='ListofAccDiv']//a[contains(.,'"+getData("AccountNum")+"')]")).click();
			waitFor(1000);

			String Prod = getText(po_UBS.WebElement_UBS_AcctProduct);
			String cCurrBal = getText(po_UBS.WebElement_UBS_CurrentAcct).replace(",","").trim();

			if (Prod.equals("CUROP") && cCurrBal.equals(getData("CurrentBalance")) || Prod.equals("FCURAC") && cCurrBal.equals(getData("FCYAccountBalance"))) {
				scrollDownScreenShot(po_UBS.WebElement_UBS_CurrentAcct,"Current Balance verified successfully");
				ReportHelper.logReportStatus(LogStatus.PASS,"Current Balance verified successfully");
			} else  {
				ReportHelper.logReportStatus(LogStatus.FAIL,"Current Balance verified is not successful");
			}

			// Meem OnePack
			if (getData("AcctType").equals("SAR")) {
				String temp = getData("AccountNum");
				Double SavAccNo = Double.parseDouble(temp);
				SavAccNo = SavAccNo + 1;
				DecimalFormat df = new DecimalFormat("0");
				String fSavAcct = df.format(SavAccNo);
				System.out.println(fSavAcct);
				driver.findElement(By.xpath("//div[@id='ListofAccDiv']//a[contains(.,'" + fSavAcct + "')]")).click();
				waitFor(1000);
				String Prod2 = getText(po_UBS.WebElement_UBS_AcctProduct);
				String cAvalBal = getText(po_UBS.WebElement_UBS_SavingAcct).replace(",", "").trim();

				if (Prod2.equals("SAVOP") && cAvalBal.equals(getData("SavingAcctBalance"))) {
					scrollDownScreenShot(po_UBS.WebElement_UBS_SavingAcct, "Saving account Balance verified successfully");
					ReportHelper.logReportStatus(LogStatus.PASS, "Saving account verified successfully");
				} else {
					ReportHelper.logReportStatus(LogStatus.FAIL, "Saving account verified is not successful");
				}
			}

		} catch (Exception e) {
			ReportHelper.logReportStatus(LogStatus.FAIL,"Search customer details failed due to '"+e.getMessage()+"'");
		}

	}

	/**********************************************************************************************************************************/
    /*
     * Function Name : SearchREFNo_RetailIB
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

	public static void SearchREFNo_RetailIB() {

		try
		{
			initPageObjects();
			getLatestDriver();
			WebDriver driver =getLatestDriver();

			click(po_UBS.Button_UBS_EnterQuery);
			waitFor(1000);

			driver.switchTo().frame("ifr_LaunchWin");
			sendKeys(po_UBS.Input_UBS_RDIContRefNo,getData("UBS_ReferenceNumber"));
			waitFor(1000);
			driver.switchTo().defaultContent();

			click(po_UBS.Button_UBS_ExecuteQuery);
			waitFor(5000);
			driver.switchTo().frame("ifr_LaunchWin");
			DecimalFormat dformat=new DecimalFormat("0.00");
			String intDebitAmount = getText(po_UBS.Input_UBS_DebitAmount).replace(",","").trim();
			Double DebAmt = Double.parseDouble(intDebitAmount);
			String dDebAmt = dformat.format(DebAmt) ;

			String intCreditAmount = getText(po_UBS.Input_UBS_CreditAmount).replace(",","").trim();
			Double CredAmt = Double.parseDouble(intCreditAmount);
			String dCredAmt = dformat.format(CredAmt) ;
			String cDRAcct = getText(po_UBS.Input_UBS_DebitAccount);
			String cCRAcct = getText(po_UBS.Input_UBS_CreditAccount);
			String IBANNum = getText(po_UBS.Input_UBS_BeneIBANAccount).replace("/","").trim();
			String intTotalAmount = getText(po_UBS.Input_UBS_TotalAmount).replace(",","").trim();
			Double TotAmt = Double.parseDouble(intTotalAmount);
			String dTotAmt = dformat.format(TotAmt);

			String DebBrnch = getText(po_UBS.Input_UBS_DebitBranch);
			String CredBrnch = getText(po_UBS.Input_UBS_CreditBranch);
			Double tPayAmt = Double.parseDouble(getData("PaymentAmount"));
			String ChkPayAmt = "";
			ChkPayAmt = dformat.format(tPayAmt);
			String ChkCredAmt = "";
			String Ccy = getData("BeneCurrency");
			if ((getData("BeneType").equals("WITHIN MEEM")&&Ccy.equals("FCY")) ||(getData("BeneType").equals("WITHIN KSA")&&Ccy.equals("FCY")) || (getData("BeneType").equals("INTERNATIONAL")) ) {
				Double tCredAmt = Double.parseDouble(getData("CreditAmount"));
				ChkCredAmt = dformat.format(tCredAmt);
			} else {
				ChkCredAmt = dformat.format(tPayAmt);
			}

			Double tTotAmt = Double.parseDouble(getData("TotalTxnAmount"));
			String ChkTotAmt = dformat.format(tTotAmt);

			if ((cDRAcct.equals(getData("UBS_DebAcct")) && dDebAmt.equals(ChkPayAmt))) {
				ReportHelper.logReportStatus(LogStatus.PASS,"Debit Amount '"+dDebAmt+"' of account number '"+getData("UBS_DebAcct")+"' has been verified correctly");
			} else {
				ReportHelper.logReportStatus(LogStatus.FAIL,"Debit Amount '"+dDebAmt+"' of account number '"+getData("UBS_DebAcct")+"' has not been verified correctly");
			}

			if ((cCRAcct.equals(getData("UBS_CredAcct")) && dCredAmt.equals(ChkCredAmt)) || (IBANNum.equals(getData("CRAcctNo")) && dCredAmt.equals(ChkCredAmt))) {
				ReportHelper.logReportStatus(LogStatus.PASS,"Credit Amount '"+ChkCredAmt+"' of account number '"+getData("UBS_CredAcct")+"' has been verified correctly");
			} else {
				ReportHelper.logReportStatus(LogStatus.FAIL,"Credit Amount '"+ChkCredAmt+"' of account number '"+getData("UBS_CredAcct")+"' has not been verified correctly");
			}

			if ( (DebBrnch.equals(getData("UBS_DebBranch"))) && (CredBrnch.equals(getData("UBS_CredBranch")))) {
				ReportHelper.logReportStatus(LogStatus.PASS,"Debit and Credit Branch verified correctly");
			} else {
				ReportHelper.logReportStatus(LogStatus.FAIL,"Debit and Credit Branch verification is not correct");
			}

			if ( dTotAmt.equals(ChkTotAmt)) {
				ReportHelper.logReportStatus(LogStatus.PASS,"Total amount verified correctly");
			} else {
				ReportHelper.logReportStatus(LogStatus.FAIL,"Total amount verification is not correct");
			}

			//*****Old validation****************
/*			if ((cCRAcct.equals(getData("CRAcctNo")) && dTotAmt.equals(ChkTotAmt)) || (IBANNum.equals(getData("CRAcctNo")) && dTotAmt.equals(ChkTotAmt)) ) {
			//if (dTotAmt.equals(ChkTotAmt)) {
				ReportHelper.logReportStatus(LogStatus.PASS,"Total Amount '"+dTotAmt+"' of account number '"+getData("CRAcctNo")+"' has been verified correctly");
			} else if (ChkCredAmt.equals(intCreditAmount)) {
				ReportHelper.logReportStatus(LogStatus.PASS,"Credit Amount '"+dTotAmt+"' has been verified correctly");
			} else {
				ReportHelper.logReportStatus(LogStatus.FAIL,"Total Amount of Credit account has not been verified correctly");
			}*/
			driver.switchTo().defaultContent();

		} catch(Exception e)
		{
			logReportStatus(LogStatus.FAIL,"Search Transaction Reference Number failed due to '"+e.getMessage()+"'");
		}
	}

	/**********************************************************************************************************************************/
    /*
     * Function Name : VerifyContractDetails_RetailIB
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

	public static void VerifyContractDetails_RetailIB()  {

		try {
			WebDriver driver=getLatestDriver();
			waitFor(1000);
			driver.switchTo().defaultContent();
			driver.switchTo().frame("ifr_LaunchWin");
			//switchDFrame(po_UBS.Frame_UBS_Contracts);

			click(po_UBS.Button_UBS_Event);
			waitFor(2000);
			driver.switchTo().defaultContent();

			switchDFrame(po_UBS.Frame2_UBS_Contracts);
			ReportHelper.logReportStatus(LogStatus.PASS,"Event displayed in the screen successfully");
/*			for (WebElement ele:po_UBS.ChkBox_UBS_Event){
				if (ele.isSelected()==false) {
					ele.click();
				}
			}*/
			List <WebElement> EventLst = driver.findElements(By.xpath("//div[@id='tableContainer']//tbody/tr/td[4]"));
			int EventCnt = EventLst.size();
			for (int i=1;i<EventCnt+1;i++) {
				String EventCode = driver.findElement(By.xpath("//div[@id='tableContainer']//tbody/tr["+i+"]/td[4]/input")).getAttribute("value");
				System.out.println(EventCode);
				if (EventCode.equals("INIT")) {
					driver.findElement(By.xpath("//div[@id='tableContainer']//tbody/tr["+i+"]/td[4]")).click();
					break;
				}
			}

			waitFor(1000);
			ReportHelper.logReportStatus(LogStatus.PASS,"Event details entered successfully");
			click(po_UBS.Button_UBS_AccountEntries);
			waitFor(2000);
			driver.switchTo().defaultContent();
			ReportHelper.logReportStatus(LogStatus.PASS,"Account entries displayed in the screen successfully");

/*			switchDFrame(po_UBS.Frame2_UBS_Contracts);
			waitFor(2000);
			DecimalFormat dformat=new DecimalFormat("0.00");
			List <WebElement> AccEntLst = driver.findElements(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr/td[4]/input"));
			int AccEntCnt = AccEntLst.size();
			int index=0;
			Robot rt = new Robot();
			Double ChkCAmt=0.00;
			if (getData("BeneType").equals("WITHIN MEEM") ) {
				for (int i=0;i<AccEntCnt;i++) {
					System.out.println(AccEntLst.get(i).getAttribute("value"));
					if(AccEntLst.get(i).getAttribute("value").equals(getData("UBS_DebAcct"))) {
						index=i+1;
						String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
						String CcyTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[7]/input")).getAttribute("value");
						if (DRTag.equals("D") && CcyTag.equals(getData("UBS_DebitCurrency"))) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Debit Account and DR & Currency Tag verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Debit Account and DR & Currency Tag has not been verified successfully");
						}
						AccEntLst.get(i).click();
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						Double DebAmt = Double.parseDouble(getData("PaymentAmount"));
						String dDebtAmt = dformat.format(DebAmt);
						String dDebtAmt2 = "";
						if (getData("BeneCurrency").equalsIgnoreCase("FCY")) {
							Double DebAmt2 = Double.parseDouble(getData("CreditAmount"));
							dDebtAmt2 = dformat.format(DebAmt2);
							Double FCYAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[8]/input")).getAttribute("value"));
							String vFCYAmt = dformat.format(FCYAmt);
							String ExcRate = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[9]/input")).getAttribute("value");
							if (vFCYAmt.equals(dDebtAmt) && ExcRate.equals(getData("UBS_ExcRate"))) {
								ReportHelper.logReportStatus(LogStatus.PASS,"Foreign Currency Amount and Exchange Rate have been validated as '"+vFCYAmt+"' and '"+ExcRate+"'");
							} else {
								ReportHelper.logReportStatus(LogStatus.FAIL,"Foreign Currency Amount and Exchange Rate have not been validated as '"+vFCYAmt+"' and '"+ExcRate+"'");
							}
						}
						Double ChkDAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value").replace(",","").trim());
						String DrAmt = dformat.format(ChkDAmt);
						if (DrAmt.equals(dDebtAmt) || DrAmt.equals(dDebtAmt2)) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Debit Amount - '"+DrAmt+"' verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Debit Amount verification is not successful");
						}
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						waitFor(2000);
					} else if(AccEntLst.get(i).getAttribute("value").equals(getData("UBS_CredAcct"))) {
						index=i+1;
						String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
						String CcyTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[7]/input")).getAttribute("value");
						if (DRTag.equals("C") && CcyTag.equals(getData("UBS_CreditCurrency"))) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Credit Account and CR & Currency Tag verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Credit Account and CR & Currency Tag has not been verified successfully");
						}
						AccEntLst.get(i).click();
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						Double CredAmt = Double.parseDouble(getData("PaymentAmount"));
						String dCredAmt = dformat.format(CredAmt);
						ChkCAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value").replace(",","").trim());
						String CrAmt = dformat.format(ChkCAmt);
						String dCredAmt2 = "";
						if (getData("BeneCurrency").equalsIgnoreCase("FCY")) {
							Double CredAmt2 = Double.parseDouble(getData("CreditAmount"));
							dCredAmt2 = dformat.format(CredAmt2);
						}
						if (CrAmt.equals(dCredAmt) || CrAmt.equals(dCredAmt2)) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Credit Amount -'"+CrAmt+"' verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Credit amount verification is not successful");
						}
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						waitFor(2000);
					}
				}
			} else if ((getData("BeneType").equals("INTERNATIONAL") && getData("BeneCurrency").equalsIgnoreCase("SAR"))|| (getData("BeneType").equals("WITHIN KSA")) ) {
				for (int i = 0; i < AccEntCnt; i++) {
					System.out.println(AccEntLst.get(i).getAttribute("value"));
					AccEntLst.get(i).click();
					if (AccEntLst.get(i).getAttribute("value").equals(getData("UBS_DebAcct"))) {
						index = i + 1;
						String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[5]/input")).getAttribute("value");
						String CcyTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[7]/input")).getAttribute("value");
						if (DRTag.equals("D") && CcyTag.equals(getData("UBS_DebitCurrency"))) {
							scrollDown(AccEntLst.get(i));
							ReportHelper.logReportStatus(LogStatus.PASS, "Debit Account and DR & Currency Tag verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Debit Account and DR & Currency Tag has not been verified successfully");
						}
						AccEntLst.get(i).click();
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						Double DebtAmt = 0.00;
						if (getData("BeneCurrency").equalsIgnoreCase("SAR")) {
							DebtAmt = Double.parseDouble(getData("PaymentAmount"));
						} else if (getData("BeneCurrency").equalsIgnoreCase("FCY")) {
							DebtAmt = Double.parseDouble(getData("CreditAmount"));
							Double TxnAmt = Double.parseDouble(getData("TotalTxnAmount"));
							String vTxnAmt = dformat.format(TxnAmt);
							Double FCYAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[8]/input")).getAttribute("value"));
							String vFCYAmt = dformat.format(FCYAmt);
							String ExcRate = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[9]/input")).getAttribute("value");
							if (vFCYAmt.equals(vTxnAmt) && ExcRate.equals(getData("UBS_ExcRate"))) {
								ReportHelper.logReportStatus(LogStatus.PASS, "Foreign Currency Amount and Exchange Rate have been validated as '" + vFCYAmt + "' and '" + ExcRate + "'");
							} else {
								ReportHelper.logReportStatus(LogStatus.FAIL, "Foreign Currency Amount and Exchange Rate have not been validated as '" + vFCYAmt + "' and '" + ExcRate + "'");
							}
						}
						Double CAmt = Double.parseDouble(getData("UBS_CAmount"));
						//Double FeeAmt = Double.parseDouble(getData("UBS_FeeAmount"));
						Double VATAmt = Double.parseDouble(getData("UBS_VATAmount"));
						Double DebAmt = DebtAmt + CAmt + VATAmt;
						//Double DebAmt = DebtAmt+CAmt+FeeAmt+VATAmt;
						String dDebtAmt = dformat.format(DebAmt);
						Double ChkDAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[10]/input")).getAttribute("value").replace(",", "").trim());
						String DrAmt = dformat.format(ChkDAmt);
						if (DrAmt.equals(dDebtAmt)) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Debit Amount - '" + DrAmt + "' verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Debit Amount verification is not successful");
						}
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						waitFor(3000);
					} else if (AccEntLst.get(i).getAttribute("value").equals(getData("UBS_CredAcct"))) {
						waitFor(2000);
						scrollDown(AccEntLst.get(i));
						index = i + 1;
						String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[5]/input")).getAttribute("value");
						String CcyTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[7]/input")).getAttribute("value");
						if (DRTag.equals("C") && CcyTag.equals(getData("UBS_CreditCurrency"))) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Credit Account and CR & Currency Tag verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Credit Account and CR & Currency Tag has not been verified successfully");
						}
						AccEntLst.get(i).click();
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						Double CredAmt = 0.00;
						if (getData("BeneCurrency").equalsIgnoreCase("FCY")) {
							CredAmt = Double.parseDouble(getData("CreditAmount"));
						} else {
							CredAmt = Double.parseDouble(getData("PaymentAmount"));
						}
						String dCredAmt = dformat.format(CredAmt);
						ChkCAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[10]/input")).getAttribute("value").replace(",", "").trim());
						String CrAmt = dformat.format(ChkCAmt);
						if (CrAmt.equals(dCredAmt)) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Credit Amount -'" + CrAmt + "' verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Credit amount verification is not successful");
						}
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						waitFor(3000);
					} else if (AccEntLst.get(i).getAttribute("value").equals(getData("UBS_ChgeAcct"))) {
						waitFor(2000);
						scrollDown(AccEntLst.get(i));
						index = i + 1;
						String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[5]/input")).getAttribute("value");
						if (DRTag.equals("C")) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Charge Account and CR Tag verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Charge Account and CR Tag  has not been verified successfully");
						}
						AccEntLst.get(i).click();
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						Double gCAmt = Double.parseDouble(getData("UBS_CAmount"));
						String dCAmt = dformat.format(gCAmt);
						Double CAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[10]/input")).getAttribute("value").replace(",", "").trim());
						String vCAmt = dformat.format(CAmt);
						if (vCAmt.equals(dCAmt)) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Charge Amount -'" + gCAmt + "' verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Charge amount verification is not successful");
						}
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						waitFor(3000);
					*//*} *//**//*else if(AccEntLst.get(i).getAttribute("value").equals(getData("UBS_FeeAcct"))) {
						index=i+1;
						String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
						if (DRTag.equals("C") ) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Fee Account and CR Tag  verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Fee Account and CR Tag  has not been verified successfully");
						}
						AccEntLst.get(i).click();
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						Double gFAmt = Double.parseDouble(getData("UBS_FeeAmount"));
						String dFAmt = dformat.format(gFAmt);
						Double FeeAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value").replace(",","").trim());
						String vFAmt = dformat.format(FeeAmt);
						if (vFAmt.equals(dFAmt)) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Fee Amount -'"+vFAmt+"' verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Fee amount verification is not successful");
						}
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						waitFor(3000);*//*
					} else if (AccEntLst.get(i).getAttribute("value").equals(getData("UBS_VATAcct"))) {
						waitFor(2000);
						scrollDown(AccEntLst.get(i));
						index = i + 1;
						String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[5]/input")).getAttribute("value");
						if (DRTag.equals("C")) {
							ReportHelper.logReportStatus(LogStatus.PASS, "VAT Account and CR Tag  verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "VAT Account and CR Tag  has not been verified successfully");
						}
						AccEntLst.get(i).click();
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						Double gVAmt = Double.parseDouble(getData("UBS_VATAmount"));
						String dVAmt = dformat.format(gVAmt);
						Double VATAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[10]/input")).getAttribute("value").replace(",", "").trim());
						String vVAmt = dformat.format(VATAmt);
						if (vVAmt.equals(dVAmt)) {
							ReportHelper.logReportStatus(LogStatus.PASS, "VAT Amount -'" + vVAmt + "' verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "VAT amount verification is not successful");
						}
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						waitFor(3000);
					}
				}
			} else if (getData("BeneType").equals("INTERNATIONAL") && getData("BeneCurrency").equalsIgnoreCase("FCY") ) {
					for (int i=0;i<AccEntCnt;i++) {
						System.out.println(AccEntLst.get(i).getAttribute("value"));
						AccEntLst.get(i).click();
						if(AccEntLst.get(i).getAttribute("value").equals(getData("UBS_DebAcct"))) {
							index=i+1;
							String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
							String CcyTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[7]/input")).getAttribute("value");
							if (DRTag.equals("D") && CcyTag.equals(getData("UBS_DebitCurrency"))) {
								scrollDown(AccEntLst.get(i));
								ReportHelper.logReportStatus(LogStatus.PASS, "Debit Account and DR & Currency Tag verified successfully");
							} else {
								ReportHelper.logReportStatus(LogStatus.FAIL, "Debit Account and DR & Currency Tag has not been verified successfully");
							}
							AccEntLst.get(i).click();
							rt.keyPress(KeyEvent.VK_TAB);
							rt.keyRelease(KeyEvent.VK_TAB);
							rt.keyPress(KeyEvent.VK_TAB);
							rt.keyRelease(KeyEvent.VK_TAB);
							Double TxnAmt = Double.parseDouble(getData("TotalTxnAmount"));
							String vTxnAmt = dformat.format(TxnAmt);
							Double FCYAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[8]/input")).getAttribute("value"));
							String vFCYAmt = dformat.format(FCYAmt);
							String ExcRate = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[9]/input")).getAttribute("value");
							if (vFCYAmt.equals(vTxnAmt) && ExcRate.equals(getData("UBS_DebExcRate"))) {
								ReportHelper.logReportStatus(LogStatus.PASS,"Foreign Currency Amount and Exchange Rate have been validated as '"+vFCYAmt+"' and '"+ExcRate+"'");
							} else {
								ReportHelper.logReportStatus(LogStatus.FAIL,"Foreign Currency Amount and Exchange Rate have not been validated as '"+vFCYAmt+"' and '"+ExcRate+"'");
							}
							Double CAmt = Double.parseDouble(getData("UBS_CAmount"));
							Double VATAmt = Double.parseDouble(getData("UBS_VATAmount"));
							Double DebtAmt = Double.parseDouble(getData("CreditAmount")) * Double.parseDouble(getData("UBS_CredExcRate"));
							Double DebAmt = DebtAmt+CAmt+VATAmt;
							String dDebtAmt = dformat.format(DebAmt);
							Double ChkDAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value").replace(",","").trim());
							String DrAmt = dformat.format(ChkDAmt);
							if (DrAmt.equals(dDebtAmt)) {
								ReportHelper.logReportStatus(LogStatus.PASS, "Debit Amount - '"+DrAmt+"' verified successfully");
							} else {
								ReportHelper.logReportStatus(LogStatus.FAIL, "Debit Amount verification is not successful");
							}
							rt.keyPress(KeyEvent.VK_TAB);
							rt.keyRelease(KeyEvent.VK_TAB);
							waitFor(3000);
						} else if(AccEntLst.get(i).getAttribute("value").equals(getData("UBS_CredAcct"))) {
							waitFor(2000);
							scrollDown(AccEntLst.get(i));
							index=i+1;
							String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
							String CcyTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[7]/input")).getAttribute("value");
							if (DRTag.equals("C") && CcyTag.equals(getData("UBS_CreditCurrency"))) {
								ReportHelper.logReportStatus(LogStatus.PASS, "Credit Account and CR & Currency Tag verified successfully");
							} else {
								ReportHelper.logReportStatus(LogStatus.FAIL, "Credit Account and CR & Currency Tag has not been verified successfully");
							}
							AccEntLst.get(i).click();
							rt.keyPress(KeyEvent.VK_TAB);
							rt.keyRelease(KeyEvent.VK_TAB);
							rt.keyPress(KeyEvent.VK_TAB);
							rt.keyRelease(KeyEvent.VK_TAB);
							Double CredAmt = Double.parseDouble(getData("CreditAmount"));
							String dCredAmt = dformat.format(CredAmt);
							Double FCYAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[8]/input")).getAttribute("value"));
							String vFCYAmt = dformat.format(FCYAmt);
							String ExcRate = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[9]/input")).getAttribute("value");
							if (vFCYAmt.equals(dCredAmt) && ExcRate.equals(getData("UBS_CredExcRate"))) {
								ReportHelper.logReportStatus(LogStatus.PASS,"Foreign Currency Amount and Exchange Rate have been validated as '"+vFCYAmt+"' and '"+ExcRate+"'");
							} else {
								ReportHelper.logReportStatus(LogStatus.FAIL,"Foreign Currency Amount and Exchange Rate have not been validated as '"+vFCYAmt+"' and '"+ExcRate+"'");
							}
							Double dCrAmount = CredAmt*Double.parseDouble(getData("UBS_CredExcRate"));
							String dCredAmt2 = dformat.format(dCrAmount);
							ChkCAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value").replace(",","").trim());
							String CrAmt = dformat.format(ChkCAmt);
							if (CrAmt.equals(dCredAmt2)) {
								ReportHelper.logReportStatus(LogStatus.PASS, "Credit Amount -'"+CrAmt+"' verified successfully");
							} else {
								ReportHelper.logReportStatus(LogStatus.FAIL, "Credit amount verification is not successful");
							}
							rt.keyPress(KeyEvent.VK_TAB);
							rt.keyRelease(KeyEvent.VK_TAB);
							waitFor(3000);
						} else if(AccEntLst.get(i).getAttribute("value").equals(getData("UBS_ChgeAcct"))) {
							waitFor(2000);
							scrollDown(AccEntLst.get(i));
							index=i+1;
							String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
							if (DRTag.equals("C") ) {
								ReportHelper.logReportStatus(LogStatus.PASS, "Charge Account and CR Tag verified successfully");
							} else {
								ReportHelper.logReportStatus(LogStatus.FAIL, "Charge Account and CR Tag  has not been verified successfully");
							}
							AccEntLst.get(i).click();
							rt.keyPress(KeyEvent.VK_TAB);
							rt.keyRelease(KeyEvent.VK_TAB);
							rt.keyPress(KeyEvent.VK_TAB);
							rt.keyRelease(KeyEvent.VK_TAB);
							Double gCAmt = Double.parseDouble(getData("UBS_CAmount"));
							String dCAmt = dformat.format(gCAmt);
							Double CAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value").replace(",","").trim());
							String vCAmt = dformat.format(CAmt);
							if (vCAmt.equals(dCAmt)) {
								ReportHelper.logReportStatus(LogStatus.PASS, "Charge Amount -'"+gCAmt+"' verified successfully");
							} else {
								ReportHelper.logReportStatus(LogStatus.FAIL, "Charge amount verification is not successful");
							}
							rt.keyPress(KeyEvent.VK_TAB);
							rt.keyRelease(KeyEvent.VK_TAB);
							waitFor(3000);
						} else if(AccEntLst.get(i).getAttribute("value").equals(getData("UBS_VATAcct"))) {
							waitFor(2000);
							scrollDown(AccEntLst.get(i));
							index=i+1;
							String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
							if (DRTag.equals("C") ) {
								ReportHelper.logReportStatus(LogStatus.PASS, "VAT Account and CR Tag  verified successfully");
							} else {
								ReportHelper.logReportStatus(LogStatus.FAIL, "VAT Account and CR Tag  has not been verified successfully");
							}
							AccEntLst.get(i).click();
							rt.keyPress(KeyEvent.VK_TAB);
							rt.keyRelease(KeyEvent.VK_TAB);
							rt.keyPress(KeyEvent.VK_TAB);
							rt.keyRelease(KeyEvent.VK_TAB);
							Double gVAmt = Double.parseDouble(getData("UBS_VATAmount"));
							String dVAmt = dformat.format(gVAmt);
							Double VATAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value").replace(",","").trim());
							String vVAmt = dformat.format(VATAmt);
							if (vVAmt.equals(dVAmt)) {
								ReportHelper.logReportStatus(LogStatus.PASS, "VAT Amount -'"+vVAmt+"' verified successfully");
							} else {
								ReportHelper.logReportStatus(LogStatus.FAIL, "VAT amount verification is not successful");
							}
							rt.keyPress(KeyEvent.VK_TAB);
							rt.keyRelease(KeyEvent.VK_TAB);
							waitFor(3000);
						}
					}

			}

			Thread.sleep(2000);
			driver.switchTo().defaultContent();*/
		} catch (Exception e) {
			logReportStatus(LogStatus.FAIL,"Verification of transaction details - Retail IB failed due to '"+e.getMessage()+"'");
		}

	}

	/**********************************************************************************************************************************/
    /*
     * Function Name : AccountEntries_BeneWithinMeem
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/
	public static void AccountEntries_BeneWithinMeem() {

		try {
			initPageObjects();
			getLatestDriver();
			WebDriver driver =getLatestDriver();

			switchDFrame(po_UBS.Frame2_UBS_Contracts);
			waitFor(2000);
			DecimalFormat dformat=new DecimalFormat("0.00");
			List <WebElement> AccEntLst = driver.findElements(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr/td[4]/input"));
			int AccEntCnt = AccEntLst.size();
			int index=0;
			Robot rt = new Robot();
			Double ChkCAmt=0.00;
			if (getData("BeneType").equals("WITHIN MEEM") ) {
				for (int i=0;i<AccEntCnt;i++) {
					System.out.println(AccEntLst.get(i).getAttribute("value"));
					if(AccEntLst.get(i).getAttribute("value").equals(getData("UBS_DebAcct"))) {
						index=i+1;
						String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
						String CcyTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[7]/input")).getAttribute("value");
						if (DRTag.equals("D") && CcyTag.equals(getData("UBS_DebitCurrency"))) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Debit Account and DR & Currency Tag verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Debit Account and DR & Currency Tag has not been verified successfully");
						}
						AccEntLst.get(i).click();
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						Double DebAmt = Double.parseDouble(getData("PaymentAmount"));
						String dDebtAmt = dformat.format(DebAmt);
						String dDebtAmt2 = "";
						if (getData("BeneCurrency").equalsIgnoreCase("FCY")) {
							Double DebAmt2 = Double.parseDouble(getData("CreditAmount"));
							dDebtAmt2 = dformat.format(DebAmt2);
							Double FCYAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[8]/input")).getAttribute("value"));
							String vFCYAmt = dformat.format(FCYAmt);
							String ExcRate = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[9]/input")).getAttribute("value");
							if (vFCYAmt.equals(dDebtAmt) && ExcRate.equals(getData("UBS_ExcRate"))) {
								ReportHelper.logReportStatus(LogStatus.PASS,"Foreign Currency Amount and Exchange Rate have been validated as '"+vFCYAmt+"' and '"+ExcRate+"'");
							} else {
								ReportHelper.logReportStatus(LogStatus.FAIL,"Foreign Currency Amount and Exchange Rate have not been validated as '"+vFCYAmt+"' and '"+ExcRate+"'");
							}
						}
						Double ChkDAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value").replace(",","").trim());
						String DrAmt = dformat.format(ChkDAmt);
						if (DrAmt.equals(dDebtAmt) || DrAmt.equals(dDebtAmt2)) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Debit Amount - '"+DrAmt+"' verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Debit Amount verification is not successful");
						}
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						waitFor(2000);
					} else if(AccEntLst.get(i).getAttribute("value").equals(getData("UBS_CredAcct"))) {
						index=i+1;
						String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
						String CcyTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[7]/input")).getAttribute("value");
						if (DRTag.equals("C") && CcyTag.equals(getData("UBS_CreditCurrency"))) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Credit Account and CR & Currency Tag verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Credit Account and CR & Currency Tag has not been verified successfully");
						}
						AccEntLst.get(i).click();
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						Double CredAmt = Double.parseDouble(getData("PaymentAmount"));
						String dCredAmt = dformat.format(CredAmt);
						ChkCAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value").replace(",","").trim());
						String CrAmt = dformat.format(ChkCAmt);
						String dCredAmt2 = "";
						if (getData("BeneCurrency").equalsIgnoreCase("FCY")) {
							Double CredAmt2 = Double.parseDouble(getData("CreditAmount"));
							dCredAmt2 = dformat.format(CredAmt2);
						}
						if (CrAmt.equals(dCredAmt) || CrAmt.equals(dCredAmt2)) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Credit Amount -'"+CrAmt+"' verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Credit amount verification is not successful");
						}
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						waitFor(2000);
					}
				}
			}

			Thread.sleep(2000);
			driver.switchTo().defaultContent();

		} catch (Exception e) {
			ReportHelper.logReportStatus(LogStatus.FAIL,"Account Entries for Beneficiary Within Meem '"+e.getMessage()+"'");
		}

	}

	/**********************************************************************************************************************************/
    /*
     * Function Name : AcctEntries_BeneWithinKSAandInterntl_SAR
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/
	public static void AcctEntries_BeneWithinKSAandInterntl_SAR() {

		try {
			initPageObjects();
			getLatestDriver();
			WebDriver driver = getLatestDriver();

			switchDFrame(po_UBS.Frame2_UBS_Contracts);
			waitFor(2000);
			DecimalFormat dformat=new DecimalFormat("0.00");
			List <WebElement> AccEntLst = driver.findElements(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr/td[4]/input"));
			int AccEntCnt = AccEntLst.size();
			int index=0;
			Robot rt = new Robot();
			Double ChkCAmt=0.00,gTxnAmt=0.00;
			if ((getData("BeneType").equals("INTERNATIONAL") && getData("BeneCurrency").equalsIgnoreCase("SAR"))|| (getData("BeneType").equals("WITHIN KSA")) ) {
				for (int i = 0; i < AccEntCnt; i++) {
					System.out.println(AccEntLst.get(i).getAttribute("value"));
					AccEntLst.get(i).click();
					if (AccEntLst.get(i).getAttribute("value").equals(getData("UBS_DebAcct"))) {
						index = i + 1;
						String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[5]/input")).getAttribute("value");
						String CcyTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[7]/input")).getAttribute("value");
						if (DRTag.equals("D") && CcyTag.equals(getData("UBS_DebitCurrency"))) {
							scrollDown(AccEntLst.get(i));
							ReportHelper.logReportStatus(LogStatus.PASS, "Debit Account and DR & Currency Tag verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Debit Account and DR & Currency Tag has not been verified successfully");
						}
						AccEntLst.get(i).click();
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						Double DebtAmt = 0.00;
						if (getData("BeneCurrency").equalsIgnoreCase("SAR")) {
							DebtAmt = Double.parseDouble(getData("PaymentAmount"));
						} else if (getData("BeneCurrency").equalsIgnoreCase("FCY")) {
							DebtAmt = Double.parseDouble(getData("CreditAmount"));
							Double TxnAmt = Double.parseDouble(getData("TotalTxnAmount"));
							String vTxnAmt = dformat.format(TxnAmt);
							Double FCYAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[8]/input")).getAttribute("value"));
							String vFCYAmt = dformat.format(FCYAmt);
							String ExcRate = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[9]/input")).getAttribute("value");
							if (vFCYAmt.equals(vTxnAmt) && ExcRate.equals(getData("UBS_ExcRate"))) {
								ReportHelper.logReportStatus(LogStatus.PASS, "Foreign Currency Amount and Exchange Rate have been validated as '" + vFCYAmt + "' and '" + ExcRate + "'");
							} else {
								ReportHelper.logReportStatus(LogStatus.FAIL, "Foreign Currency Amount and Exchange Rate have not been validated as '" + vFCYAmt + "' and '" + ExcRate + "'");
							}
						}
						Double CAmt = Double.parseDouble(getData("UBS_CAmount"));
						//Double FeeAmt = Double.parseDouble(getData("UBS_FeeAmount"));
						Double VATAmt = Double.parseDouble(getData("UBS_VATAmount"));
						Double DebAmt = DebtAmt + CAmt + VATAmt;
						//Double DebAmt = DebtAmt+CAmt+FeeAmt+VATAmt;
						String dDebtAmt = dformat.format(DebAmt);
						Double ChkDAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[10]/input")).getAttribute("value").replace(",", "").trim());
						String DrAmt = dformat.format(ChkDAmt);
						if (DrAmt.equals(dDebtAmt)) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Debit Amount - '" + DrAmt + "' verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Debit Amount verification is not successful");
						}
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						waitFor(3000);
					} else if (AccEntLst.get(i).getAttribute("value").equals(getData("UBS_CredAcct"))) {
						waitFor(2000);
						scrollDown(AccEntLst.get(i));
						index = i + 1;
						String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[5]/input")).getAttribute("value");
						String CcyTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[7]/input")).getAttribute("value");
						if (DRTag.equals("C") && CcyTag.equals(getData("UBS_CreditCurrency"))) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Credit Account and CR & Currency Tag verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Credit Account and CR & Currency Tag has not been verified successfully");
						}
						AccEntLst.get(i).click();
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						Double CredAmt = 0.00;
						if (getData("BeneCurrency").equalsIgnoreCase("FCY")) {
							CredAmt = Double.parseDouble(getData("CreditAmount"));
						} else {
							CredAmt = Double.parseDouble(getData("PaymentAmount"));
						}
						String dCredAmt = dformat.format(CredAmt);
						ChkCAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[10]/input")).getAttribute("value").replace(",", "").trim());
						String CrAmt = dformat.format(ChkCAmt);
						if (CrAmt.equals(dCredAmt)) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Credit Amount -'" + CrAmt + "' verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Credit amount verification is not successful");
						}
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						waitFor(3000);
					} else if (AccEntLst.get(i).getAttribute("value").equals(getData("UBS_ChgeAcct"))) {
						waitFor(2000);
						scrollDown(AccEntLst.get(i));
						index = i + 1;
						String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[5]/input")).getAttribute("value");
						if (DRTag.equals("C")) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Charge Account and CR Tag verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Charge Account and CR Tag  has not been verified successfully");
						}
						AccEntLst.get(i).click();
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						Double gCAmt = Double.parseDouble(getData("UBS_CAmount"));
						String dCAmt = dformat.format(gCAmt);
						Double CAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[10]/input")).getAttribute("value").replace(",", "").trim());
						String vCAmt = dformat.format(CAmt);
						if (vCAmt.equals(dCAmt)) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Charge Amount -'" + gCAmt + "' verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Charge amount verification is not successful");
						}
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						waitFor(3000);
					/*} *//*else if(AccEntLst.get(i).getAttribute("value").equals(getData("UBS_FeeAcct"))) {
						index=i+1;
						String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
						if (DRTag.equals("C") ) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Fee Account and CR Tag  verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Fee Account and CR Tag  has not been verified successfully");
						}
						AccEntLst.get(i).click();
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						Double gFAmt = Double.parseDouble(getData("UBS_FeeAmount"));
						String dFAmt = dformat.format(gFAmt);
						Double FeeAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value").replace(",","").trim());
						String vFAmt = dformat.format(FeeAmt);
						if (vFAmt.equals(dFAmt)) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Fee Amount -'"+vFAmt+"' verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Fee amount verification is not successful");
						}
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						waitFor(3000);*/
					} else if (AccEntLst.get(i).getAttribute("value").equals(getData("UBS_VATAcct"))) {
						waitFor(2000);
						scrollDown(AccEntLst.get(i));
						index = i + 1;
						String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[5]/input")).getAttribute("value");
						if (DRTag.equals("C")) {
							ReportHelper.logReportStatus(LogStatus.PASS, "VAT Account and CR Tag  verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "VAT Account and CR Tag  has not been verified successfully");
						}
						AccEntLst.get(i).click();
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						Double gVAmt = Double.parseDouble(getData("UBS_VATAmount"));
						String dVAmt = dformat.format(gVAmt);
						Double VATAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr[" + index + "]/td[10]/input")).getAttribute("value").replace(",", "").trim());
						String vVAmt = dformat.format(VATAmt);
						if (vVAmt.equals(dVAmt)) {
							ReportHelper.logReportStatus(LogStatus.PASS, "VAT Amount -'" + vVAmt + "' verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "VAT amount verification is not successful");
						}
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						waitFor(3000);
					}
				}
			}

			Thread.sleep(2000);
			driver.switchTo().defaultContent();

		} catch (Exception e) {
			ReportHelper.logReportStatus(LogStatus.FAIL,"Account entries for Beneficiary Within KSA & International from SAR '"+e.getMessage()+"'");
		}
	}

	/**********************************************************************************************************************************/
    /*
     * Function Name : AcctEntries_BeneInterntl_FCY
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/
	public static void AcctEntries_BeneInterntl_FCY() {

		try {
			initPageObjects();
			getLatestDriver();
			WebDriver driver = getLatestDriver();

			switchDFrame(po_UBS.Frame2_UBS_Contracts);
			waitFor(2000);
			DecimalFormat dformat=new DecimalFormat("0.00");
			List <WebElement> AccEntLst = driver.findElements(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr/td[4]/input"));
			int AccEntCnt = AccEntLst.size();
			int index=0;
			Robot rt = new Robot();
			Double ChkCAmt=0.00;
			if (getData("BeneType").equals("INTERNATIONAL") && getData("BeneCurrency").equalsIgnoreCase("FCY") ) {
				for (int i=0;i<AccEntCnt;i++) {
					System.out.println(AccEntLst.get(i).getAttribute("value"));
					AccEntLst.get(i).click();
					if(AccEntLst.get(i).getAttribute("value").equals(getData("UBS_DebAcct"))) {
						index=i+1;
						String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
						String CcyTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[7]/input")).getAttribute("value");
						if (DRTag.equals("D") && CcyTag.equals(getData("UBS_DebitCurrency"))) {
							scrollDown(AccEntLst.get(i));
							ReportHelper.logReportStatus(LogStatus.PASS, "Debit Account and DR & Currency Tag verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Debit Account and DR & Currency Tag has not been verified successfully");
						}
						AccEntLst.get(i).click();
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						Double TxnAmt = Double.parseDouble(getData("TotalTxnAmount"));
						String vTxnAmt = dformat.format(TxnAmt);
						Double FCYAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[8]/input")).getAttribute("value"));
						String vFCYAmt = dformat.format(FCYAmt);
						String ExcRate = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[9]/input")).getAttribute("value");
						if (vFCYAmt.equals(vTxnAmt) && ExcRate.equals(getData("UBS_DebExcRate"))) {
							ReportHelper.logReportStatus(LogStatus.PASS,"Foreign Currency Amount and Exchange Rate have been validated as '"+vFCYAmt+"' and '"+ExcRate+"'");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL,"Foreign Currency Amount and Exchange Rate have not been validated as '"+vFCYAmt+"' and '"+ExcRate+"'");
						}
						Double CAmt = Double.parseDouble(getData("UBS_CAmount"));
						Double VATAmt = Double.parseDouble(getData("UBS_VATAmount"));
						Double DebtAmt = Double.parseDouble(getData("CreditAmount")) * Double.parseDouble(getData("UBS_CredExcRate"));
						Double DebAmt = DebtAmt+CAmt+VATAmt;
						String dDebtAmt = dformat.format(DebAmt);
						Double ChkDAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value").replace(",","").trim());
						String DrAmt = dformat.format(ChkDAmt);
						if (DrAmt.equals(dDebtAmt)) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Debit Amount - '"+DrAmt+"' verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Debit Amount verification is not successful");
						}
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						waitFor(3000);
					} else if(AccEntLst.get(i).getAttribute("value").equals(getData("UBS_CredAcct"))) {
						waitFor(2000);
						scrollDown(AccEntLst.get(i));
						index=i+1;
						String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
						String CcyTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[7]/input")).getAttribute("value");
						if (DRTag.equals("C") && CcyTag.equals(getData("UBS_CreditCurrency"))) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Credit Account and CR & Currency Tag verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Credit Account and CR & Currency Tag has not been verified successfully");
						}
						AccEntLst.get(i).click();
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						Double CredAmt = Double.parseDouble(getData("CreditAmount"));
						String dCredAmt = dformat.format(CredAmt);
						Double FCYAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[8]/input")).getAttribute("value"));
						String vFCYAmt = dformat.format(FCYAmt);
						String ExcRate = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[9]/input")).getAttribute("value");
						if (vFCYAmt.equals(dCredAmt) && ExcRate.equals(getData("UBS_CredExcRate"))) {
							ReportHelper.logReportStatus(LogStatus.PASS,"Foreign Currency Amount and Exchange Rate have been validated as '"+vFCYAmt+"' and '"+ExcRate+"'");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL,"Foreign Currency Amount and Exchange Rate have not been validated as '"+vFCYAmt+"' and '"+ExcRate+"'");
						}
						Double dCrAmount = CredAmt*Double.parseDouble(getData("UBS_CredExcRate"));
						String dCredAmt2 = dformat.format(dCrAmount);
						ChkCAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value").replace(",","").trim());
						String CrAmt = dformat.format(ChkCAmt);
						if (CrAmt.equals(dCredAmt2)) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Credit Amount -'"+CrAmt+"' verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Credit amount verification is not successful");
						}
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						waitFor(3000);
					} else if(AccEntLst.get(i).getAttribute("value").equals(getData("UBS_ChgeAcct"))) {
						waitFor(2000);
						scrollDown(AccEntLst.get(i));
						index=i+1;
						String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
						if (DRTag.equals("C") ) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Charge Account and CR Tag verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Charge Account and CR Tag  has not been verified successfully");
						}
						AccEntLst.get(i).click();
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						Double gCAmt = Double.parseDouble(getData("UBS_CAmount"));
						String dCAmt = dformat.format(gCAmt);
						Double CAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value").replace(",","").trim());
						String vCAmt = dformat.format(CAmt);
						if (vCAmt.equals(dCAmt)) {
							ReportHelper.logReportStatus(LogStatus.PASS, "Charge Amount -'"+gCAmt+"' verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "Charge amount verification is not successful");
						}
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						waitFor(3000);
					} else if(AccEntLst.get(i).getAttribute("value").equals(getData("UBS_VATAcct"))) {
						waitFor(2000);
						scrollDown(AccEntLst.get(i));
						index=i+1;
						String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
						if (DRTag.equals("C") ) {
							ReportHelper.logReportStatus(LogStatus.PASS, "VAT Account and CR Tag  verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "VAT Account and CR Tag  has not been verified successfully");
						}
						AccEntLst.get(i).click();
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						Double gVAmt = Double.parseDouble(getData("UBS_VATAmount"));
						String dVAmt = dformat.format(gVAmt);
						Double VATAmt = Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value").replace(",","").trim());
						String vVAmt = dformat.format(VATAmt);
						if (vVAmt.equals(dVAmt)) {
							ReportHelper.logReportStatus(LogStatus.PASS, "VAT Amount -'"+vVAmt+"' verified successfully");
						} else {
							ReportHelper.logReportStatus(LogStatus.FAIL, "VAT amount verification is not successful");
						}
						rt.keyPress(KeyEvent.VK_TAB);
						rt.keyRelease(KeyEvent.VK_TAB);
						waitFor(3000);
					}
				}

			}

			Thread.sleep(2000);
			driver.switchTo().defaultContent();
		} catch (Exception e) {
			ReportHelper.logReportStatus(LogStatus.FAIL,"Account entries for Beneficiary International from FCY '"+e.getMessage()+"'");
		}

	}
	/**********************************************************************************************************************************/
    /*
     * Function Name : SearchREFNo_InternationalFT
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

	public static void SearchREFNo_InternationalFT() {

		try
		{
			initPageObjects();
			getLatestDriver();
			WebDriver driver =getLatestDriver();

			click(po_UBS.Button_UBS_EnterQuery);
			waitFor(1000);

			//driver.switchTo().frame("ifr_LaunchWin");
			driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@title='Contract Input (SWIFT) ']")));
			sendKeys(po_UBS.Input_UBS_RDIContRefNo,getData("UBS_ReferenceNumber"));
			waitFor(1000);
			driver.switchTo().defaultContent();

			click(po_UBS.Button_UBS_ExecuteQuery);
			waitFor(10000);

			//driver.switchTo().frame("ifr_LaunchWin");
			driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@title='Contract Input (SWIFT) - Transaction Branch Code ::: 200']")));
			String intDebitAmount = getText(po_UBS.Input_UBS_DebitAmount).replace(",","").trim();
			DecimalFormat dformat=new DecimalFormat("0.00");
			Double tDebitAmt = Double.parseDouble(getData("ConversionAmount"));
			String ChkDebAmt = dformat.format(tDebitAmt);

			String intCreditAmount = getText(po_UBS.Input_UBS_CreditAmount).replace(",","").trim();
			Double tCredAmt = Double.parseDouble(getData("PaymentAmount"));
			String ChkCredAmt = dformat.format(tCredAmt);
			String DRAcct = getText(po_UBS.Input_UBS_DebitAccount);
			String CRAcct = getText(po_UBS.Input_UBS_CreditAccount);
			String DrBrnch = getText(po_UBS.Input_UBS_DebitBranch);
			String CrBrnch = getText(po_UBS.Input_UBS_CreditBranch);

			String IBANNum = getText(po_UBS.Input_UBS_BeneIBANAccount).replace("/","").trim();

			if ( intDebitAmount.equals(ChkDebAmt) && DRAcct.equals(getData("DebitAccount"))) {
				ReportHelper.logReportStatus(LogStatus.PASS,"Debit Amount '"+ChkDebAmt+"' of DrAcctNo '"+getData("DebitAccount")+"' verified correctly");
			} else {
				ReportHelper.logReportStatus(LogStatus.FAIL,"Debit Amount '"+ChkDebAmt+"' of DrAcctNo '"+getData("DebitAccount")+"' verified is not correct");
			}

			if (intCreditAmount.equals(ChkCredAmt)  && IBANNum.equals(getData("BeneficiaryAccount")) && CRAcct.equals(getData("CreditAccount"))) {
				ReportHelper.logReportStatus(LogStatus.PASS,"Credit Amount '"+ChkCredAmt+"' of CrAcctNo '"+getData("CreditAccount")+"' verified correctly");
			} else {
				ReportHelper.logReportStatus(LogStatus.FAIL,"Credit Amount '"+ChkCredAmt+"' of CrAcctNo '"+getData("CreditAccount")+"' verified is not correct");
			}

			if ( DrBrnch.equals(getData("DebitBranch")) && CrBrnch.equals(getData("CreditBranch"))  ) {
				ReportHelper.logReportStatus(LogStatus.PASS,"Debit Branch '"+DrBrnch+ "' & Credit Branch '"+CrBrnch+ " verified correctly");
			} else {
				ReportHelper.logReportStatus(LogStatus.FAIL,"Debit Branch '"+DrBrnch+ "' & Credit Branch '"+CrBrnch+ " verified is not correct");
			}

			driver.switchTo().defaultContent();

		} catch(Exception e)
		{
			logReportStatus(LogStatus.FAIL,"Search Transaction Reference Number failed due to '"+e.getMessage()+"'");
		}
	}

	/**********************************************************************************************************************************/
    /*
     * Function Name : VerifyContractDetails_InternationalFT
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

	public static void VerifyContractDetails_InternationalFT()  {

		try {
			WebDriver driver=getLatestDriver();
			waitFor(1000);
			//driver.switchTo().defaultContent();
			//driver.switchTo().frame("ifr_LaunchWin");
			driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@title='Contract Input (SWIFT) - Transaction Branch Code ::: 200']")));

			click(po_UBS.Button_UBS_Event);
			waitFor(2000);
			driver.switchTo().defaultContent();

			switchDFrame(po_UBS.Frame2_UBS_Contracts);
			ReportHelper.logReportStatus(LogStatus.PASS,"Event displayed in the screen successfully");
/*			for (WebElement ele:po_UBS.ChkBox_UBS_Event){
				if (ele.isSelected()==false) {
					ele.click();
				}
			}*/
			List <WebElement> EventLst = driver.findElements(By.xpath("//div[@id='tableContainer']//tbody/tr/td[4]"));
			int EventCnt = EventLst.size();
			for (int i=1;i<EventCnt+1;i++) {
				String EventCode = driver.findElement(By.xpath("//div[@id='tableContainer']//tbody/tr["+i+"]/td[4]/input")).getAttribute("value");
				System.out.println(EventCode);
				if (EventCode.equals("INIT")) {
					driver.findElement(By.xpath("//div[@id='tableContainer']//tbody/tr["+i+"]/td[4]")).click();
					break;
				}
			}
			waitFor(1000);
			ReportHelper.logReportStatus(LogStatus.PASS,"Event details entered successfully");
			click(po_UBS.Button_UBS_AccountEntries);
			waitFor(2000);
			driver.switchTo().defaultContent();
			//ReportHelper.logReportStatus(LogStatus.PASS,"Account entries displayed in the screen successfully");
			switchDFrame(po_UBS.Frame2_UBS_Contracts);

			DecimalFormat dformat=new DecimalFormat("0.00");

			Double tPaymtAmt=0.0,tConvAmt=0.0;
			tPaymtAmt = Double.parseDouble(getData("PaymentAmount"));
			tConvAmt = Double.parseDouble(getData("ConversionAmount"));

			//String ExcRate = po_UBS.Input_UBS_ExcRate.get(1).getAttribute("value");


/*			LCYAmt = Double.parseDouble(po_UBS.Input_UBS_LCYAmt.get(1).getAttribute("value"));
			FCYAmt = Double.parseDouble(po_UBS.Input_UBS_FCYAmt.get(1).getAttribute("value"));
			String AccCcy = po_UBS.Input_UBS_AccCcy.get(1).getAttribute("value");*/


/*			if((tPaymtAmt.equals(FCYAmt)) && (tConvAmt.equals(LCYAmt)) && (AccCcy.equals(Ccy)) && ExcRate.equals(getData("ExchangeRate")) ) {
				ReportHelper.logReportStatus(LogStatus.PASS,"Debit Currency and Credit Currency verified successfully");
				po_UBS.Input_UBS_CrAcct.get(1).click();
				Robot rt = new Robot();
				rt.keyPress(KeyEvent.VK_TAB);
				rt.keyRelease(KeyEvent.VK_TAB);
				rt.keyPress(KeyEvent.VK_TAB);
				rt.keyRelease(KeyEvent.VK_TAB);

				logReportStatus(LogStatus.PASS, "Debit and credit details verified successfully");
			} else {
				logReportStatus(LogStatus.FAIL, "Debit and Credit details verified successfully");
			}*/


			List <WebElement> AccEntLst = driver.findElements(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr/td[4]/input"));
			int AccEntCnt = AccEntLst.size();
			int index=0;
			Robot rt = new Robot();
			for (int i=0;i<AccEntCnt;i++) {
				//String AcctNum = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+i+"]/td[4]")).getText();
				System.out.println(AccEntLst.get(i).getAttribute("value"));
				if (AccEntLst.get(i).getAttribute("value").equals(getData("UBS_ChgeAcctNo"))) {
					index=i+1;
					String CRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
					if (CRTag.equals("C")) {
						ReportHelper.logReportStatus(LogStatus.PASS, "Fee Charge Account and CR & Currency Tag verified successfully");
					} else {
						ReportHelper.logReportStatus(LogStatus.FAIL, "Fee Charge Account and CR & Currency Tag has not been verified successfully");
					}
					AccEntLst.get(i).click();
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					if (driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value").equals(getData("UBS_CAmount"))) {
						ReportHelper.logReportStatus(LogStatus.PASS, "Fee Charge Amount verified successfully");
					} else {
						ReportHelper.logReportStatus(LogStatus.FAIL, "Fee Charge Amount verification is not successful");
					}
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					waitFor(1000);
				} else if(AccEntLst.get(i).getAttribute("value").equals(getData("UBS_VATAcctNo"))) {
					index=i+1;
					String CRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
					if (CRTag.equals("C")) {
						ReportHelper.logReportStatus(LogStatus.PASS, "VAT Account and CR & Currency Tag verified successfully");
					} else {
						ReportHelper.logReportStatus(LogStatus.FAIL, "VAT Account and CR & Currency Tag has not been verified successfully");
					}
					AccEntLst.get(i).click();
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB)
					;

					//System.out.println(dformat.format(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value"))+"  "+getData("UBSVATAmt"));
					if (dformat.format(Double.parseDouble(driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value"))).equals(getData("UBSVATAmt"))) {
						ReportHelper.logReportStatus(LogStatus.PASS, "VAT Amount verified successfully");
																} else {
						ReportHelper.logReportStatus(LogStatus.FAIL, "VAT Amount verification is not successful");
					}
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					waitFor(1000);
				}  else if(AccEntLst.get(i).getAttribute("value").equals(getData("UBSDebitAccount"))) {
					index=i+1;
					String DRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
					String CcyTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[7]/input")).getAttribute("value");
					if (DRTag.equals("D") && CcyTag.equals(getData("DebitCurrency"))) {
						ReportHelper.logReportStatus(LogStatus.PASS, "Debit Account and DR & Currency Tag verified successfully");
					} else {
						ReportHelper.logReportStatus(LogStatus.FAIL, "Debit Account and DR & Currency Tag has not been verified successfully");
					}
					AccEntLst.get(i).click();
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					Double TotTxnAmt = Double.parseDouble(getData("UBS_CAmount"))+Double.parseDouble(getData("UBSVATAmt"))+Double.parseDouble(getData("ConversionAmount"));
					String TotDebAmt = dformat.format(TotTxnAmt);
					if (driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value").equals(TotDebAmt)) {
						ReportHelper.logReportStatus(LogStatus.PASS, "Debit Amount verified successfully");
					} else {
						ReportHelper.logReportStatus(LogStatus.FAIL, "Debit amount verification is not successful");
					}
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					waitFor(1000);
				} else if(AccEntLst.get(i).getAttribute("value").equals(getData("UBSCreditAccount"))) {
					index=i+1;
					String CRTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[5]/input")).getAttribute("value");
					String CcyTag = driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[7]/input")).getAttribute("value");
					if (CRTag.equals("C") && CcyTag.equals(getData("CreditCurrency"))) {
						ReportHelper.logReportStatus(LogStatus.PASS, "Credit Account and CR & Currency Tag verified successfully");
					} else {
						ReportHelper.logReportStatus(LogStatus.FAIL, "Credit Account and CR & Currency Tag has not been verified successfully");
					}
					AccEntLst.get(i).click();
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					// Credit Currency & Exchange Rate
					String Ccy = getData("CreditCurrency");
					String ExcRate = getData("ExchangeRate");
					if (driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[10]/input")).getAttribute("value") .equals(getData("ConversionAmount")) && driver.findElement(By.xpath("//*[@id='BLK_ACCOUNT']/tbody/tr["+index+"]/td[9]/input")).getAttribute("value").equals(ExcRate)) {
						ReportHelper.logReportStatus(LogStatus.PASS, "Credit Amount and Exchange rate  verified successfully");
					} else {
						ReportHelper.logReportStatus(LogStatus.FAIL, "Credit amount verification is not successful");
					}
					rt.keyPress(KeyEvent.VK_TAB);
					rt.keyRelease(KeyEvent.VK_TAB);
					waitFor(1000);
				}
			}

			Thread.sleep(2000);
			driver.switchTo().defaultContent();

		} catch (Exception e) {
			logReportStatus(LogStatus.FAIL,"Verification of transaction details - Retail IB failed due to '"+e.getMessage()+"'");
		}

	}

/*	*//**
	 * This method is used to click New button in Main Screen
	 *
	 * @throws Exception
	 *//*
	public static void clickQueryButton() {
		try {
			initPageObjects();
			getLatestDriver();
			//WebDriver driver = getLatestDriver();

			click(po_UBS.BTN_Query);
			ReportHelper.logReportStatus(LogStatus.PASS, "New button clicked'");
		} catch (Exception e) {
			ReportHelper.logReportStatus(LogStatus.FAIL, "New Button has not been clicked '" + e.getMessage() + "'");
		}

	}
	public static void clickNewbutton() {
		try {
			initPageObjects();
			getLatestDriver();
			WebDriver driver = getLatestDriver();

			click(po_UBS.newBtn);
			ReportHelper.logReportStatus(LogStatus.PASS, "New button clicked'");
		} catch (Exception e) {
			ReportHelper.logReportStatus(LogStatus.FAIL, "New Button has not been clicked '" + e.getMessage() + "'");
		}

	}

	*//**
	 * This mehod is used to enter Transaction Branch code
	 *
	 * @throws Exception
	 *//*

	public static void enterBranchCode() {
		try {
			initPageObjects();
			getLatestDriver();
			WebDriver driver = getLatestDriver();

			driver.switchTo().defaultContent();
			driver.switchTo().frame("ifr_LaunchWin");
			driver.switchTo().frame("ifrSubScreen");


			po_UBS.branchCode.clear();
			String branchCode = getData("BranchCode");

			po_UBS.branchCode.sendKeys(branchCode);
			po_UBS.okBtn.click();

			ReportHelper.logReportStatus(LogStatus.PASS, "Entered the branch code is'" + branchCode);
		} catch (Exception e) {
			ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to Enter the branch code '" + e.getMessage() + "'");
		}

	}

	public static void EnterReferceAndclickQuery() {
		try {
			initPageObjects();
			getLatestDriver();
			WebDriver driver = getLatestDriver();

			driver.switchTo().defaultContent();
			driver.switchTo().frame("ifr_LaunchWin");
			sendKeys(po_UBS.TXT_contctRefernce,getData("ContactRefernceNumber"));
			driver.switchTo().defaultContent();
			click(po_UBS.BTN_ExecuteQuery);
			click(po_UBS.BTN_Authorize);
			//Thread.sleep(6000);

			ReportHelper.logReportStatus(LogStatus.PASS, "Clicked  the product populate  button");
		} catch (Exception e) {
			ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click product populate buttton '" + e.getMessage() + "'");
		}

	}
	*//**
	 * This mehod is used to enter the  Product and populate the product values in Fund transfer screen
	 *
	 * @throws Exception
	 *//*

	public static void enterProductAndClickPopulate() {
		try {
			initPageObjects();
			getLatestDriver();

			WebDriver driver = getLatestDriver();

			driver.switchTo().defaultContent();
			driver.switchTo().frame("ifr_LaunchWin");

			po_UBS.productTxt.sendKeys("FOLC");
			po_UBS.productSearchBtn.click();

			driver.switchTo().defaultContent();
			driver.switchTo().frame("ifr_LaunchWin");
			driver.switchTo().frame("ifrSubScreen");


			String productName = getData("Product Name");
			po_UBS.productValue.sendKeys(productName);
			po_UBS.fetchValuesBtn.click();

			driver.findElement(By.xpath("//tbody//tr[1]//td[1]//a[text()='" + productName + "']")).click();
			ReportHelper.logReportStatus(LogStatus.PASS, "Enter the product is" + productName);

			driver.switchTo().defaultContent();
			driver.switchTo().frame("ifr_LaunchWin");
			po_UBS.prdpopulateBtn.click();
			//Thread.sleep(6000);

			ReportHelper.logReportStatus(LogStatus.PASS, "Clicked  the product populate  button");
		} catch (Exception e) {
			ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click product populate buttton '" + e.getMessage() + "'");
		}

	}

	*//**
	 * This method is used to enter the debit  and credit details in the screen
	 *
	 * @throws Exception
	 *//*

	public static void enterDebitAndCreditDetails() {
		try {
			initPageObjects();
			getLatestDriver();
			WebDriver driver = getLatestDriver();

			driver.switchTo().defaultContent();
			driver.switchTo().frame("ifr_LaunchWin");

			driver.findElement(By.xpath("//div[input[@title='Debit Account' and @class='TXTstd']]//button[contains(@title,'List')]")).click();

			driver.switchTo().defaultContent();
			driver.switchTo().frame("ifr_LaunchWin");
			driver.switchTo().frame("ifrSubScreen");

			String debitAccNo = getData("DebitAccountNumber");

			//driver.findElement(By.xpath("//input[@class='TXTstd' and @id='1']")).sendKeys("200");

			WebElement element = driver.findElement(By.xpath("//input[@class='TXTstd' and @name='2']"));
			element.clear();
			element.sendKeys(debitAccNo);

			driver.findElement(By.xpath("//span[@class='ICOsearch']")).click();
			Thread.sleep(2000);

			driver.findElement(By.xpath("//td//a[@class='Astd' and text()='" + debitAccNo + "']")).click();
			ReportHelper.logReportStatus(LogStatus.PASS, "Debit Account number is selected");


			driver.switchTo().defaultContent();
			driver.switchTo().frame("ifr_LaunchWin");

			driver.findElement(By.xpath("//div[input[@title='Credit Account' and @class='TXTstd']]//button[contains(@title,'List')]")).click();


			driver.switchTo().defaultContent();
			driver.switchTo().frame("ifr_LaunchWin");
			driver.switchTo().frame("ifrSubScreen");

			String creditAccNo = getData("CreditAccountNumber");

			//	driver.findElement(By.xpath("//input[@class='TXTstd' and @id='1']")).sendKeys("200");

			WebElement element2 = driver.findElement(By.xpath("//input[@class='TXTstd' and @name='2']"));
			element2.clear();
			element2.sendKeys(creditAccNo);

			driver.findElement(By.xpath("//span[@class='ICOsearch']")).click();
			Thread.sleep(2000);

			driver.findElement(By.xpath("//td//a[@class='Astd' and text()='" + creditAccNo + "']")).click();
			ReportHelper.logReportStatus(LogStatus.PASS, "Credit Account number is selected");


			driver.switchTo().defaultContent();
			driver.switchTo().frame("ifr_LaunchWin");

			po_UBS.txt_CreditAmount.sendKeys(getData("CreditAmount"));
			ReportHelper.logReportStatus(LogStatus.PASS, "Credit Amount is Entered");

			By customerInitiated = By.xpath("//select[@class='SELstd' and @label_value='Customer Initiated']");

			Select select = new Select(driver.findElement(customerInitiated));
			select.selectByVisibleText("Yes");


		} catch (Exception e) {
			ReportHelper.logReportStatus(LogStatus.FAIL, "Debit and Credit Amount details are not entered properly'" + e.getMessage() + "'");
		}

	}

	public static void clickBenificaryIBANANDCountry() {
		try {

			initPageObjects();
			getLatestDriver();
			WebDriver driver = getLatestDriver();

			driver.switchTo().defaultContent();
			driver.switchTo().frame("ifr_LaunchWin");

			By IBANSearch = By.xpath("//div[input[@title='Beneficiary IBAN' and @class='TXTstd']]//button[contains(@title,'List')]");
			driver.findElement(IBANSearch).click();

			//Benificary Name
			driver.switchTo().defaultContent();
			driver.switchTo().frame("ifr_LaunchWin");
			driver.switchTo().frame("ifrSubScreen");

			String benificaryIBAN = getData("BenficaryIBAN");

			By benificaryName = By.xpath("//input[@class='TXTstd' and @name='1']");
			driver.findElement(benificaryName).clear();
			driver.findElement(benificaryName).sendKeys(benificaryIBAN);

			po_UBS.fetchValuesBtn.click();

			driver.findElement(By.xpath("//td//a[text()='" + benificaryIBAN + "']")).click();

			driver.switchTo().defaultContent();
			driver.switchTo().frame("ifr_LaunchWin");

			WebElement enrichBtn = driver.findElement(By.xpath("//button[@title='Enrich']"));

			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].scrollIntoView(true);", enrichBtn);

			System.out.println("Scrolled  successfully");


			String countryValue = getData("Countrycode");

			List<WebElement> list = driver.findElements(By.xpath("//div//input[@title='Country' and @class='TXTstd']"));
			list.get(1).sendKeys(countryValue);

			ReportHelper.logReportStatus(LogStatus.PASS, "Entered the Country code is:" + countryValue);



		} catch (Exception e) {
			ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to enter Benficary IBAN and country code'" + e.getMessage() + "'");
		}
	}

	public static void clickBenificaryIBANANDCountry_domestic() {
		try {

			initPageObjects();
			getLatestDriver();
			WebDriver driver = getLatestDriver();

			driver.switchTo().defaultContent();
			driver.switchTo().frame("ifr_LaunchWin");

			//	By IBANSearch = By.xpath("//div[input[@title='Beneficiary IBAN' and @class='TXTstd']]//button[contains(@title,'List')]");
			*//*driver.findElement(IBANSearch).click();

			//Benificary Name
			driver.switchTo().defaultContent();
			driver.switchTo().frame("ifr_LaunchWin");
			driver.switchTo().frame("ifrSubScreen");*//*

			String benificaryIBAN = getData("BenficaryIBAN");
*//*
			By benificaryName = By.xpath("//input[@class='TXTstd' and @name='1']");
			driver.findElement(benificaryName).clear();
			driver.findElement(benificaryName).sendKeys(benificaryIBAN);

			po_UBS.fetchValuesBtn.click();

			driver.findElement(By.xpath("//td//a[text()='" + benificaryIBAN + "']")).click();*//*
*//*
			driver.switchTo().defaultContent();
			driver.switchTo().frame("ifr_LaunchWin");*//*
			driver.findElement(By.xpath("//input[@id='BLK_CONTRACT_DETAILS__ULTBEN1']")).sendKeys(benificaryIBAN);
			driver.findElement(By.xpath("//input[@id='BLK_CONTRACT_DETAILS__ULTBEN2']")).sendKeys(getData("Benef_name"));
			driver.findElement(By.xpath("//input[@id='BLK_CONTRACT_DETAILS__ULTBEN3']")).sendKeys(getData("BAddress1"));
			driver.findElement(By.xpath("//input[@id='BLK_CONTRACT_DETAILS__ULTBEN4']")).sendKeys(getData("BAddress2"));
			driver.findElement(By.xpath("//input[@id='BLK_CONTRACT_DETAILS__ULTBEN5']")).sendKeys(getData("BAddress3"));
			WebElement enrichBtn = driver.findElement(By.xpath("//button[@title='Enrich']"));

			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].scrollIntoView(true);", enrichBtn);

			System.out.println("Scrolled  successfully");


		*//*	String countryValue = getData("Countrycode");

			List<WebElement> list = driver.findElements(By.xpath("//div//input[@title='Country' and @class='TXTstd']"));
			list.get(1).sendKeys(countryValue);*//*

			//ReportHelper.logReportStatus(LogStatus.PASS, "Entered the Country code is:" + countryValue);



		} catch (Exception e) {
			ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to enter Benficary IBAN and country code'" + e.getMessage() + "'");
		}
	}

	public static void clickEnrichAndSave() {
		try {

			initPageObjects();
			getLatestDriver();
			WebDriver driver = getLatestDriver();

			driver.switchTo().defaultContent();
			driver.switchTo().frame("ifr_LaunchWin");

			WebElement enrichBtn = driver.findElement(By.xpath("//button[@title='Enrich']"));


			enrichBtn.click();


			String debitAmount = po_UBS.txt_debitAmount.getText();

			System.out.println(debitAmount);

			driver.switchTo().defaultContent();
			driver.switchTo().frame("ifr_LaunchWin");
			po_UBS.PartyDetails.click();
			po_UBS.purposeofTransfer.sendKeys(getData("Purpose"));
			driver.switchTo().defaultContent();
			po_UBS.saveBtn.click();

			driver.switchTo().defaultContent();
			driver.switchTo().frame("ifr_LaunchWin");
			driver.switchTo().frame("ifr_AlertWin");

			String Msg = driver.findElement(By.xpath("//h1[text()='Override Message']")).getText();
			System.out.println("The Message is:" + Msg);


			if (po_UBS.acceptBtn.isDisplayed()) {
				po_UBS.acceptBtn.click();
				ReportHelper.logReportStatus(LogStatus.PASS, "Accept button clicked successfully");
			} else {
				ReportHelper.logReportStatus(LogStatus.FAIL, "Accept button has not been clicked");
			}


			driver.switchTo().defaultContent();
			driver.switchTo().frame("ifr_LaunchWin");
			driver.switchTo().frame("ifr_AlertWin");


			String successMsg = po_UBS.SuccessMsg.getText();
			ReportHelper.logReportStatus(LogStatus.PASS, successMsg);

			po_UBS.okBtn.click();
			driver.switchTo().defaultContent();

		} catch (Exception e) {
			ReportHelper.logReportStatus(LogStatus.FAIL, "Transaction Messge got Failed due to'" + e.getMessage() + "'");
		}
	}


	public static void ExitAllActiveWindowsall() {

		try {
			WebDriver driver = getLatestDriver();

			List<WebElement> frame2;
			frame2 = driver.findElements(By.cssSelector("#ifr_LaunchWin"));
			for(int i=frame2.size()-1;i>=0;i--)
			{driver.switchTo().defaultContent();
				driver.switchTo().frame(frame2.get(i));
				driver.findElement(By.cssSelector("#WNDbuttons")).click();


			}

		} catch (Exception e) {
			logReportStatus(LogStatus.FAIL, "Exit all active windows failed due to '" + e.getMessage() + "'");
		}

	}

	public static void UBS_authorize()
	{
		WebDriver driver = getLatestDriver();
		driver.switchTo().defaultContent();
		driver.switchTo().frame("ifr_LaunchWin");
		driver.switchTo().frame("ifrSubScreen");
		click(po_UBS.BTN_Authorize_all);


		driver.switchTo().defaultContent();
		driver.switchTo().frame("ifr_LaunchWin");
		driver.switchTo().frame("ifrSubScreen");
		driver.switchTo().frame("ifr_AlertWin");
		String msg=driver.findElement(By.xpath("//table[@id='ERRTBL']//span[@class='SPNtbltwoC']")).getText();
		if(msg.equalsIgnoreCase("Successfully Authorized"))
		{
			logReportStatus(LogStatus.PASS, "Authorised Done Successfully");
		}
	}*/

}
