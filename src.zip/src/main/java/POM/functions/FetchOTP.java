package POM.functions;

import FrameWork.helpers.ReportHelper;
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import static FrameWork.library.Util.waitFor;

public class FetchOTP {

    public  static String getOTP(){


        System.setProperty("webdriver.chrome.driver","./src/main/resources/drivers/chromedriver");

        WebDriver webDriver=new ChromeDriver();
        webDriver.get("http://10.14.30.37:899/Home/Index");
        waitFor(5000);        webDriver.findElement(By.id("btnGetOTP")).click();
        waitFor(6000);
        String otp=webDriver.findElement(By.xpath("//*[@id='body']/section/table/tbody/tr[2]/td[2]")).getText();
        ReportHelper.logReportStatus(LogStatus.PASS,"OTP -'"+otp+"' generated successfully");
        waitFor(1000);
        webDriver.quit();
        return otp;

    }

}
