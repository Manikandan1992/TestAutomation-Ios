package POM.functions;
import FrameWork.helpers.DriverHelper;
import FrameWork.helpers.Helper;
import FrameWork.helpers.ReportHelper;
import POM.pageobjects.po_LoginPage;
import POM.pageobjects.po_RDI_IB;
import com.relevantcodes.extentreports.LogStatus;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import static FrameWork.helpers.Helper.getData;
import static FrameWork.helpers.Helper.loginCredentials;
import static FrameWork.helpers.Helper.saveTestDataToDb;
import static FrameWork.helpers.ReportHelper.forceScreenShot;
import static FrameWork.helpers.ReportHelper.logReportStatus;
import static FrameWork.helpers.ReportHelper.logReportStatusInBlue;
import static FrameWork.library.Util.*;
import static FrameWork.library.Util.getLatestDriver;
import static FrameWork.listeners.PreReq.getURL;
import static FrameWork.listeners.po_BaseClass.drvr;
import static POM.pageobjects.po_RDI_IB.Button_GoalArrowDown;
import static org.openqa.selenium.support.PageFactory.initElements;

public class fn_RDI_IB {
    public static void initPageObjects() throws Exception {
        initElements(drvr, po_RDI_IB.class);
        logReportStatusInBlue(LogStatus.INFO, "Method: " + Thread.currentThread().getStackTrace()[2].getMethodName());
        getLatestDriver();
    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : all_Login_RDI
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void all_Login_RDI() {
        try {
            String loginType = DriverHelper.environmentURL;
            //String loginUserType = loginType.split("~")[0] + "~" + loginType.split("~")[1];
            String application = loginType.split("~")[1];
            String urlType = loginType.split("~")[2];
            fn_allLogin.Login_RDI(loginType, application + "~" + urlType);
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,e.getMessage());
        }
    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : Select_MenuItem
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void Select_MenuItem(String strMenuItem){
        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver=getLatestDriver();
            switchDFrame(1);
            WebElement PageHeader=null;
            switch (strMenuItem){

                case "TALK TO MEEM":
                    po_RDI_IB.Button_TalktoMeem.click();
                    PageHeader=po_RDI_IB.WebElement_TalktoMeem;
                    break;

                case "PROFILES":
                    po_RDI_IB.Button_Profile.click();
                    PageHeader=po_RDI_IB.Button_Profile;
                    break;

                case "TOOLS":
                    po_RDI_IB.Button_Tools.click();
                    PageHeader=po_RDI_IB.WebElement_TalktoMeem;
                    break;

                case "PRODUCTS":
                    po_RDI_IB.Button_Products.click();
                    PageHeader=po_RDI_IB.WebElement_Products;
                    break;

                case "SECURITY TIPS":
                    po_RDI_IB.Button_Security.click();
                    PageHeader=po_RDI_IB.WebElement_SecurityTips;
                    break;

                case "INVITE FRIENDS":
                    po_RDI_IB.Button_Invite.click();
                    PageHeader=po_RDI_IB.WebElement_InviteFriends;
                    break;

                case "FAVOURITE":
                    po_RDI_IB.Button_Favorites.click();
                    PageHeader=po_RDI_IB.WebElement_Favourite;
                    break;

                case "TRANSFER":
                    po_RDI_IB.Button_TransferPayment.click();
                    PageHeader=po_RDI_IB.WebElement_TransferPayment;
                    break;

                case "YOUR ACCOUNTS":
                    po_RDI_IB.Button_Accounts.click();
                    PageHeader=po_RDI_IB.WebElement_Accounts;
                    break;

                case "YOUR BUDGET":
                    po_RDI_IB.Button_Budgets.click();
                    PageHeader=po_RDI_IB.WebElement_Budgets;
                    break;

                case "EMERGENCY CASH":
                    po_RDI_IB.Button_EmergencyCash.click();
                    PageHeader=po_RDI_IB.WebElement_EmergencyCash;
                    break;

                default:
                    ReportHelper.logReportStatus(LogStatus.FAIL,"Menu Item proivded '" +strMenuItem+"' is not present in home page, kindly check");
            }

            waitFor(1000);

/*            driver.switchTo().defaultContent();
            driver.switchTo().frame(1);*/

            if (elemExist(PageHeader)) {
                ReportHelper.logReportStatus(LogStatus.PASS,"Click on the Menu Item '" +strMenuItem+"',Page of '"+strMenuItem+"' is displayed succesfully");
            } else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Click on the Menu Item '" +strMenuItem+"',Page of '"+strMenuItem+"' is not displayed");
            }
        } catch (Exception e){
            ReportHelper.logReportStatus(LogStatus.FAIL,"Navigation through Menu Item failed due to '"+e.getMessage()+"'");
        }
    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : FCYAcct_MoveMoneyFromOnePacktoFCY
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void FCYAcct_MoveMoneyFromOnePacktoFCY() {

        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver=getLatestDriver();
            driver.switchTo().defaultContent();
            driver.switchTo().frame(1);
            driver.findElement(By.xpath("//a[@id='Recipients-btn']")).click();

/*            switchDFrame(1);
            click(po_RDI_IB.Menu_TransferAndPaymt);*/
            waitFor(1000);

            // fund transfer displayed
            if (elemExist(driver.findElement(By.xpath("//span/div[contains(text(),'Select the account you want to move money from')]")))) {
                ReportHelper.logReportStatus(LogStatus.PASS,"Move Money is displayed in the Transfer & Payments screen successfully");
                driver.findElement(By.xpath("//span/div[contains(text(),'Select the account you want to move money from')]")).click();
                //click(po_RDI_IB.Select_MoveMoneyFrom);
                waitFor(1000);

                driver.findElement(By.xpath("//div[@class='dd wrapper-dropdown-5 ddfromaccount wrapper-dropdown-padding active']//div[@id='aUD1']")).click();
                //click(po_RDI_IB.DropDownLst_OnePack);
                ReportHelper.logReportStatus(LogStatus.PASS,"Move money from the account -'One Pack' entered successfully");
                waitFor(1000);

                driver.findElement(By.xpath("//span/div[contains(text(),'Select the account you want to move money to')]")).click();
                //click(po_RDI_IB.Select_MoveMoneyTo);
                waitFor(1000);

                driver.findElement(By.xpath("//div[@class='dd wrapper-dropdown-5 ddtoaccount wrapper-dropdown-padding active']//div[@id='aUD2']")).click();
                //click(po_RDI_IB.DropDownLst_FCY);
                ReportHelper.logReportStatus(LogStatus.PASS,"Move money to the account -'FCY' entered successfully");
                waitFor(1000);

                String SrceAmt = getData("SourceAmount");
                sendKeys(po_RDI_IB.Input_SourceAmount,SrceAmt);
                /*sendKeys(po_RDI_IB.Input_ExchangeRate,"");
                sendKeys(po_RDI_IB.Input_DestinationAmount,"");*/

                ReportHelper.logReportStatus(LogStatus.PASS,"All mandatory details entered successfully");
                driver.findElement(By.xpath("//a[contains(.,'Immediately')]")).click();
                //click(po_RDI_IB.Button_Immediately);
                waitFor(7000);

                String CreditAmt = driver.findElement(By.xpath("//*[@id='slideContainer']//tr[5]/td[2]/span")).getText();

                if (!CreditAmt.equals(0.00)) {
                    ReportHelper.logReportStatus(LogStatus.PASS,"Move Money details added successfully");
                    driver.findElement(By.xpath("//div[@id='ctl00_ContentPlaceHolder2_upConfirm']//a[contains(text(),'Confirm')]")).click();
                    //click(po_RDI_IB.Button_MoveMoney_Confirm);
                    waitFor(8000);

                    String TxnMsg = driver.findElement(By.xpath("//span[contains(text(),'Your funds transfer has been successful.')]")).getText();
                    if (TxnMsg.contains("Your funds transfer has been successful")) {
                        ReportHelper.logReportStatus(LogStatus.PASS,TxnMsg);
                        driver.findElement(By.xpath("//li/a[contains(.,'Done')]")).click();
                        //click(po_RDI_IB.Button_Done);
                    } else {
                        ReportHelper.logReportStatus(LogStatus.FAIL,TxnMsg);
                    }

                }else {
                    ReportHelper.logReportStatus(LogStatus.FAIL,"Move Money from One Pack to FCY account added is not successful");
                }

            }
            else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Move money displayed in the Transfer & Payments screen is not successful");
            }

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"FCY Account - Move Money failed due to '" +e.getMessage()+"'");
        }

    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : FCY_Create
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void FCY_Create() {

        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver = getLatestDriver();
            driver.switchTo().defaultContent();
            driver.switchTo().frame(1);
            //switchDFrame(1);
            //click(po_RDI_IB.Menu_Products);
            driver.findElement(By.xpath("//div/a[contains(.,'Products')]")).click();
            waitFor(5000);

            if (elemExist(driver.findElement(By.xpath("//div/a[contains(.,'Foreign Currency Account')]")))) {
                //if (elemExist(po_RDI_IB.Menu_ForeignCcyAcct)) {
                ReportHelper.logReportStatus(LogStatus.PASS,"Foreign Currency Account displayed in the submenu successfully");
                driver.findElement(By.xpath("//div/a[contains(.,'Foreign Currency Account')]")).click();
                //click(po_RDI_IB.Menu_ForeignCcyAcct);
                waitFor(3000);

                driver.findElement(By.xpath("//div[@class='currency']/ul/li[contains(.,'"+getData("ForeignCcy")+"')]")).click();
                waitFor(1000);
                driver.findElement(By.xpath("//div[@class='statement']/ul/li[contains(.,'"+getData("Statement")+"')]")).click();
                waitFor(5000);
                String FCYAcctName = driver.findElement(By.xpath("//input[@name='ctl00$ContentPlaceHolder2$txtAccountLabel']")).getAttribute("value");
                saveTestDataToDb("AccountName",FCYAcctName);
                ReportHelper.logReportStatus(LogStatus.PASS,"Foreign Currency Account details entered successfully");

                //click(po_RDI_IB.Button_Confirm);
                driver.findElement(By.xpath("//a[contains(text(),'Confirm')]")).click();
                waitFor(5000);

                if (elemExist(driver.findElement(By.xpath("//a[contains(text(),'Accept')]")))) {
                    //if (elemExist(po_RDI_IB.Button_Accept)) {
                    ReportHelper.logReportStatus(LogStatus.PASS,"Foreign Currency Account displayed in the confirmation page successfully");
                    driver.findElement(By.xpath("//a[contains(text(),'Accept')]")).click();
                    //click(po_RDI_IB.Button_Accept);
                    waitFor(10000);

                    System.out.println(getData("AccountName"));
                    if (driver.findElement(By.xpath("//div/h3[contains(text(),'"+getData("AccountName")+"')]")).isDisplayed()) {
                        ReportHelper.logReportStatus(LogStatus.PASS,"Foreign currency account created successfully");
                    }else {
                        ReportHelper.logReportStatus(LogStatus.FAIL,"Foreign currency account is not created successfully");
                    }
                } else {
                    ReportHelper.logReportStatus(LogStatus.FAIL,"Foreign Currency Account displayed in the confirmation page is not successful");
                }
            } else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Foreign Currency Account displayed in the submenu is not successful");
            }

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Creation of FCY failed due to '"+e.getMessage()+"'");
        }

    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : FCYAcct_MoveMoneyFromFCYToOnePack
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void FCYAcct_MoveMoneyFromFCYToOnePack() {

        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver=getLatestDriver();
            driver.switchTo().defaultContent();
            driver.switchTo().frame(1);
            driver.findElement(By.xpath("//a[@id='Recipients-btn']")).click();

/*            switchDFrame(1);
            click(po_RDI_IB.Menu_TransferAndPaymt);*/
            waitFor(1000);

            // fund transfer displayed
            if (elemExist(driver.findElement(By.xpath("//span/div[contains(text(),'Select the account you want to move money from')]")))) {
                ReportHelper.logReportStatus(LogStatus.PASS,"Move Money is displayed in the Transfer & Payments screen successfully");
                driver.findElement(By.xpath("//span/div[contains(text(),'Select the account you want to move money from')]")).click();
                //click(po_RDI_IB.Select_MoveMoneyFrom);
                waitFor(1000);

                driver.findElement(By.xpath("//div[@class='dd wrapper-dropdown-5 ddfromaccount wrapper-dropdown-padding active']//div[@id='aUD2']")).click();
                //click(po_RDI_IB.DropDownLst_OnePack);
                ReportHelper.logReportStatus(LogStatus.PASS,"Move money from the FCY account entered successfully");
                waitFor(1000);

                driver.findElement(By.xpath("//span/div[contains(text(),'Select the account you want to move money to')]")).click();
                //click(po_RDI_IB.Select_MoveMoneyTo);
                waitFor(1000);

                driver.findElement(By.xpath("//div[@class='dd wrapper-dropdown-5 ddtoaccount wrapper-dropdown-padding active']//div[@id='aUD1']")).click();
                //click(po_RDI_IB.DropDownLst_FCY);
                ReportHelper.logReportStatus(LogStatus.PASS,"Move money to the OnePack Account entered successfully");
                waitFor(10000);

                String SrceAmt = getData("SourceAmount");
                sendKeys(po_RDI_IB.Input_SourceAmount,SrceAmt);
                /*sendKeys(po_RDI_IB.Input_ExchangeRate,"");
                sendKeys(po_RDI_IB.Input_DestinationAmount,"");*/

                ReportHelper.logReportStatus(LogStatus.PASS,"All mandatory details entered successfully");
                driver.findElement(By.xpath("//a[contains(.,'Immediately')]")).click();
                //click(po_RDI_IB.Button_Immediately);
                waitFor(7000);

                String CreditAmt = driver.findElement(By.xpath("//*[@id='slideContainer']//tr[5]/td[2]/span")).getText();
                System.out.println(CreditAmt);

                if (!CreditAmt.equals(0.00)) {
                    ReportHelper.logReportStatus(LogStatus.PASS,"Move Money details added successfully");
                    driver.findElement(By.xpath("//div[@id='ctl00_ContentPlaceHolder2_upConfirm']//a[contains(text(),'Confirm')]")).click();
                    //click(po_RDI_IB.Button_MoveMoney_Confirm);
                    waitFor(10000);

                    String TxnMsg = driver.findElement(By.xpath("//span[contains(text(),'Your funds transfer has been successful.')]")).getText();
                    if (TxnMsg.contains("YOUR FUNDS TRANSFER HAS BEEN SUCCESSFUL")) {
                        ReportHelper.logReportStatus(LogStatus.PASS,TxnMsg);
                        driver.findElement(By.xpath("//li/a[contains(.,'Done')]")).click();
                        //click(po_RDI_IB.Button_Done);
                    } else {
                        ReportHelper.logReportStatus(LogStatus.FAIL,TxnMsg);
                    }

                }else {
                    ReportHelper.logReportStatus(LogStatus.FAIL,"Move Money from One Pack to FCY account added is not successful");
                }

            }
            else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Move money displayed in the Transfer & Payments screen is not successful");
            }

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"FCY Account - Move Money failed due to '" +e.getMessage()+"'");
        }

    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : Bill_Create
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void Bill_Create() {

        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver = getLatestDriver();
            driver.switchTo().defaultContent();
            driver.switchTo().frame(1);

            //click(po_RDI_IB.Menu_TransferAndPaymt);
            driver.findElement(By.xpath("//a[@id='Recipients-btn']")).click();
            waitFor(1000);

            if (elemExist(driver.findElement(By.xpath("//a[contains(text(),'Bills')]")))) {
                //if (elemExist(po_RDI_IB.Menu_Bills)) {
                ReportHelper.logReportStatus(LogStatus.PASS, "Bills displayed in the submenu successfully");
                //click(po_RDI_IB.Menu_Bills);
                driver.findElement(By.xpath("//a[contains(text(),'Bills')]")).click();
                waitFor(2000);
                ReportHelper.logReportStatus(LogStatus.PASS,"Bills are displayed in the records successfully");

                // To add new bill button
                driver.findElement(By.xpath("//a[@id='addNewb']")).click();
                waitFor(5000);

                // create new button
                ReportHelper.logReportStatus(LogStatus.PASS,"Create new Bill displayed in the screen successfully");
                driver.findElement(By.xpath("//li[contains(text(),'Create New')]")).click();
                waitFor(2000);

                driver.findElement(By.xpath("//*[@id='1']/h6//p[contains(.,'Telecom')]")).click();
                waitFor(2000);
                driver.findElement(By.xpath("//h6//p[contains(.,'Mobily')]")).click();
                waitFor(2000);
                driver.findElement(By.xpath("//li[@id='GSM_CIP']")).click();
                waitFor(5000);

                int Sdsize = 15;
                for (int i=1;i<Sdsize;i++) {
                    if (driver.findElement(By.xpath("//*[@id='arrow-menu']/a[1]")).isEnabled()) {
                        waitFor(1000);
                        driver.findElement(By.xpath("//*[@id='arrow-menu']/a[1]")).click();
                        if (driver.findElement(By.xpath("//a[@id='ctl00_ContentPlaceHolder2_lbtnSaveConsumer']")).isDisplayed()) {
                            driver.findElement(By.xpath("//*[@id='arrow-menu']/a[1]")).click();
                            break;
                        }
                    }
                }

                driver.findElement(By.xpath("//li[@id='liField'][1]/input")).sendKeys(getData("ServiceLineNumber"));
                driver.findElement(By.xpath("//li[@id='liField'][2]/input ")).sendKeys(getData("BeneficiaryID"));
                driver.findElement(By.xpath("//li[@id='liField'][3]/ul/li[contains(.,'"+getData("BeneficiaryIDType")+"')]")).click();
                //li[@id='liField'][3]/ul/li[contains(.,'National ID')] - Bene ID Type

                driver.findElement(By.xpath("//input[@name='ctl00$ContentPlaceHolder2$txtConcumerAlias']")).sendKeys(getData("Alias"));
                ReportHelper.logReportStatus(LogStatus.PASS,"All bill details entered successfully");
                waitFor(2000);
                driver.findElement(By.xpath("//*[@id='arrow-menu']/a[1]")).click();
                driver.findElement(By.xpath("//div[@id='ctl00_ContentPlaceHolder2_upConsumerAdd']/div/ul/li/a[contains(text(),'Add')]")).click();
                waitFor(8000);

                if (elemExist(driver.findElement(By.xpath("//li/a[@id='lbtnOTPSentMobile']")))) {
                    ReportHelper.logReportStatus(LogStatus.PASS,"Authentication code displayed in the screen");
                    driver.findElement(By.xpath("//li/a[@id='lbtnOTPSentMobile']")).click();
                    waitFor(6000);

                    /*String OTP = FetchOTP.getOTP();
                    driver.findElement(By.xpath("//input[@name='ctl00$ContentPlaceHolder2$ucFAuth2$txtVerificationNumber']")).sendKeys(OTP);
                    driver.findElement(By.xpath("//li/a[contains(text(),'Confirm')]")).click();*/
                    sendKeys(po_LoginPage.Input_AuthenticationCode,FetchOTP.getOTP());
                    driver.findElement(By.xpath("//li/a[contains(text(),'Confirm')]")).click();
                    waitFor(15000);

                    if (driver.findElement(By.xpath("//li[contains(.,'"+getData("Alias")+"')]")).isDisplayed()) {
                        ReportHelper.logReportStatus(LogStatus.PASS,"Newly created bill details displayed in the list successfully");
                    }else {
                        ReportHelper.logReportStatus(LogStatus.FAIL,"Newly created bill details displayed in the list is not successful");
                    }

                } else {
                    ReportHelper.logReportStatus(LogStatus.FAIL,"Bill details added is not successful");
                }
            }else  {
                ReportHelper.logReportStatus(LogStatus.FAIL, "Bills displayed in the submenu is not successful");
            }
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Creation of Bills failed due to '"+e.getMessage()+"'");
        }
    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : Bill_Delete
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void Bill_Delete() {

        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver = getLatestDriver();
            driver.switchTo().defaultContent();
            driver.switchTo().frame(1);

            //click(po_RDI_IB.Menu_TransferAndPaymt);
            driver.findElement(By.xpath("//a[@id='Recipients-btn']")).click();
            waitFor(1000);

            if (elemExist(driver.findElement(By.xpath("//a[contains(text(),'Bills')]")))) {
                //if (elemExist(po_RDI_IB.Menu_Bills)) {
                ReportHelper.logReportStatus(LogStatus.PASS,"Bills displayed in the submenu successfully");
                //click(po_RDI_IB.Menu_Bills);
                driver.findElement(By.xpath("//a[contains(text(),'Bills')]")).click();
                waitFor(5000);

                List<WebElement> eleBills = driver.findElements(By.xpath("//*[@id='dvPayeesBeneficries1']/li"));
                int iBills = eleBills.size();
                //int iBills = po_RDI_IB.Table_FundTransferSummaryList.size();
                ReportHelper.logReportStatus(LogStatus.PASS,"Bills are displayed in the list successfully");
                boolean bFlag;
                bFlag = false;
                for (int i=1;i<iBills;i++) {
                    String tBillName = driver.findElement(By.xpath("//li["+i+"]//p[@id='billName']")).getText();
                    System.out.println(tBillName);
                    System.out.println(getData("BillName"));
                    if (tBillName.equals(getData("BillName"))) {
                        driver.findElement(By.xpath("//*[@id='dvPayeesBeneficries1']/li["+i+"]")).click();
                        waitFor(3000);
                        ReportHelper.logReportStatus(LogStatus.PASS,"Bill Name details displayed successfully");
                        driver.findElement(By.xpath("//*[@id='delete-btn']")).click();
                        //click(po_RDI_IB.Button_Delete);
                        waitFor(2000);
                        ReportHelper.logReportStatus(LogStatus.PASS,"Are you sure that you want to delete this bill? YES/NO");
                        driver.findElement(By.xpath("//a[contains(text(),'Yes')]")).click();
                        waitFor(5000);
                        ReportHelper.logReportStatus(LogStatus.PASS,"Bill name deleted successfully");
                        bFlag=true;
                        break;
                    }
                }

                if (bFlag=false) {
                    ReportHelper.logReportStatus(LogStatus.FAIL,"Bill name is not deleted successfully");
                }

            } else {

                ReportHelper.logReportStatus(LogStatus.FAIL,"Bills displayed in the submenu is not successful");
            }

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Bill Deletion failed due to '"+e.getMessage()+"'");
        }

    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : Beneficiary_Delete
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void Beneficiary_Delete() {
        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver = getLatestDriver();
            driver.switchTo().defaultContent();
            driver.switchTo().frame(1);

            //click(po_RDI_IB.Menu_TransferAndPaymt);
            driver.findElement(By.xpath("//a[@id='Recipients-btn']")).click();
            waitFor(1000);

            if (elemExist(driver.findElement(By.xpath("//a[contains(text(),'Beneficiaries')]")))) {
                //if (elemExist(po_RDI_IB.Menu_Beneficiaries)) {
                ReportHelper.logReportStatus(LogStatus.PASS, "Beneficiaries displayed in the submenu successfully");
                //click(po_RDI_IB.Menu_Beneficiaries);
                driver.findElement(By.xpath("//a[contains(text(),'Beneficiaries')]")).click();

                List<WebElement> eleBills = driver.findElements(By.xpath("//*[@id='dvPayeesBeneficries1']/li"));
                int iBene = eleBills.size();
                //int iBene = po_RDI_IB.Table_FundTransferSummaryList.size();
                ReportHelper.logReportStatus(LogStatus.PASS,"Beneficiaries are displayed in the records successfully");
                boolean bFlag;
                bFlag = false;
                for (int i=1;i<iBene;i++) {
                    String tBeneName = driver.findElement(By.xpath("//li["+i+"]//p[@id='BenName']")).getText();
                    System.out.println(tBeneName);
                    System.out.println(getData("BeneName"));
                    if (tBeneName.equals(getData("BeneName"))) {
                        driver.findElement(By.xpath("//*[@id='dvPayeesBeneficries1']/li["+i+"]")).click();
                        waitFor(3000);
                        ReportHelper.logReportStatus(LogStatus.PASS,"Beneficary Name details displayed successfully");
                        driver.findElement(By.xpath("//*[@id='delete-btn']")).click();
                        //click(po_RDI_IB.Button_Delete);
                        waitFor(2000);
                        ReportHelper.logReportStatus(LogStatus.PASS,"Are you sure that you want to delete this bill? YES/NO");
                        driver.findElement(By.xpath("//a[contains(text(),'Yes')]")).click();
                        waitFor(5000);
                        ReportHelper.logReportStatus(LogStatus.PASS,"Beneficiary name deleted successfully");
                        bFlag=true;
                        break;
                    }
                }

                if (bFlag=false) {
                    ReportHelper.logReportStatus(LogStatus.FAIL,"Beneficiary name is not deleted successfully");
                }

            }else {

                ReportHelper.logReportStatus(LogStatus.FAIL,"Beneficiaries displayed in the submenu is not successful");
            }

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Beneficiary Deletion failed due to '"+e.getMessage()+"'");
        }

    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : OnePack_AccountSumm
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void OnePack_AccountSumm() {
        try {
            initPageObjects();
            getLatestDriver();

            //WebDriver driver = getLatestDriver();
            switchDFrame(1);
            String AcctBal = getText(po_RDI_IB.TextArea_AcctBalance);

            if (!AcctBal.equals(0.00)) {
                ReportHelper.logReportStatus(LogStatus.PASS,"Available Balance -'"+AcctBal+"' of Meem OnePack displayed successfully");
                click(po_RDI_IB.WebElement_MeemOnePackAccount);
                waitFor(7000);

                if (getText(po_RDI_IB.TextArea_AccountStatus).equals(getData("AcctStatus"))) {
                    ReportHelper.logReportStatus(LogStatus.PASS,"Meem OnePack account details displayed correctly");

                    String IBAN = getText(po_RDI_IB.WebELement_IBANNumber).trim();
                    String AccountNo = IBAN.substring(13, IBAN.length());
                    saveTestDataToDb("AccountNum", AccountNo);
                    waitFor(1000);
                    String AvalBal = getText(po_RDI_IB.WebELement_AvailableBalance).replace(",","").trim();
                    saveTestDataToDb("AvailableBalance", AvalBal);
                    waitFor(1000);
                    String CurrBal = getText(po_RDI_IB.WebELement_CurrentAccount).replace("SAR","");
                    String gCurBal = CurrBal.replace(",","").trim();
                    saveTestDataToDb("CurrentBalance", gCurBal);

                    String SavBal = getText(po_RDI_IB.WebELement_SavingAccount).replace("SAR","");
                    String gSavBal = SavBal.replace(",","").trim();
                    saveTestDataToDb("SavingAcctBalance", gSavBal);

                } else {
                    ReportHelper.logReportStatus(LogStatus.FAIL,"Meem OnePack account details displayed is not successful");
                }

            } else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Available Balance of Meem OnePack is shown as '"+AcctBal+"'");
            }

        } catch (Exception e){
            ReportHelper.logReportStatus(LogStatus.FAIL,"OnePack Account summary failed due to '"+e.getMessage()+"'");
        }

    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : FCY_AccountSumm
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void FCY_AccountSumm() {
        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver = getLatestDriver();
/*            driver.switchTo().defaultContent();
            driver.switchTo().frame(1);*/
            switchDFrame(1);

            ReportHelper.logReportStatus(LogStatus.PASS,"Account summary displayed in the screen successfully");

            //div/h3[contains(.,'Foreign Currency account Creation')]
            driver.findElement(By.xpath("//div/h3[contains(.,'"+getData("FCYAccountName")+"')]")).click();
            waitFor(5000);

            if (elemExist(po_RDI_IB.WebELement_FCYIBAN)) {
                ReportHelper.logReportStatus(LogStatus.PASS,getData("FCYAccountName")+" details displayed successfully");

                String AllIBAN = getText(po_RDI_IB.WebELement_FCYIBAN);
                String IBAN= AllIBAN.replace("IBAN:","").trim();
                String AccountNo = IBAN.substring(13, IBAN.length());
                System.out.println(AccountNo);
                saveTestDataToDb("AccountNum", AccountNo);
                waitFor(1000);

                String AvalBal = getText(po_RDI_IB.WebELement_FCYBalance).trim();
                String AcctBal = AvalBal.replace(",","");
                saveTestDataToDb("FCYAccountBalance", AcctBal);
                waitFor(1000);

            } else {
                ReportHelper.logReportStatus(LogStatus.FAIL,getData("FCYAccountName")+" details displayed is not successful");
            }

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"FCY Account summary failed due to '"+e.getMessage()+"'");
        }
    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : FCYAcct_Close
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void FCYAcct_Close() {

        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver = getLatestDriver();
            driver.switchTo().defaultContent();
            driver.switchTo().frame(1);

            if (elemExist(driver.findElement(By.xpath("//div/div/h3[contains(.,'"+getData("AcctType")+"')]")))) {
                ReportHelper.logReportStatus(LogStatus.PASS,getData("AcctType")+" displayed in the account summary list");

                driver.findElement(By.xpath("//div/div/h3[contains(.,'"+getData("AcctType")+"')]")).click();
                waitFor(3000);

                ReportHelper.logReportStatus(LogStatus.PASS,getData("AcctType")+" details displayed successfully");
                driver.findElement(By.xpath("//a[contains(.,'ACCOUNT CLOSE')]")).click();
                waitFor(3000);

                driver.findElement(By.xpath("//textarea[@name='ctl00$ContentPlaceHolder2$ucAccountClose$txtPurpose']")).sendKeys(getData("TextArea_CloseAcct"));
                ReportHelper.logReportStatus(LogStatus.PASS,"Data entered successfully");

                driver.findElement(By.xpath("//a[contains(.,'proceed')]")).click();
                //waitTillElementIsVisible(driver.findElement(By.xpath("//div/div/h3[contains(.,'Accounts')]")));
                waitFor(18000);

                List<WebElement> AcctList = driver.findElements(By.xpath("//div/div/div/div/h3"));
                int CntAcct = AcctList.size();
                boolean AcctFlg;
                AcctFlg=false;
                for (int i=1;i<CntAcct;i++){
                    String gAcct = driver.findElement(By.xpath("//div/div["+i+"]/div/div/h3")).getText();
                    if (gAcct.equals(getData("AcctType"))) {
                        AcctFlg=true;
                        ReportHelper.logReportStatus(LogStatus.FAIL,"FCY Account details closed is not successful");
                        break;
                    }
                }

                if (AcctFlg=false) {
                    ReportHelper.logReportStatus(LogStatus.PASS,"FCY Account details have been closed successfully");
                }

/*                try {
                    driver.findElement(By.xpath("//div/div/h3[contains(.,'"+getData("AcctType")+"')]"));
                    ReportHelper.logReportStatus(LogStatus.FAIL,"FCY Account details closed is not successful");
                }catch(Exception e)
                {
                    ReportHelper.logReportStatus(LogStatus.PASS,"FCY Account details have been closed successfully");
                }*/
              /*  if (driver.findElement(By.xpath("//div/div/h3[contains(.,'"+getData("AcctType")+"')]")).isDisplayed()) {
                    ReportHelper.logReportStatus(LogStatus.FAIL,"FCY Account details closed is not successful");
                }else {

                    ReportHelper.logReportStatus(LogStatus.PASS,"FCY Account details have been closed successfully");
                }*/

            }

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"FCY Account Close failed due to '"+e.getMessage()+"'");
        }

    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : Govt_Payment
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void Govt_Payment() {

        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver = getLatestDriver();
            driver.switchTo().defaultContent();
            driver.switchTo().frame(1);

            //click(po_RDI_IB.Menu_TransferAndPaymt);
            driver.findElement(By.xpath("//a[@id='Recipients-btn']")).click();
            waitFor(1000);

            if (elemExist(driver.findElement(By.xpath("//a[contains(.,'Government Payment')]")))) {
                ReportHelper.logReportStatus(LogStatus.PASS,"Government Payment displayed in the submenu successfully");

                driver.findElement(By.xpath("//a[contains(.,'Government Payment')]")).click();
                waitFor(1000);
                ReportHelper.logReportStatus(LogStatus.PASS,"Government Payment displayed in the page successfully");
                driver.findElement(By.xpath("//div[@class='new-GovtFeeCompanies-viewport govtCarousel']/div")).click();
/*                Select Biller = new Select(driver.findElement(By.xpath("//div[@class='new-GovtFeeCompanies-viewport govtCarousel']/select[@id='GvotCompanies']")));
                Biller.selectByVisibleText(getData("SelBiller"));*/
                driver.findElement(By.xpath("//div[@class='new-GovtFeeCompanies-viewport govtCarousel']//ul/li[contains(.,'"+getData("SelBiller")+"')]")).click();

                waitFor(2000);

                driver.findElement(By.xpath("//div[@class='new-GovtFees-viewport govtCarousel']/div")).click();
/*                Select Servce = new Select(driver.findElement(By.xpath("//select[@id='GovtServices']")));
                Servce.selectByVisibleText(getData("SelService"));*/
                driver.findElement(By.xpath("//div[@class='new-GovtFees-viewport govtCarousel']//ul/li[contains(.,'"+getData("SelService")+"')]")).click();
                ReportHelper.logReportStatus(LogStatus.PASS,"Biller and services entered successfully");
                waitFor(1000);
                driver.findElement(By.xpath("//li[contains(.,'Payment')]")).click();
                waitFor(2000);

                driver.findElement(By.xpath("//ul[@id='dvFields']/li/input")).sendKeys(getData("IQAMAID"));
/*                Select Iqama_Duratn = new Select(driver.findElement(By.xpath("//select[@id='ulCustomFields']")));
                Iqama_Duratn.selectByVisibleText(getData("Iqama_Duration"));*/
                driver.findElement(By.xpath("//select[@id='ulCustomFields']")).click();
                driver.findElement(By.xpath("//select[@id='ulCustomFields']/option[contains(.,'"+getData("Iqama_Duration")+"')][1]")).click();
                ReportHelper.logReportStatus(LogStatus.PASS,"IQAMA details entered successfully");

                driver.findElement(By.xpath("//a[@id='SearchGovtFee']")).click();
                waitFor(5000);

                String TotAmtPay = driver.findElement(By.xpath("//div[@id='dvBillDetails']/h2//span[@id='lblAmountFormatted']")).getText();
                System.out.println(TotAmtPay);

                if (!TotAmtPay.equals("")) {
                    ReportHelper.logReportStatus(LogStatus.PASS,"Total Amount of government payment is displayed as '"+TotAmtPay+"'");
                    driver.findElement(By.xpath("//a[@id='PayFee']")).click();
                    waitFor(7000);

                    String SuccMsg = driver.findElement(By.xpath("//span[@id='lblFeeSuccess']")).getText();
                    if (SuccMsg.contains("YOUR FEE PAYMENT HAS BEEN PAID SUCCESSFULLY")) {
                        ReportHelper.logReportStatus(LogStatus.PASS,SuccMsg);
                        driver.findElement(By.xpath("//a[@id='lbtnOK']")).click();
                    } else {
                        ReportHelper.logReportStatus(LogStatus.FAIL,SuccMsg);
                    }
                } else {
                    String ErrMsg = driver.findElement(By.xpath("//span[@id='lblFeeError']")).getText();
                    ReportHelper.logReportStatus(LogStatus.FAIL,ErrMsg);
                }
            } else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Government Payment displayed in the submenu is not successful");
            }

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Government Payment failed due to '"+e.getMessage()+"'");
        }
    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : Beneficiary_Create
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void Beneficiary_Create() {

        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver = getLatestDriver();
            driver.switchTo().defaultContent();
            driver.switchTo().frame(1);

            //click(po_RDI_IB.Menu_TransferAndPaymt);
            driver.findElement(By.xpath("//a[@id='Recipients-btn']")).click();
            waitFor(1000);

            if (elemExist(driver.findElement(By.xpath("//a[contains(text(),'Beneficiaries')]")))) {
                //if (elemExist(po_RDI_IB.Menu_Beneficiaries)) {
                ReportHelper.logReportStatus(LogStatus.PASS, "Beneficiaries displayed in the submenu successfully");
                //click(po_RDI_IB.Menu_Beneficiaries);
                driver.findElement(By.xpath("//a[contains(text(),'Beneficiaries')]")).click();
                waitFor(2000);
                ReportHelper.logReportStatus(LogStatus.PASS,"Beneficiaries are displayed in the list successfully");

                driver.findElement(By.xpath("//a[@id='addNewb']")).click();
                waitFor(5000);

                // create new button
                ReportHelper.logReportStatus(LogStatus.PASS,"Create new Bill displayed in the screen successfully");

                driver.findElement(By.xpath("//ul/li[contains(text(),'"+getData("BeneType")+"')]")).click();
                waitFor(2000);

                driver.findElement(By.xpath("//input[@name='ctl00$ContentPlaceHolder2$txtIBAN']")).sendKeys(getData("IBANNumber"));
                ReportHelper.logReportStatus(LogStatus.PASS,"IBAN Number entered successfully");
                driver.findElement(By.xpath("//*[@id='add-new-accordion']//ul/li/img")).click();
                waitFor(2000);

                if (elemExist(driver.findElement(By.name("ctl00$ContentPlaceHolder2$txtFirstName")))) {
                    ReportHelper.logReportStatus(LogStatus.PASS, "Beneficiary fields after entering IBAN displayed successfully");
                    if(getData("BeneType").equals("Within KSA")) {
                        driver.findElement(By.name("ctl00$ContentPlaceHolder2$txtFirstName")).sendKeys(getData("BeneFirstNam"));
                        driver.findElement(By.name("ctl00$ContentPlaceHolder2$txtSecondName")).sendKeys(getData("BeneSecNam"));
                        driver.findElement(By.name("ctl00$ContentPlaceHolder2$txtLastName")).sendKeys(getData("BeneLastNam"));
                    } else if (getData("BeneType").equals("International")){
                        driver.findElement(By.name("ctl00$ContentPlaceHolder2$txtBeneSwift")).sendKeys("CTBAAU2S");
                    }
                    ReportHelper.logReportStatus(LogStatus.PASS,"All beneficiary details entered successfully");
                    waitFor(2000);

                    int Sdsize = 16;
                    for (int i=1;i<Sdsize;i++) {
                        if (driver.findElement(By.xpath("//*[@id='arrow-menu']/a[1]")).isEnabled()) {
                            waitFor(1000);
                            driver.findElement(By.xpath("//*[@id='arrow-menu']/a[1]")).click();
                            if (driver.findElement(By.xpath("//a[contains(.,'Confirm')]")).isDisplayed()) {
                                break;
                            }
                        }
                    }
                    driver.findElement(By.xpath("//*[@id='arrow-menu']/a[1]")).click();
                    driver.findElement(By.xpath("//a[contains(.,'Confirm')]")).click();
                    waitFor(8000);

                    if (elemExist(driver.findElement(By.xpath("//li/a[@id='lbtnOTPSentMobile']")))) {
                        ReportHelper.logReportStatus(LogStatus.PASS,"Authentication code displayed in the screen");
                        //driver.findElement(By.xpath("//li/a[@id='lbtnOTPSentMobile']")).click();
                        click(po_RDI_IB.Button_OTPSentMobile);
                        waitFor(6000);

                        sendKeys(po_LoginPage.Input_AuthenticationCode,FetchOTP.getOTP());
                        click(po_RDI_IB.Button_OTPConfirm);
                        //driver.findElement(By.xpath("//li/a[contains(text(),'Confirm')]")).click();
                        waitFor(15000);

                        String BeneName = getData("BeneFirstNam")+" "+getData("BeneLastNam");
                        if (driver.findElement(By.xpath("//div/h6/p[@id='BenName'][contains(.,'"+BeneName+"')]")).isDisplayed()) {
                            ReportHelper.logReportStatus(LogStatus.PASS,"Newly created beneficiary details added in the list successfully");
                        }else {
                            ReportHelper.logReportStatus(LogStatus.FAIL,"Newly created beneficiary details added in the list is not successful");
                        }
                    } else {
                        ReportHelper.logReportStatus(LogStatus.FAIL,"Authentication code displayed in the screen is not successful");
                    }
                } else {
                    ReportHelper.logReportStatus(LogStatus.FAIL,"Beneficiary Fields displayed after entering IBAN details is not successful");
                }
            }else  {
                ReportHelper.logReportStatus(LogStatus.FAIL, "Beneficiaries displayed in the submenu is not successful");
            }
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Creation of Beneficiary failed due to '"+e.getMessage()+"'");
        }
    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : SecSettng_PasswordChnge
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void SecSettng_PasswordChnge() {
        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver = getLatestDriver();
            driver.switchTo().defaultContent();
            driver.switchTo().frame(1);

            driver.findElement(By.xpath("//a[contains(text(),'Profiles')]")).click();
            waitFor(3000);

            if (elemExist(driver.findElement(By.xpath("//a[contains(text(),'Security Settings')]")))) {
                ReportHelper.logReportStatus(LogStatus.PASS,"Profiles displayed in the submenu successfully");
                driver.findElement(By.xpath("//a[contains(text(),'Security Settings')]")).click();
                waitFor(1000);
                ReportHelper.logReportStatus(LogStatus.PASS,"Password and Security Settings displayed successfully");
                driver.findElement(By.xpath("//div/h3[@id='ChangePassword']")).click();
                waitFor(1000);

                driver.findElement(By.name("ctl00$ContentPlaceHolder2$txtOldPassword")).sendKeys(getData("OldPassword"));
                driver.findElement(By.name("ctl00$ContentPlaceHolder2$txtNewPassword")).sendKeys(getData("NewPassword"));
                driver.findElement(By.name("ctl00$ContentPlaceHolder2$txtConfirmNewPassword")).sendKeys(getData("ConfirmNewPassword"));
                ReportHelper.logReportStatus(LogStatus.PASS,"All fields entered successfully");
                driver.findElement(By.xpath("//div[2]/ul/li/a[contains(text(),'confirm')]")).click();
                waitFor(3000);
                ReportHelper.logReportStatus(LogStatus.PASS,"Authentication code displayed in the screen");
                driver.findElement(By.xpath("//li/a[@id='lbtnOTPSentMobile']")).click();
                waitFor(1000);
                sendKeys(po_LoginPage.Input_AuthenticationCode,FetchOTP.getOTP());
                driver.findElement(By.xpath("//li/a[contains(text(),'Confirm')]")).click();
                waitFor(5000);

                String SuccMsg = driver.findElement(By.xpath("//span[@id='ctl00_ContentPlaceHolder2_ucFAuth2_imgbtn_Validator']")).getText();
                if (SuccMsg.contains("YOU HAVE SUCCESSFULLY CHANGED YOUR PASSWORD")) {
                    ReportHelper.logReportStatus(LogStatus.PASS,SuccMsg);
                    driver.findElement(By.xpath("//a[@id='ctl00_ContentPlaceHolder2_ucFAuth2_imgbtn']")).click();
                }else {
                    ReportHelper.logReportStatus(LogStatus.FAIL,SuccMsg);
                }

            } else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Profiles displayed in the submenu is not successful");
            }

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Security Setting - Password Change failed due to '"+e.getMessage()+"'");
        }

    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : CurrenciesCard_AcctDetails
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void CurrenciesCard_AcctDetails() {
        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver = getLatestDriver();
            driver.switchTo().defaultContent();
            driver.switchTo().frame(1);

            driver.findElement(By.xpath("//div/h3[contains(.,'"+getData("EmbossName")+"')]")).click();


            if (elemExist(driver.findElement(By.xpath("//div/h3[@id='MoreDetails']")))) {
                ReportHelper.logReportStatus(LogStatus.PASS,"Currencies Card displayed in the page successfully");
                driver.findElement(By.xpath("//div/h3[@id='MoreDetails']")).click();
                waitFor(1000);

                String AcctStatus = driver.findElement(By.xpath("//div[@id='divMoreDetails']//tr[4]/td[2]")).getText();
                if (AcctStatus.equals(getData("AcctStatus"))) {
                    ReportHelper.logReportStatus(LogStatus.PASS,"Account Status of Currencies Card is '"+AcctStatus+"'");
                }else {
                    ReportHelper.logReportStatus(LogStatus.FAIL,"Account Status of Currencies Card is '"+AcctStatus+"'");
                }

            }else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Currencies Card displayed is not successful");
            }

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Currencies Card account details failed due to'"+e.getMessage()+"'");
        }
    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : CardUpdateLimit
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void CardUpdateLimit() {

        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver = getLatestDriver();
            driver.switchTo().defaultContent();
            driver.switchTo().frame(1);

            //driver.findElement(By.xpath("//a[contains(text(),'Profiles')]")).click();
            click(po_RDI_IB.Menu_Profiles);
            waitFor(3000);

            if (elemExist(po_RDI_IB.SubMenu_SecSettings)) {
                ReportHelper.logReportStatus(LogStatus.PASS,"Profiles displayed in the submenu successfully");
                //driver.findElement(By.xpath("//a[contains(text(),'Security Settings')]")).click();
                click(po_RDI_IB.SubMenu_SecSettings);
                waitFor(1000);
                ReportHelper.logReportStatus(LogStatus.PASS,"Password and Security Settings displayed successfully");

                //driver.findElement(By.xpath("//div/h3[@id='Limits']")).click();
                click(po_RDI_IB.Select_CardUpdateLimit);
                waitFor(1000);

/*                driver.findElement(By.xpath("//div/input[@name='ctl00$ContentPlaceHolder2$amount11']")).clear();
                driver.findElement(By.xpath("//div/input[@name='ctl00$ContentPlaceHolder2$amount11']")).sendKeys();*/
                po_RDI_IB.Input_LimitAmount.clear();
                sendKeys(po_RDI_IB.Input_LimitAmount,getData("LimitAmount"));
                ReportHelper.logReportStatus(LogStatus.PASS,"Limit Amount entered successfully");

                click(po_RDI_IB.Button_UpdateLimit);
                waitFor(1000);
                //driver.findElement(By.xpath("//li/a[@id='lbtnOTPSentMobile']")).click();
                click(po_RDI_IB.Button_OTPSentMobile);
                waitFor(1000);
                sendKeys(po_LoginPage.Input_AuthenticationCode,FetchOTP.getOTP());

                //driver.findElement(By.xpath("//li/a[contains(text(),'Confirm')]")).click();
                click(po_RDI_IB.Button_OTPConfirm);
                waitFor(5000);



            }else {

            }
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Card Update Limit failed due to'"+e.getMessage()+"'");
        }
    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : BeneType_LimitValidation
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/
    public static void BeneType_LimitValidation() {

        try {
            initPageObjects();
            getLatestDriver();

            switchDFrame(1);
            click(po_RDI_IB.Menu_TransferAndPaymt);
            waitFor(1000);

            ReportHelper.logReportStatus(LogStatus.PASS, "Beneficiaries displayed in the submenu successfully");
            click(po_RDI_IB.Menu_Beneficiaries);
            waitFor(4000);
            //ReportHelper.logReportStatus(LogStatus.PASS, "Beneficiaries displayed in the summary list successfully");

            int iBene = po_RDI_IB.Table_Beneficiaries.size();
            WebDriver driver = getLatestDriver();
            boolean bFlag;
            bFlag = false;
            for (int i=1;i<iBene;i++) {
                String gBeneName = driver.findElement(By.xpath("//div[@id='BeneficiaryList']//ul/li["+i+"]//div/h6[1]/p")).getText();
                String gBeneTyp = driver.findElement(By.xpath("//div[@id='BeneficiaryList']//ul/li["+i+"]//div/h6[2]/p")).getText();
                String gBeneStatus = driver.findElement(By.xpath("//div[@id='BeneficiaryList']//ul/li["+i+"]//div/h6[3]/p")).getText();
                if (gBeneName.equals(getData("BeneName")) && gBeneTyp.equals(getData("BeneType")) && gBeneStatus.equals("ACTIVE")) {
                    ReportHelper.logReportStatus(LogStatus.PASS,"'"+gBeneTyp+"' displayed in the summary list successfully");
                    driver.findElement(By.xpath("//div[@id='BeneficiaryList']//ul/li["+i+"]")).click();
                    click(po_RDI_IB.WebElement_DownArrow);
                    bFlag=true;
                    break;
                }
                if (iBene>6) {
                    click(po_RDI_IB.WebElement_DownArrow);
                }
            }

            waitFor(5000);
            if (bFlag=true && elemExist(po_RDI_IB.Button_PayNow)) {
                ReportHelper.logReportStatus(LogStatus.PASS,"'"+getData("BeneType")+"' Details displayed successfully");
                click(po_RDI_IB.Button_PayNow);
                waitFor(3000);

                if (elemExist(po_RDI_IB.Input_TransferAmount)) {
                    ReportHelper.logReportStatus(LogStatus.PASS,"Beneficiaries Payment displayed in the screen successfully");

                    String Ccy = getData("BeneCurrency");
                    if (Ccy.equals("FCY")) {
                        click(po_RDI_IB.Image_Close);
                        waitFor(5000);
                        click(po_RDI_IB.Button_ArrowDown);
                        waitFor(1000);

                        int iFCYAccts = po_RDI_IB.Table_FCYAccounts.size();
                        boolean FFlag;
                        FFlag=false;
                        for (int i=1;i<iFCYAccts;i++){
                            waitFor(2000);
                            String cAcctNam = driver.findElement(By.xpath("//div[@class='accountsContainer FCY']["+i+"]/div[1]//h3")).getText();
                            String cAcctBal = driver.findElement(By.xpath("//div[@class='accountsContainer FCY']["+i+"]/div[2]/p[@class='amount']")).getText();
                            String cAcctStatus = driver.findElement(By.xpath("//div[@class='accountsContainer FCY']["+i+"]/div/div/p[1]")).getText();
                            if (!cAcctBal.equals("0.00") && cAcctStatus.equals("ACTIVE") && cAcctNam.equals(getData("AccountName"))) {
                                WebElement source=driver.findElement(By.xpath("//div[@class='accountsContainer FCY']["+i+"]/div[1]"));
                                WebElement destiny=driver.findElement(By.xpath("//*[@data-class='from']"));

                                Actions builder = new Actions(driver);
                                Action dragAndDrop = builder.clickAndHold(source)
                                        .moveToElement(destiny)
                                        .release(destiny)
                                        .build();
                                dragAndDrop.perform();

                                FFlag=true;
                                ReportHelper.logReportStatus(LogStatus.PASS,"FCY Account entered in the 'From Account' field successfully");
                                break;
                            }
                            click(po_RDI_IB.Button_ArrowDown);
                        }

                        if (FFlag=false) {
                            ReportHelper.logReportStatus(LogStatus.FAIL,"FCY Account entered in the 'From Account' field is not successful");
                        }
                    }

                    waitFor(7000);
                    if (getData("BeneType").equals("INTERNATIONAL")&& Ccy.equals("FCY")) {
                        String gCreditAmt = getText(po_RDI_IB.Input_TransferAmount);
                        saveTestDataToDb("PaymentAmount",gCreditAmt);
                        saveTestDataToDb("CreditAmount",gCreditAmt);
                    }else {
                        po_RDI_IB.Input_TransferAmount.clear();
                        sendKeys(po_RDI_IB.Input_TransferAmount, getData("PaymentAmount"));
                    }
                    ReportHelper.logReportStatus(LogStatus.PASS,"Transfer Amount entered successfully");
                    waitFor(1000);
                    String gCreditAmt = "";
                    if ((getData("BeneType").equals("WITHIN MEEM")&&Ccy.equals("FCY")) ||(getData("BeneType").equals("WITHIN KSA")&&Ccy.equals("FCY")) || (getData("BeneType").equals("INTERNATIONAL")&& Ccy.equals("SAR")) ) {
                         gCreditAmt = getText(po_RDI_IB.WebElement_BeneCreditAmt).replace(",","").trim();
                        saveTestDataToDb("CreditAmount", gCreditAmt);
                    } else if ((getData("BeneType").equals("INTERNATIONAL")&& Ccy.equals("FCY"))) {
                        Double DebAmt = Double.parseDouble(getData("PaymentAmount"));
                        Double ExcRate = Double.parseDouble(getData("CcyExchange"));
                        Double CredAmt = DebAmt*ExcRate;
                        DecimalFormat df = new DecimalFormat("0.000");
                        gCreditAmt = df.format(CredAmt);
                        saveTestDataToDb("CreditAmount", gCreditAmt);
                    }
                    click(po_RDI_IB.Button_ConfirmTransferMoney);
                    waitFor(5000);

                    if (getData("BeneType").equals("WITHIN KSA") || getData("BeneType").equals("INTERNATIONAL")) {
                        Select CategoryPaymt = new Select(po_RDI_IB.Select_PurposeOfCategoryPaymt);
                        CategoryPaymt.selectByValue(getData("PurposeOfCategoryPaymt"));
                        waitFor(2000);
                        Select Payment = new Select(po_RDI_IB.Select_PurposeOfPayment);
                        Payment.selectByValue(getData("PurposeOfPayment"));
                        waitFor(1000);
                        String VATChrge = getText(po_RDI_IB.TextArea_VATChargesAmt).replace("SAR","").trim();
                        Double gVAT = Double.parseDouble(VATChrge);
                        saveTestDataToDb("VATCharge",VATChrge);

                        if (!getData("BeneType").equals("INTERNATIONAL")) {
                            Double dCredAmt = Double.parseDouble(getData("CreditAmount"));
                            Double TotAmt = gVAT + dCredAmt;
                            DecimalFormat df = new DecimalFormat("0.00");
                            String TotalTxnAmt = df.format(TotAmt);
                            saveTestDataToDb("TotalTxnAmount", TotalTxnAmt);
                        }

                    } else if (getData("BeneType").equals("WITHIN MEEM")) {
                        sendKeys(po_RDI_IB.Input_PurposeOfPaymt,getData("PurposeOfPayment"));
                    }
                    ReportHelper.logReportStatus(LogStatus.PASS,"Payment details entered successfully");
                    click(po_RDI_IB.Button_ConfirmProceed);
                    waitFor(2000);

                    if (elemExist(po_RDI_IB.Button_ConfirmTxn)) {
                        ReportHelper.logReportStatus(LogStatus.PASS,"Transaction details displayed successfully");
                        click(po_RDI_IB.Button_ConfirmTxn);
                        waitFor(1000);

                        if (elemExist(po_LoginPage.Input_AuthenticationCode)) {
                            ReportHelper.logReportStatus(LogStatus.PASS,"Authentication code displayed successfully");
                            sendKeys(po_LoginPage.Input_AuthenticationCode,FetchOTP.getOTP());
                            waitFor(3000);
                            ReportHelper.logReportStatus(LogStatus.PASS,"Transfer amount details displayed correctly");
                            click(po_RDI_IB.Button_ConfirmAgreemnt);
                        } else if (elemExist(po_RDI_IB.Button_ConfirmAgreemnt)) {
                            ReportHelper.logReportStatus(LogStatus.PASS,"Transfer amount details displayed correctly");
                            click(po_RDI_IB.Button_ConfirmAgreemnt);
                        } else {
                            ReportHelper.logReportStatus(LogStatus.FAIL,"Transfer amount details displayed is not successful");
                        }

                        waitFor(6000);
                        String TxnMsg = getText(po_RDI_IB.WebElement_FundTransferSuccessfulMsg);

                        if (TxnMsg.contains("YOUR FUNDS TRANSFER HAS BEEN SUCCESSFUL")) {
                            ReportHelper.logReportStatus(LogStatus.PASS,TxnMsg);
                            click(po_RDI_IB.Button_OK);
                        } else {
                            ReportHelper.logReportStatus(LogStatus.FAIL,TxnMsg);
                        }

                    }else {
                        ReportHelper.logReportStatus(LogStatus.FAIL,"Transaction details displayed is not successful");
                    }

                } else {
                    ReportHelper.logReportStatus(LogStatus.FAIL,"Beneficiaries Payment displayed in the screen is not successful");
                }

            }else {
                ReportHelper.logReportStatus(LogStatus.FAIL,getData("BeneType")+" Beneficiary Type is not displayed in the list");
            }

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Fund Transfer failed due to '"+e.getMessage()+"'");
        }

    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : BeneType_VerifyAcctTransaction
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/
    public static void BeneType_VerifyAcctTransaction() {

        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver = getLatestDriver();
            switchDFrame(1);
            //click(po_RDI_IB.Image_Home);
            waitFor(2000);

            ReportHelper.logReportStatus(LogStatus.PASS,"Account summary displayed in the screen successfully");
            boolean AcctFlag;
            AcctFlag = false;
            //String Ccy = "";
            int iAccts = po_RDI_IB.Table_Accounts.size();
            for (int i=1;i<iAccts;i++) {
                String cAcct = driver.findElement(By.xpath("//div[@id='accountsContainer']/div["+i+"]//div[@class='accountsLeft']/h3")).getText();
                if (cAcct.equals(getData("AccountName"))) {
                    //Ccy = driver.findElement(By.xpath("//div[@id='accountsContainer']/div["+i+"]//div[@class='accountsRight']//p[1]/span")).getText();
                    driver.findElement(By.xpath("//div[@id='accountsContainer']/div["+i+"]//div[@class='accountsRight']//p[2]")).click();
                    AcctFlag = true;
                    break;
                }
                if (iAccts>8) {
                    click(po_RDI_IB.WebElement_DownArrow);
                }
            }

            waitFor(4000);
            if (AcctFlag==true && elemExist(po_RDI_IB.Title_AccountTransaction)) {
                ReportHelper.logReportStatus(LogStatus.PASS, "Account Transaction displayed in the screen successfully");
                int iAcctTxns = po_RDI_IB.Table_AcctTransaction.size();
                boolean TxnFlag;
                TxnFlag=false;
                for (int i=1;i<iAcctTxns;i++) {
                    String cTxnAmt ="";
                    String cBeneName = driver.findElement(By.xpath("//div[@id='ctl00_ContentPlaceHolder2_ucTransactionList_udpTransactionList']/ul/li["+i+"]/div[1]/h3/a")).getText();
                    String gBeneName = getData("BeneName");
                    String SpBene[] = gBeneName.split(" ");
                    if (cBeneName.contains(SpBene[0])) {
                        cTxnAmt = driver.findElement(By.xpath("//div[@id='ctl00_ContentPlaceHolder2_ucTransactionList_udpTransactionList']/ul/li[" + i + "]/div[2]/h1/p")).getText().replace(",", "").trim();
                        saveTestDataToDb("TotalTxnAmount",cTxnAmt);
                        waitFor(2000);
                        driver.findElement(By.xpath("//div[@id='ctl00_ContentPlaceHolder2_ucTransactionList_udpTransactionList']/ul/li["+i+"]/div[1]/h3/a")).click();
                        waitFor(20000);
                        int iTxnDtl = po_RDI_IB.Table_AcctTxnDtls.size();
                        boolean Flag2;
                        Flag2=false;
                        for (int k=1;k<iTxnDtl+1;k++) {
                            String TxnName = driver.findElement(By.xpath("//div[@id='balance-details']/div[4]//tr["+k+"]/td[1]")).getText();
                            if (TxnName.contains("BENEFICIARY'S ACCOUNT NUMBER:")) {
                                String gCrNum = driver.findElement(By.xpath("//div[@id='balance-details']/div[4]//tr["+k+"]/td[2]")).getText();
                                saveTestDataToDb("CRAcctNo",gCrNum);
                            } else if (TxnName.contains("REFERENCE NUMBER:")) {
                                String gRefNum = driver.findElement(By.xpath("//div[@id='balance-details']/div[4]//tr["+k+"]/td[2]")).getText();
                                saveTestDataToDb("UBS_ReferenceNumber",gRefNum);
                                ReportHelper.logReportStatus(LogStatus.PASS,"Total Transaction amount of credit account has been validated as '"+cTxnAmt+"' and Reference Number '"+gRefNum+"' displayed successfully");
                                Flag2=true;
                                break;
                            }
                        }

                        if (Flag2==false) {
                            ReportHelper.logReportStatus(LogStatus.FAIL,"Total Transaction amount of credit account has not been validated as '"+cTxnAmt+"' and Reference Number displayed is not successful");
                        } else {
                            TxnFlag=true;
                            break;
                        }
                    }
                }

                if (TxnFlag==false) {
                    ReportHelper.logReportStatus(LogStatus.FAIL,"Transaction Details displayed in the screen is not successful");
                }

  /*                  //*******************************************************************************************************************
                    DecimalFormat dformat=new DecimalFormat("0.00");
                    String vTransfAmt1 ="",vTransfAmt2="",vTransfAmt3="",vTransfAmt4="",vTransfAmt5="";

                    Double TransfAmt1 = Double.parseDouble(getData("PaymentAmount")); //Based on Internal(Within Meem)
                    vTransfAmt1 = dformat.format(TransfAmt1);

                    if (getData("BeneType").equals("WITHIN KSA") && getData("BeneCurrency").equals("FCY") ) {
                        String VATAmt = getData("VATCharge");
                        String CcyExc = getData("CcyExchange");
                        Double FVATAmt = Double.parseDouble(VATAmt)*Double.parseDouble(CcyExc);
                        Double TxnAmt2 = FVATAmt + Double.parseDouble(getData("PaymentAmount"));
                        vTransfAmt2 = dformat.format(TxnAmt2);
                    } else if (getData("BeneType").equals("INTERNATIONAL") && getData("BeneCurrency").equals("SAR")) {
                        Double TransfAmt4 = Double.parseDouble(getData("PaymentAmount")) + Double.parseDouble(getData("VATCharge")) + 3.25;
                        vTransfAmt4 = dformat.format(TransfAmt4);
                        saveTestDataToDb("TotalTxnAmount", vTransfAmt4);
                    } else if (getData("BeneType").equals("INTERNATIONAL") && getData("BeneCurrency").equals("FCY")){
                        String CcyExc = getData("CcyExchange");
                        Double FVATAmt = Double.parseDouble(getData("VATCharge"))*Double.parseDouble(CcyExc);
                        Double TxnAmt5 = FVATAmt + Double.parseDouble(getData("PaymentAmount")) + 3.25 ;
                        vTransfAmt5 = dformat.format(TxnAmt5);
                        saveTestDataToDb("TotalTxnAmount", vTransfAmt5);
                    } else if (!getData("BeneType").equals("WITHIN MEEM")) {
                        Double TransfAmt3 = Double.parseDouble(getData("TotalTxnAmount")); //Based on Domestic(KSA) And International
                        vTransfAmt3 = dformat.format(TransfAmt3);
                    }

                    if (cTxnAmt.equals(vTransfAmt1) || cTxnAmt.equals(vTransfAmt2) || cTxnAmt.equals(vTransfAmt3) || cTxnAmt.equals(vTransfAmt4) || cTxnAmt.equals(vTransfAmt5)) {
                        driver.findElement(By.xpath("//div[@id='ctl00_ContentPlaceHolder2_ucTransactionList_udpTransactionList']/ul/li["+i+"]/div[1]/h3/a")).click();
                        waitFor(20000);
                        String cTxnAmt2 = getText(po_RDI_IB.TextArea_CreditAmount).replace(",","").trim();
                        String vTxnAmt = "";
                        String vTxnAmt2 = "";
                        String vCredtAmt ="";
                        if (getData("BeneType").equals("INTERNATIONAL") && getData("BeneCurrency").equals("SAR")) {
                            vTxnAmt2 = vTransfAmt4;
                        }else if (!getData("BeneType").equals("WITHIN MEEM")) {
                            Double TxnAmt = Double.parseDouble(getData("TotalTxnAmount"));//Based on Domestic(KSA) And International
                            vTxnAmt = dformat.format(TxnAmt);
                            Double CredtAmt = Double.parseDouble(getData("CreditAmount"));
                            vCredtAmt = dformat.format(CredtAmt);
                        } else {
                            Double CredtAmt = Double.parseDouble(getData("CreditAmount"));//Based on Internal(Within Meem)
                            vCredtAmt = dformat.format(CredtAmt);
                        }
                        //System.out.println(cTxnAmt2+" "+vCredAmt);
                        if (cTxnAmt2.equals(vTxnAmt) || cTxnAmt2.equals(vTxnAmt2) || cTxnAmt2.equals(vCredtAmt)) {
                            ReportHelper.logReportStatus(LogStatus.PASS,"Transaction Details displayed in the screen correctly");
                            int iTxnDtl = po_RDI_IB.Table_AcctTxnDtls.size();
                            boolean Flag2;
                            Flag2=false;
                            for (int k=1;k<iTxnDtl+1;k++) {
                                String TxnName = driver.findElement(By.xpath("//div[@id='balance-details']/div[4]//tr["+k+"]/td[1]")).getText();
                                if (TxnName.contains("BENEFICIARY'S ACCOUNT NUMBER:")) {
                                    String gCrNum = driver.findElement(By.xpath("//div[@id='balance-details']/div[4]//tr["+k+"]/td[2]")).getText();
                                    saveTestDataToDb("CRAcctNo",gCrNum);
                                } else if (TxnName.contains("REFERENCE NUMBER:")) {
                                    String gRefNum = driver.findElement(By.xpath("//div[@id='balance-details']/div[4]//tr["+k+"]/td[2]")).getText();
                                    saveTestDataToDb("UBS_ReferenceNumber",gRefNum);
                                    Flag2=true;
                                    break;
                                }
                            }

                            if (Flag2==true) {
                                ReportHelper.logReportStatus(LogStatus.PASS,"Reference Number is displayed in the account transaction page");
                                TxnFlag = true;
                                break;
                            } else {
                                ReportHelper.logReportStatus(LogStatus.FAIL,"Reference Number is not displayed in the account transaction page");
                            }
                        }
                    }
                }

                if (TxnFlag==false) {
                    ReportHelper.logReportStatus(LogStatus.FAIL,"Transaction Details displayed in the screen is not successful");
                } */

                //*******************************************************************************************************************
            }else {
                ReportHelper.logReportStatus(LogStatus.FAIL, "Account Transaction displayed in the screen is not successful");
            }

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Verification of account balance failed due to '"+e.getMessage()+"'");
        }

    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : Goal_Create
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/
    public static String getmonth(String monthval)
    {
        String[] monthName = {"January", "February",
                "March", "April", "May", "June", "July",
                "August", "September", "October", "November",
                "December"};
        String month=monthName[Integer.parseInt(monthval)-1];
        return month;
    }

    public static void Goal_Create() {

        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver = getLatestDriver();
            switchDFrame(1);
            waitFor(2000);
            ReportHelper.logReportStatus(LogStatus.PASS, "Account summary displayed in the screen successfully");

            Select_MenuItem("YOUR BUDGET");
            click(po_RDI_IB.Button_CreateNewGoal);
            waitFor(3000);

            if (elemExist(po_RDI_IB.Input_GoalName)) {
                ReportHelper.logReportStatus(LogStatus.PASS,"New Saving Plan displayed in the screen successfully");

                driver.findElement(By.xpath("//div[@class='viewport']/ul/li[@id='"+getData("GoalIcon")+"']/img")).click();
                sendKeys(po_RDI_IB.Input_GoalName,getData("GoalName"));
                sendKeys(po_RDI_IB.Input_TotalSavingAmount,getData("TotalSavingAmount"));
                sendKeys(po_RDI_IB.Input_ThreshHoldAmount,getData("ThreshHoldAmount"));
                driver.findElement(By.xpath("//li[@id='"+getData("VIA")+"']")).click();

                String []Sp_StartDate = getData("StartDate").split("/");
                String vDate1 = Sp_StartDate[0];
                String vMonth1 = getmonth(Sp_StartDate[1]);
                System.out.println(vMonth1);
                String vYear1 = Sp_StartDate[2];
                click(po_RDI_IB.Input_StartDate);
                Select Month1 = new Select(po_RDI_IB.Select_CalendarMonth);
                Month1.selectByVisibleText(vMonth1);
                Select Year1 = new Select(po_RDI_IB.Select_CalendarYear);
                Year1.selectByVisibleText(vYear1);
                driver.findElement(By.xpath("//div[@class='calendars-month']//tr/td/a[contains(.,'"+vDate1+"')]")).click();

                String []Sp_EndDate = getData("EndDate").split("/");
                String vDate2 = Sp_EndDate[0];
                String vMonth2 = getmonth(Sp_EndDate[1]);
                System.out.println(vMonth2);
                String vYear2 = Sp_EndDate[2];
                click(po_RDI_IB.Input_EndDate);
                Select Month2 = new Select(po_RDI_IB.Select_CalendarMonth);
                Month2.selectByVisibleText(vMonth2);
                Select Year2 = new Select(po_RDI_IB.Select_CalendarYear);
                Year2.selectByVisibleText(vYear2);
                driver.findElement(By.xpath("//div[@class='calendars-month']//tr/td/a[contains(.,'"+vDate2+"')]")).click();
                waitFor(1000);

                driver.findElement(By.xpath("//div[@id='ctl00_ContentPlaceHolder2_upFrequency']//li[contains(.,'"+getData("UpFrequency")+"')]")).click();
                ReportHelper.logReportStatus(LogStatus.PASS,"Goal details entered successfully");

                int ArrDown = 5;
                for (int i=1;i<ArrDown;i++){
                    click(po_RDI_IB.Button_GoalArrowDown);
                }
                click(po_RDI_IB.Button_Confirm);
                waitFor(5000);

                String SuccMsg = getText(po_RDI_IB.WebElement_GoalSuccessfulMessage);
                if (SuccMsg.equals("YOU HAVE SUCCESSFULLY CREATED A NEW SAVING GOAL")) {
                    ReportHelper.logReportStatus(LogStatus.PASS,SuccMsg);
                }else {
                    ReportHelper.logReportStatus(LogStatus.FAIL,SuccMsg);
                }

            }else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"New Saving Plan displayed in the screen is not successful");
            }

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Goal creation failed due to '"+e.getMessage()+"'");
        }
    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : Goal_Delete
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void Goal_Delete() {

        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver = getLatestDriver();
            switchDFrame(1);
            waitFor(2000);
            ReportHelper.logReportStatus(LogStatus.PASS, "Account summary displayed in the screen successfully");

            Select_MenuItem("YOUR BUDGET");

            int SavCnt = po_RDI_IB.Table_SavingInfo.size();
            boolean SFlag;
            SFlag=false;
            for (int i=1;i<SavCnt+1;i++){
                System.out.println(po_RDI_IB.Table_SavingInfo.get(i-1).getText() +"   "+getData("GoalName"));
                if(getData("GoalName").equals(po_RDI_IB.Table_SavingInfo.get(i-1).getText())) {
                    hover(po_RDI_IB.Table_SavingInfo.get(i-1));
                    i=i+1;
                    //System.out.println(i);
                    driver.findElement(By.xpath("//div[@class='jspPane']/div["+i+"]//a[@id='deleteIcon']")).click();
                    waitFor(2000);
                    ReportHelper.logReportStatus(LogStatus.PASS,"Are you sure that you want to delete your goal? Yes/No");
                    driver.findElement(By.xpath("//div[@class='jspPane']/div["+i+"]//a[contains(.,'yes')]")).click();
                    SFlag=true;
                    break;
                }
            }

            waitFor(8000);
            if (SFlag=true) {
                ReportHelper.logReportStatus(LogStatus.PASS,"Goal details deleted successfully");
            }else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Goal details deleted is not successful");
            }

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Deletion of goal failed due to '"+e.getMessage()+"'");
        }
    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : SI_SetUp
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void SI_SetUp() {

        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver = getLatestDriver();
            switchDFrame(1);
            waitFor(2000);
            ReportHelper.logReportStatus(LogStatus.PASS, "Account summary displayed in the screen successfully");

            Select_MenuItem("TRANSFER");
            click(po_RDI_IB.Menu_Beneficiaries);
            waitFor(4000);

            int iBene = po_RDI_IB.Table_Beneficiaries.size();
            boolean bFlag;
            bFlag = false;
            for (int i=1;i<iBene+1;i++) {
                String gBeneName = driver.findElement(By.xpath("//div[@id='BeneficiaryList']//ul/li["+i+"]//div/h6[1]/p")).getText();
                String gBeneStatus = driver.findElement(By.xpath("//div[@id='BeneficiaryList']//ul/li["+i+"]//div/h6[3]/p")).getText();
                if (gBeneName.equals(getData("BeneName")) && gBeneStatus.equals("ACTIVE")) {
                    ReportHelper.logReportStatus(LogStatus.PASS,"'"+gBeneName+"' displayed in the summary list successfully");
                    driver.findElement(By.xpath("//div[@id='BeneficiaryList']//ul/li["+i+"]")).click();
                    bFlag=true;
                    break;
                }
            }

            waitFor(5000);
            if (bFlag=true && elemExist(po_RDI_IB.Button_SetUpStandingInstr)) {
                ReportHelper.logReportStatus(LogStatus.PASS,"'"+getData("BeneName")+"' Details displayed successfully");
                click(po_RDI_IB.Button_SetUpStandingInstr);
                waitFor(3000);

                if (elemExist(po_RDI_IB.Input_SI_Amount)) {
                    ReportHelper.logReportStatus(LogStatus.PASS,"New Standing Instruction displayed in the screen successfully");

                    sendKeys(po_RDI_IB.Input_SI_Amount,getData("SI_Amount"));
                    click(po_RDI_IB.Button_MeemOnePack);
                    driver.findElement(By.xpath("//ul[@class='freq']/li[contains(text(),'"+getData("Frequency")+"')]")).click();

                    String []Sp_StartDate = getData("StartDate").split("/");
                    String vDate1 = Sp_StartDate[0];
                    String vMonth1 = getmonth(Sp_StartDate[1]);
                    System.out.println(vMonth1);
                    String vYear1 = Sp_StartDate[2];
                    click(po_RDI_IB.Input_StartDate);
                    Select Month1 = new Select(po_RDI_IB.Select_CalendarMonth);
                    Month1.selectByVisibleText(vMonth1);
                    Select Year1 = new Select(po_RDI_IB.Select_CalendarYear);
                    Year1.selectByVisibleText(vYear1);
                    driver.findElement(By.xpath("//div[@class='calendars-month']//tr/td/a[contains(.,'"+vDate1+"')]")).click();

                    String []Sp_EndDate = getData("EndDate").split("/");
                    String vDate2 = Sp_EndDate[0];
                    String vMonth2 = getmonth(Sp_EndDate[1]);
                    System.out.println(vMonth2);
                    String vYear2 = Sp_EndDate[2];
                    click(po_RDI_IB.Input_EndDate);
                    Select Month2 = new Select(po_RDI_IB.Select_CalendarMonth);
                    Month2.selectByVisibleText(vMonth2);
                    Select Year2 = new Select(po_RDI_IB.Select_CalendarYear);
                    Year2.selectByVisibleText(vYear2);
                    driver.findElement(By.xpath("//div[@class='calendars-month']//tr/td/a[contains(.,'"+vDate2+"')]")).click();
                    waitFor(1000);
                    ReportHelper.logReportStatus(LogStatus.PASS,"Standing Instruction details entered successfully");
                    click(po_RDI_IB.Button_Confirm);

                    waitFor(5000);
                    Select CategoryPaymt = new Select(po_RDI_IB.Select_PurposeOfCategoryPaymt);
                    CategoryPaymt.selectByValue(getData("PurposeOfCategoryPaymt"));
                    waitFor(2000);
                    Select Payment = new Select(po_RDI_IB.Select_PurposeOfPayment);
                    Payment.selectByValue(getData("PurposeOfPayment"));
                    waitFor(1000);
                    ReportHelper.logReportStatus(LogStatus.PASS,"Payment details entered successfully");
                    click(po_RDI_IB.Button_ConfirmProceed);
                    waitFor(2000);

                    if (elemExist(po_RDI_IB.Button_ConfirmTxn)) {
                        ReportHelper.logReportStatus(LogStatus.PASS,"Transaction details displayed successfully");
                        click(po_RDI_IB.Button_ConfirmTxn);
                        waitFor(1000);

                        if (elemExist(po_LoginPage.Input_AuthenticationCode)) {
                            ReportHelper.logReportStatus(LogStatus.PASS,"Authentication code displayed successfully");
                            sendKeys(po_LoginPage.Input_AuthenticationCode,FetchOTP.getOTP());
                            waitFor(3000);
                            ReportHelper.logReportStatus(LogStatus.PASS,"Transfer amount details displayed correctly");
                            click(po_RDI_IB.Button_ConfirmAgreemnt);
                        } else if (elemExist(po_RDI_IB.Button_ConfirmAgreemnt)) {
                            ReportHelper.logReportStatus(LogStatus.PASS,"Transfer amount details displayed correctly");
                            click(po_RDI_IB.Button_ConfirmAgreemnt);
                        } else {
                            ReportHelper.logReportStatus(LogStatus.FAIL,"Transfer amount details displayed is not successful");
                        }

                        waitFor(6000);
                        String TxnMsg = getText(po_RDI_IB.WebElement_SuccessfulMessage);
                       /* System.out.println(TxnMsg);
                        System.out.println("YOUR STANDING INSTRUCTION REQUEST FOR SAR "+getData("SI_Amount")+" PAYABLE DAILY HAS BEEN SETUP");*/
                        if (TxnMsg.contains("YOUR STANDING INSTRUCTION REQUEST FOR SAR "+getData("SI_Amount")+" PAYABLE DAILY HAS BEEN SETUP")) {
                            ReportHelper.logReportStatus(LogStatus.PASS,TxnMsg);
                            click(po_RDI_IB.Button_OK);
                        } else {
                            ReportHelper.logReportStatus(LogStatus.FAIL,TxnMsg);
                        }

                    }else {
                        ReportHelper.logReportStatus(LogStatus.FAIL,"Transaction details displayed is not successful");
                    }

                }else {
                    ReportHelper.logReportStatus(LogStatus.FAIL,"New Standing Instruction displayed in the screen is not successful");
                }
            } else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"New Standing Instruction displayed in the screen is not successful");
            }

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Standing Instruction Setup failed due to '"+e.getMessage()+"'");
        }

    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : SI_Verify
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void SI_Verify() {

        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver = getLatestDriver();
            switchDFrame(1);
            waitFor(2000);

            if (elemExist(po_RDI_IB.WebElement_MeemOnePackAccount)) {
                ReportHelper.logReportStatus(LogStatus.PASS, "Account summary displayed in the screen successfully");
                click(po_RDI_IB.WebElement_MeemOnePackAccount);
                waitFor(3000);

                if (elemExist(po_RDI_IB.SubMenu_StandingInstruction)) {
                    ReportHelper.logReportStatus(LogStatus.PASS,"Standing Instruction displayed in the submenu successfully");
                    click(po_RDI_IB.SubMenu_StandingInstruction);
                    waitFor(2000);

                    ReportHelper.logReportStatus(LogStatus.PASS,"Standing Instructions displayed in the transaction details screen successfully");
                    Select TxnList = new Select(po_RDI_IB.Select_TransactionList);
                    TxnList.selectByVisibleText(getData("TransactionList"));
                    waitFor(3000);

                    click(po_RDI_IB.Button_SIArrowDown);
                    int TxnLst = po_RDI_IB.Table_TransactionList.size();
                    boolean TxnFlg;
                    TxnFlg=false;
                    for (int i=1;i<TxnLst;i++) {
                        String BeneName = driver.findElement(By.xpath("//ul[@class='rows']/li["+i+"]/div[@class='left']/h3")).getText();
                        String TxnVal = driver.findElement(By.xpath("//ul[@class='rows']/li["+i+"]/div[2]/h1/p")).getText().trim();
/*                        System.out.println(BeneName +"        "+getData("FullName"));
                        System.out.println(TxnVal+"       "+getData("SI_Amount"));*/
                        if (getData("FullName").equals(BeneName) && TxnVal.equals(getData("SI_Amount"))) {
                            ReportHelper.logReportStatus(LogStatus.PASS,"Successful Transaction status displayed in the details");
                            TxnFlg=true;
                            break;
                        }
                        click(po_RDI_IB.Button_SIArrowDown);
                    }

                    if (TxnFlg=false) {
                        ReportHelper.logReportStatus(LogStatus.FAIL,"Successful Transaction status displayed is not found in the details");
                    }

                } else {
                    ReportHelper.logReportStatus(LogStatus.FAIL,"Standing Instruction displayed in the submenu is not successful");
                }

            }else {
                ReportHelper.logReportStatus(LogStatus.FAIL, "Account summary displayed in the screen is not successful");
            }

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Verification of Standing Instruction failed due to '"+e.getMessage()+"'");
        }


    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : SI_Delete
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void SI_Delete() {

        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver = getLatestDriver();
            switchDFrame(1);
            waitFor(2000);

            if (elemExist(po_RDI_IB.WebElement_MeemOnePackAccount)) {
                ReportHelper.logReportStatus(LogStatus.PASS, "Account summary displayed in the screen successfully");
                click(po_RDI_IB.WebElement_MeemOnePackAccount);
                waitFor(3000);

                if (elemExist(po_RDI_IB.SubMenu_StandingInstruction)) {
                    ReportHelper.logReportStatus(LogStatus.PASS,"Standing Instruction displayed in the submenu successfully");
                    click(po_RDI_IB.SubMenu_StandingInstruction);
                    waitFor(2000);

                    ReportHelper.logReportStatus(LogStatus.PASS,"Standing Instructions displayed in the transaction details screen successfully");
                    Select TxnList = new Select(po_RDI_IB.Select_TransactionList);
                    TxnList.selectByVisibleText(getData("TransactionList"));
                    waitFor(3000);

                    click(po_RDI_IB.Button_SIArrowDown);
                    int TxnLst = po_RDI_IB.Table_TransactionList.size();
                    boolean TxnFlg;
                    TxnFlg=false;
                    for (int i=1;i<TxnLst;i++) {
                        String BeneName = driver.findElement(By.xpath("//ul[@class='rows']/li["+i+"]/div[@class='left']/h3")).getText();
                        String TxnVal = driver.findElement(By.xpath("//ul[@class='rows']/li["+i+"]/div[2]/h1/p")).getText().trim();
                        if (getData("FullName").equals(BeneName) && TxnVal.equals(getData("SI_Amount"))) {
                            driver.findElement(By.xpath("//ul[@class='rows']/li["+i+"]/div[@class='left']")).click();
                            waitFor(1000);
                            ReportHelper.logReportStatus(LogStatus.PASS,"Standing Instruction Delete button displayed successfully");
                            driver.findElement(By.xpath("//ul[@class='rows']/li["+i+"]/div[@class='buttons']//a[1]")).click();
                            TxnFlg=true;
                            break;
                        }
                        click(po_RDI_IB.Button_SIArrowDown);
                    }

                    if (TxnFlg=true && elemExist(po_RDI_IB.WebElement_MeemOnePackAccount) ) {
                        ReportHelper.logReportStatus(LogStatus.PASS,"Standing Instruction details deleted successfully");
                    } else {
                        ReportHelper.logReportStatus(LogStatus.FAIL,"Standing Instruction details deleted is not successful");
                    }

                } else {
                    ReportHelper.logReportStatus(LogStatus.FAIL,"Standing Instruction displayed in the submenu is not successful");
                }

            }else {
                ReportHelper.logReportStatus(LogStatus.FAIL, "Account summary displayed in the screen is not successful");
            }

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Verification of Standing Instruction failed due to '"+e.getMessage()+"'");
        }

    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : MFCA_Create
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void MFCA_Create() {

        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver = getLatestDriver();
            switchDFrame(1);
            waitFor(2000);
            ReportHelper.logReportStatus(LogStatus.PASS, "Account summary displayed in the screen successfully");

            Select_MenuItem("PRODUCTS");
            click(po_RDI_IB.SubMenu_CurrenciesCard);

            if (elemExist(po_RDI_IB.Title_CurrenciesCard)) {
                ReportHelper.logReportStatus(LogStatus.PASS, "Currencies Card displayed in the screen successfully");
                String gCcy = getData("Currencies");
                String Sp_Ccy[] = gCcy.split(";");
                int CcyCnt = Sp_Ccy.length;
                //int CcyCnt = po_RDI_IB.Table_Currency.size();
                for (int i=0;i<CcyCnt;i++) {
                    driver.findElement(By.xpath("//div[@id='dvCurrencies']//li[contains(.,'"+Sp_Ccy[i]+"')]")).click();
                }

                driver.findElement(By.xpath("//div[@id='baseCurr']//li[contains(.,'"+getData("BaseCurrency")+"')]")).click();
                driver.findElement(By.xpath("//div[@class='statement']//li[contains(.,'"+getData("E_Statement")+"')]")).click();
                driver.findElement(By.xpath("//div[@class='delivery-option']//li[contains(.,'"+getData("DeliveryOption")+"')]")).click();
                ReportHelper.logReportStatus(LogStatus.PASS, "Currencies Card fields entered successfully");

                click(po_RDI_IB.Button_AddNewProduct);
                waitFor(2000);

                click(po_RDI_IB.Button_OTPSentMobile);
                waitFor(2000);

                sendKeys(po_LoginPage.Input_AuthenticationCode, FetchOTP.getOTP());
                ReportHelper.logReportStatus(LogStatus.PASS,"OTP Code entered successfully");
                click(po_RDI_IB.Button_OTPConfirm);
                waitFor(3000);

                if (elemExist(po_RDI_IB.Button_Accept)) {
                    ReportHelper.logReportStatus(LogStatus.PASS,"Currencies card details displayed correctly");
                    click(po_RDI_IB.Button_Accept);
                    waitFor(20000);
/*                    String loginType=DriverHelper.environmentURL;
                    String loginType1 = loginCredentials(loginType)[0];*/
                    if (elemExist(driver.findElement(By.xpath("//div/h3[contains(text(),'Currencies Card')]")))) {
                        ReportHelper.logReportStatus(LogStatus.PASS,"Newly created MFCA account added in the summary list successfully");
                    } else {
                        ReportHelper.logReportStatus(LogStatus.FAIL,"MFCA account created is not successful");
                    }

                } else {
                    ReportHelper.logReportStatus(LogStatus.FAIL,"Currencies card details displayed is not successful");
                }
            }

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Creation of currencies card failed due to '"+e.getMessage()+"'");

        }
    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : Card_ReIssuance
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void Card_ReIssuance() {

        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver = getLatestDriver();
            switchDFrame(1);
            waitFor(2000);
            ReportHelper.logReportStatus(LogStatus.PASS, "Account summary displayed in the screen successfully");

            if (getData("AccountType").equals("MeemOnePack")) {
                click(po_RDI_IB.WebElement_MeemOnePackAccount);
                waitFor(3000);
                ReportHelper.logReportStatus(LogStatus.PASS,"Meem OnePack displayed in the details successfully");
                click(po_RDI_IB.WebELement_OP_ATMCard);
            } else if (getData("AccountType").equals("CurrenciesCard")) {
                //div/h3[contains(text(),'1040674291')]
                String loginType=DriverHelper.environmentURL;
                String loginType1 = loginCredentials(loginType)[0];
                driver.findElement(By.xpath("//div/h3[contains(text(),'"+loginType1+"')]")).click();
                waitFor(3000);
                ReportHelper.logReportStatus(LogStatus.PASS,"Currencies Card displayed in the details successfully");
                click(po_RDI_IB.WebELement_MFCA_ActivateCard);
            } else if (getData("AccountType").equals("CreditCard")) {
                click(po_RDI_IB.WebElement_CreditCardAccount);
                waitFor(3000);
                ReportHelper.logReportStatus(LogStatus.PASS,"Credit Card details displayed in the screen successfully");
                click(po_RDI_IB.WebELement_CC_CashBackDetails);
                waitFor(1000);
                click(po_RDI_IB.WebELement_CC_StopCard);
            }

            ReportHelper.logReportStatus(LogStatus.PASS,"Card Block details displayed successfully");
            click(po_RDI_IB.Button_CardBlock);
            waitFor(2000);

            driver.findElement(By.xpath("//ul[@id='reason']/li[contains(text(),'"+getData("BlockCardReason")+"')]")).click();
            waitFor(1000);
            if (getData("AccountType").equals("MeemOnePack") || getData("AccountType").equals("CreditCard")) {
                int ArrDown = 10;
                for (int i=1;i<ArrDown;i++){
                    click(po_RDI_IB.Button_GoalArrowDown);
                }
                driver.findElement(By.xpath("//div[@id='divDeliveryOptions']//li[contains(.,'" + getData("DeliverCard") + "')]")).click();
            } else {
                driver.findElement(By.xpath("//div[@id='divDeliveryOptions']//li[contains(.,'" + getData("DeliverCard") + "')]")).click();
            }

            if (getData("AccountType").equals("CreditCard")) {
                sendKeys(po_RDI_IB.Input_CC_NewCardPin,getData("NewCardPin"));
                sendKeys(po_RDI_IB.Input_CC_ConfirmNewPin,getData("ConfirmNewPin"));
            }

            ReportHelper.logReportStatus(LogStatus.PASS,"Card Block details entered successfully");
            click(po_RDI_IB.Button_ConfirmCardBlock);
            waitFor(25000); // need to be modified (loading object)

            String IssuMsg = getText(po_RDI_IB.WebElement_SuccessfulMessage);
            if (IssuMsg.contains(getData("CardSuccessMessage"))) {
                ReportHelper.logReportStatus(LogStatus.PASS,IssuMsg);
                click(po_RDI_IB.Button_OK);
            } else {
                ReportHelper.logReportStatus(LogStatus.FAIL,IssuMsg);
            }

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Card ReIssuance failed due to '"+e.getMessage()+"'");
        }

    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : BillPayment_CreditCard
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void BillPayment_CreditCard() {

        try {
            initPageObjects();
            getLatestDriver();

            WebDriver driver = getLatestDriver();
            driver.switchTo().defaultContent();
            driver.switchTo().frame(1);

            Select_MenuItem("TRANSFER");
            waitFor(1000);

            if (elemExist(po_RDI_IB.Menu_Bills)) {
                ReportHelper.logReportStatus(LogStatus.PASS,"Bills displayed in the submenu successfully");
                click(po_RDI_IB.Menu_Bills);
                waitFor(5000);

                driver.findElement(By.xpath("//ul[@id='dvPayeesBeneficries1']//div[@id='Wrapper']/h6[contains(.,'"+getData("BillName")+"')]")).click();
                waitFor(5000);

                if (elemExist(po_RDI_IB.Button_PayBill)) {
                    ReportHelper.logReportStatus(LogStatus.PASS,"Bill displayed in the details successfully");
                    click(po_RDI_IB.Button_PayBill);
                    waitFor(3000);

                    if (elemExist(po_RDI_IB.Input_TransferAmount)) {
                        ReportHelper.logReportStatus(LogStatus.PASS, "Bill Payment displayed in the screen successfully");

                        click(po_RDI_IB.Image_CloseBill);
                        waitFor(5000);
                        click(po_RDI_IB.Button_ArrowDown);
                        waitFor(1000);

                        int iCCAccts = po_RDI_IB.Table_CCAccounts.size();
                        boolean FFlag;
                        FFlag = false;
                        for (int i = 1; i <=iCCAccts; i++) {
                            waitFor(2000);
                            String cAcctNam = driver.findElement(By.xpath("//div[@class='accountsContainer CC'][" + i + "]/div[1]//h3")).getText();
                            String cAcctStatus = driver.findElement(By.xpath("//div[@class='accountsContainer CC'][" + i + "]/div/div/p[1]")).getText();
                            String cAccBal = driver.findElement(By.xpath("//div[@class='accountsContainer CC']["+i+"]/div/div/p[2]/span")).getText();
                            if (cAcctStatus.equals("ACTIVE") && cAcctNam.equals(getData("CCAcctName")) && !cAccBal.equals("0.00")) {
                                WebElement source = driver.findElement(By.xpath("//div[@class='accountsContainer CC'][" + i + "]/div[1]"));
                                WebElement destiny = driver.findElement(By.xpath("//*[@data-class='from']"));

                                Actions builder = new Actions(driver);
                                Action dragAndDrop = builder.clickAndHold(source)
                                        .moveToElement(destiny)
                                        .release(destiny)
                                        .build();
                                dragAndDrop.perform();

                                FFlag = true;
                                ReportHelper.logReportStatus(LogStatus.PASS, "CC Account entered in the 'From Account' field successfully");
                                break;
                            }
                            click(po_RDI_IB.Button_ArrowDown);
                        }

                        if (FFlag = false) {
                            ReportHelper.logReportStatus(LogStatus.FAIL, "CC Account entered in the 'From Account' field is not successful");
                        }

                        waitFor(7000);
                        po_RDI_IB.Input_TransferAmount.clear();
                        sendKeys(po_RDI_IB.Input_TransferAmount, getData("PaymentAmount"));
                        ReportHelper.logReportStatus(LogStatus.PASS, "Transfer Amount entered successfully");
                        waitFor(1000);

                        click(po_RDI_IB.Button_ConfirmTransferMoney);
                        waitFor(5000);

                        if (elemExist(po_RDI_IB.Button_ConfirmTxn)) {
                            ReportHelper.logReportStatus(LogStatus.PASS, "Bill transaction details displayed successfully");
                            click(po_RDI_IB.Button_ConfirmTxn);

                        } else {
                            ReportHelper.logReportStatus(LogStatus.FAIL, "Bill transaction details displayed is not successful");
                        }

                        waitFor(5000);
                        if (elemExist(po_RDI_IB.Button_ConfirmAgreemnt)) {
                            ReportHelper.logReportStatus(LogStatus.PASS, "Transfer amount details displayed correctly");
                            click(po_RDI_IB.Button_ConfirmAgreemnt);
                            waitFor(10000);

                            String TxnMsg = getText(po_RDI_IB.WebElement_SuccessfulMessage);

                            if (TxnMsg.contains("YOUR BILL HAS BEEN SUCCESSFULLY PAID")) {
                                ReportHelper.logReportStatus(LogStatus.PASS, TxnMsg);
                                click(po_RDI_IB.Button_OK);
                            } else {
                                ReportHelper.logReportStatus(LogStatus.FAIL, TxnMsg);
                            }
                        } else {
                            ReportHelper.logReportStatus(LogStatus.FAIL, "Transfer amount details displayed is not successful");
                        }
                    } else {
                        ReportHelper.logReportStatus(LogStatus.FAIL,"Bill Payment displayed in the screen is not successful");
                    }

                } else {
                    ReportHelper.logReportStatus(LogStatus.FAIL,"Bill details displayed is not successful");
                }

            } else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Bills displayed in the submenu is not successful");
            }

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Bill Payment - Credit card failed due to '"+e.getMessage()+"'");
        }
    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : Beneficaiy CRM_Launch via CRM
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void CRM_Launch() {


        try {
            openUrl(getURL("CRM~T2"));
            ReportHelper.logReportStatus(LogStatus.PASS, "CRM URL lanunched Successfully");
        }catch(Exception e)
        {
            ReportHelper.logReportStatus(LogStatus.FAIL, "CRM URL Launch Failes"+e.getMessage());
        }

    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : Select_Customer
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void Select_Customer() throws AWTException {
        try {

            WebDriver driver = getLatestDriver();
            driver.findElement(By.xpath("//*[contains(text(),'Contacts')]")).click();
            waitFor(5000);
            driver.switchTo().frame("contentIFrame");
            driver.findElement(By.id("crmGrid_findCriteria")).sendKeys(getData("UserID"), Keys.ENTER);
            waitFor(5000);
            driver.findElement(By.xpath("//table[@id='gridBodyTable']//tr/td[3]//a/span")).click();
            waitFor(25000);

            Robot rt = new Robot();
            rt.keyPress(KeyEvent.VK_ENTER);
            rt.keyRelease(KeyEvent.VK_ENTER);
            waitFor(3000);

            rt.keyPress(KeyEvent.VK_ENTER);
            rt.keyRelease(KeyEvent.VK_ENTER);

            waitFor(1000);
            ReportHelper.logReportStatus(LogStatus.PASS, getData("UserID")+" is Selected Successfully");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "User Selection failed due to "+e.getMessage());
        }

    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : StandingOrderInstructions
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void StandingOrderInstructions_Validate() {

        try {
            WebDriver driver=getLatestDriver();
            for(String sam:driver.getWindowHandles())
            {
                driver.switchTo().window(sam);
            }

            driver.switchTo().frame("contentIFrame");
            waitFor(3000);

            Robot rt = new Robot();
            rt.keyPress(KeyEvent.VK_ENTER);
            rt.keyRelease(KeyEvent.VK_ENTER);
            waitFor(3000);

            rt.keyPress(KeyEvent.VK_ENTER);
            rt.keyRelease(KeyEvent.VK_ENTER);

            waitFor(5000);

            driver.findElement(By.xpath("//a//img[@id='formSelectorDropdown']")).click();
            waitFor(1000);

            driver.findElement(By.xpath("//span[contains(text(),'360*')]")).click();
            waitFor(10000);
            driver.switchTo().defaultContent();
            for (String s1: driver.getWindowHandles())
            {
                driver.switchTo().window(s1);
            }
            driver.switchTo().frame("contentIFrame");

            ReportHelper.logReportStatus(LogStatus.PASS,"Standing Order Instructions displayed in the menu successfully");
            driver.findElement(By.xpath("//a[@id='tab6Tab']//nobr[contains(text(),'Standing Order Instructions')]")).click();
            waitFor(10000);

            driver.switchTo().defaultContent();
            for (String s1: driver.getWindowHandles())
            {
                driver.switchTo().window(s1);
            }
            driver.switchTo().frame("contentIFrame");
            driver.switchTo().frame("IFRAME_StandingOrderInstructions");

            List <WebElement> SIList = driver.findElements(By.xpath("//table[@id='standingOrderInstruction_GrdStandingOrderInstructions']//tr"));
            int SICount = SIList.size();
            boolean Flag;
            Flag = false;
            for (int i=2;i<SICount;i++) {
                String vDate = driver.findElement(By.xpath("//table[@id='standingOrderInstruction_GrdStandingOrderInstructions']//tr["+i+"]/td[1]/span")).getText();
                String vStatus = driver.findElement(By.xpath("//table[@id='standingOrderInstruction_GrdStandingOrderInstructions']//tr["+i+"]/td[9]/span")).getText();
                if (vDate.equals(getData("SIDate")) && vStatus.equals(getData("Status"))) {
                    ReportHelper.logReportStatus(LogStatus.PASS,"Standing Order Instructions verified successfully");
                    Flag = true;
                    break;
                }
            }

            if (Flag=false) {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Standing Order Instructions verified is not successful");
            }

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Standing Order Instructions failed due to '"+e.getMessage()+"'");
        }


    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : ViewContacts_Info
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void ViewContacts_Info() {

        try {
            WebDriver driver=getLatestDriver();
            for(String sam:driver.getWindowHandles())
            {
                driver.switchTo().window(sam);
            }

            driver.switchTo().frame("contentIFrame");
            waitFor(3000);

            Robot rt = new Robot();
            rt.keyPress(KeyEvent.VK_ENTER);
            rt.keyRelease(KeyEvent.VK_ENTER);
            waitFor(3000);

            rt.keyPress(KeyEvent.VK_ENTER);
            rt.keyRelease(KeyEvent.VK_ENTER);

            waitFor(5000);
            driver.switchTo().defaultContent();
            for (String s1: driver.getWindowHandles())
            {
                driver.switchTo().window(s1);
            }
            driver.switchTo().frame("contentIFrame");

            String FrstName = driver.findElement(By.xpath("//input[@id='firstname']")).getAttribute("value");
            if (!FrstName.equals("")) {
                ReportHelper.logReportStatus(LogStatus.PASS,"Contacts Information displayed in the details successfully");
            } else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Contacts Information displayed is not successful");
            }
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Standing Order Instructions failed due to '"+e.getMessage()+"'");
        }

    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : CRM_AccountSync
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void CRM_AccountSync() {

        try {
            WebDriver driver=getLatestDriver();
            for(String sam:driver.getWindowHandles())
            {
                driver.switchTo().window(sam);
            }

            driver.switchTo().frame("contentIFrame");
            waitFor(3000);

            Robot rt = new Robot();
            rt.keyPress(KeyEvent.VK_ENTER);
            rt.keyRelease(KeyEvent.VK_ENTER);
            waitFor(3000);

            rt.keyPress(KeyEvent.VK_ENTER);
            rt.keyRelease(KeyEvent.VK_ENTER);

            waitFor(5000);

            driver.findElement(By.xpath("//a//img[@id='formSelectorDropdown']")).click();
            waitFor(1000);

            driver.findElement(By.xpath("//span[contains(text(),'360*')]")).click();
            waitFor(10000);
            driver.switchTo().defaultContent();
            for (String s1: driver.getWindowHandles())
            {
                driver.switchTo().window(s1);
            }
            driver.switchTo().frame("contentIFrame");

            List <WebElement> AcctList = driver.findElements(By.xpath("//table[@id='gridBodyTable']/tbody/tr"));
            int AcctCount = AcctList.size();
            boolean Flag;
            Flag = false;
            for (int i=1;i<AcctCount;i++) {
                String vProd = driver.findElement(By.xpath("//table[@id='gridBodyTable']/tbody/tr["+i+"]/td[4]")).getText();
                if (!vProd.equals("")) {
                    ReportHelper.logReportStatus(LogStatus.PASS,"Account details verified successfully");
                    Flag = true;
                    break;
                }
            }

            if (Flag=false) {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Account list verified is not successful");
            }


        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Account Sync failed due to '"+e.getMessage()+"'");
        }

    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : CRM_CardSync
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void CRM_CardSync() {

        try {
            WebDriver driver=getLatestDriver();
            for(String sam:driver.getWindowHandles())
            {
                driver.switchTo().window(sam);
            }

            driver.switchTo().frame("contentIFrame");
            waitFor(3000);

            Robot rt = new Robot();
            rt.keyPress(KeyEvent.VK_ENTER);
            rt.keyRelease(KeyEvent.VK_ENTER);
            waitFor(3000);

            rt.keyPress(KeyEvent.VK_ENTER);
            rt.keyRelease(KeyEvent.VK_ENTER);

            waitFor(5000);

            driver.findElement(By.xpath("//a//img[@id='formSelectorDropdown']")).click();
            waitFor(1000);

            driver.findElement(By.xpath("//span[contains(text(),'360*')]")).click();
            waitFor(10000);
            driver.switchTo().defaultContent();
            for (String s1: driver.getWindowHandles())
            {
                driver.switchTo().window(s1);
            }
            driver.switchTo().frame("contentIFrame");

            List <WebElement> CardList = driver.findElements(By.xpath("//div[@id='CustomerProductCards_divDataArea']//table[@id='gridBodyTable']/tbody/tr"));
            int CardCount = CardList.size();
            boolean Flag;
            Flag = false;
            for (int i=1;i<CardCount;i++) {
                String vProd = driver.findElement(By.xpath("//div[@id='CustomerProductCards_divDataArea']//table[@id='gridBodyTable']/tbody/tr["+i+"]/td[5]")).getText();
                if (!vProd.equals("")) {
                    ReportHelper.logReportStatus(LogStatus.PASS,"Card details verified successfully");
                    Flag = true;
                    break;
                }
            }

            if (Flag=false) {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Card list verified is not successful");
            }


        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Card Sync failed due to '"+e.getMessage()+"'");
        }

    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : CRM_GoalDetails_View
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void CRM_GoalDetails_View() {

        try {
            WebDriver driver=getLatestDriver();
            for(String sam:driver.getWindowHandles())
            {
                driver.switchTo().window(sam);
            }

            driver.switchTo().frame("contentIFrame");
            waitFor(3000);

            Robot rt = new Robot();
            rt.keyPress(KeyEvent.VK_ENTER);
            rt.keyRelease(KeyEvent.VK_ENTER);
            waitFor(3000);

            rt.keyPress(KeyEvent.VK_ENTER);
            rt.keyRelease(KeyEvent.VK_ENTER);

            waitFor(5000);

            driver.findElement(By.xpath("//a//img[@id='formSelectorDropdown']")).click();
            waitFor(1000);

            driver.findElement(By.xpath("//span[contains(text(),'360*')]")).click();
            waitFor(10000);
            driver.switchTo().defaultContent();
            for (String s1: driver.getWindowHandles())
            {
                driver.switchTo().window(s1);
            }
            driver.switchTo().frame("contentIFrame");

            List <WebElement> GoalList = driver.findElements(By.xpath(""));
            int GoalCount = GoalList.size();
            boolean Flag;
            Flag = false;
            for (int i=1;i<GoalCount;i++) {
                String vProd = driver.findElement(By.xpath("")).getText();
                if (!vProd.equals("")) {
                    ReportHelper.logReportStatus(LogStatus.PASS,"Goal details verified successfully");
                    Flag = true;
                    break;
                }
            }

            if (Flag=false) {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Goal list verified is not successful");
            }


        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Goal Details failed due to '"+e.getMessage()+"'");
        }

    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : CRM_Segment_Update
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void CRM_Segment_Update() {

        try {
            WebDriver driver=getLatestDriver();
            for(String sam:driver.getWindowHandles())
            {
                driver.switchTo().window(sam);
            }

            driver.switchTo().frame("contentIFrame");
            waitFor(3000);

            Robot rt = new Robot();
            rt.keyPress(KeyEvent.VK_ENTER);
            rt.keyRelease(KeyEvent.VK_ENTER);
            waitFor(3000);

            rt.keyPress(KeyEvent.VK_ENTER);
            rt.keyRelease(KeyEvent.VK_ENTER);

            waitFor(5000);

            driver.findElement(By.xpath("//a//img[@id='formSelectorDropdown']")).click();
            waitFor(1000);

            driver.findElement(By.xpath("//span[contains(text(),'360*')]")).click();
            waitFor(10000);
            driver.switchTo().defaultContent();
            for (String s1: driver.getWindowHandles())
            {
                driver.switchTo().window(s1);
            }
            driver.switchTo().frame("contentIFrame");
            driver.findElement(By.xpath("//img[@id='vrp_customersegment']")).click();

            // scripts to be added - WebPage Dialog


        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"Standing Order Instructions failed due to '"+e.getMessage()+"'");
        }

    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : Select_Statement
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void Select_Statement() throws AWTException {
        try {

            WebDriver driver = getLatestDriver();
            driver.findElement(By.xpath("//*[contains(text(),'Reports')]")).click();
            waitFor(5000);
            driver.switchTo().frame("contentIFrame");
            driver.findElement(By.id("crmGrid_findCriteria")).sendKeys(getData("StmtAcctName"), Keys.ENTER);
            waitFor(5000);

            ReportHelper.logReportStatus(LogStatus.PASS, getData("StmtAcctName")+" displayed Successfully");
            driver.findElement(By.xpath("//label[contains(text(),'Modified On')]")).click();
            waitFor(2000);

            List <WebElement> EStmt = driver.findElements(By.xpath("//table[@id='gridBodyTable']//tr/td[4]//a"));
            int EStmtCnt = EStmt.size();
/*            for (int i=1;i<EStmtCnt;i++) {
                if (i==EStmtCnt) {
                    driver.findElement(By.xpath("//table[@id='gridBodyTable']//tr[" + EStmtCnt + "]/td[3]//a/span")).click();
                    break;
                }
            }*/
            driver.findElement(By.xpath("//table[@id='gridBodyTable']//tr[" + EStmtCnt + "]/td[4]//a")).click();
            waitFor(25000);

/*            Robot rt = new Robot();
            rt.keyPress(KeyEvent.VK_ENTER);
            rt.keyRelease(KeyEvent.VK_ENTER);
            waitFor(3000);

            rt.keyPress(KeyEvent.VK_ENTER);
            rt.keyRelease(KeyEvent.VK_ENTER);*/

            waitFor(1000);
            ReportHelper.logReportStatus(LogStatus.PASS, getData("StmtAcctName")+" is Selected Successfully");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "EStatement Selection failed due to "+e.getMessage());
        }

    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : CRM_EStatement_OnePack
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void CRM_EStatement_OnePack() {

        try {
            WebDriver driver=getLatestDriver();
            for(String sam:driver.getWindowHandles())
            {
                driver.switchTo().window(sam);
            }

            driver.switchTo().frame("resultFrame");
            waitFor(3000);
            driver.findElement(By.name("reportViewer$ctl04$ctl03$txtValue")).clear();
            driver.findElement(By.name("reportViewer$ctl04$ctl03$txtValue")).sendKeys(getData("CustomerID"));
            driver.findElement(By.name("reportViewer$ctl04$ctl05$txtValue")).clear();
            driver.findElement(By.name("reportViewer$ctl04$ctl05$txtValue")).sendKeys(getData("FromDate"));
            driver.findElement(By.name("reportViewer$ctl04$ctl07$txtValue")).clear();
            driver.findElement(By.name("reportViewer$ctl04$ctl07$txtValue")).sendKeys(getData("ToDate"));
            driver.findElement(By.name("reportViewer$ctl04$ctl09$txtValue")).clear();
            driver.findElement(By.name("reportViewer$ctl04$ctl09$txtValue")).sendKeys(getData("AccountNo"));
            waitFor(1000);
            ReportHelper.logReportStatus(LogStatus.PASS,"EStatement fields entered successfully");
            driver.findElement(By.name("reportViewer$ctl04$ctl00")).click();
            waitFor(10000);

            driver.switchTo().defaultContent();
            ReportHelper.logReportStatus(LogStatus.PASS,"OnePack EStatement details displayed successfully");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL," OnePack EStatement failed due to '"+e.getMessage()+"'");
        }


    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : CRM_EStatement_CreditCard
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/

    public static void CRM_EStatement_CreditCard() {

        try {
            WebDriver driver=getLatestDriver();
            for(String sam:driver.getWindowHandles())
            {
                driver.switchTo().window(sam);
            }

            driver.switchTo().frame("resultFrame");
            waitFor(3000);
            driver.findElement(By.name("reportViewer$ctl04$ctl03$txtValue")).clear();
            driver.findElement(By.name("reportViewer$ctl04$ctl03$txtValue")).sendKeys(getData("FromDate"));
            driver.findElement(By.name("reportViewer$ctl04$ctl05$txtValue")).clear();
            driver.findElement(By.name("reportViewer$ctl04$ctl05$txtValue")).sendKeys(getData("ToDate"));
            driver.findElement(By.name("reportViewer$ctl04$ctl07$txtValue")).clear();
            driver.findElement(By.name("reportViewer$ctl04$ctl07$txtValue")).sendKeys(getData("CardAccountNo"));
            waitFor(1000);
            ReportHelper.logReportStatus(LogStatus.PASS,"EStatement fields entered successfully");
            driver.findElement(By.name("reportViewer$ctl04$ctl00")).click();
            waitFor(10000);

            driver.switchTo().defaultContent();
            ReportHelper.logReportStatus(LogStatus.PASS,"Credit Card EStatement details displayed successfully");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL," Credit Card EStatement failed due to '"+e.getMessage()+"'");
        }


    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : Beneficaiy active via CRM
     * Description    :
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/
/*

    public static void CRM_Launch() {


        try {
            openUrl(getURL("CRM~T2"));
            ReportHelper.logReportStatus(LogStatus.PASS, "CRM URL lanunched Successfully");
        }catch(Exception e)
        {
            ReportHelper.logReportStatus(LogStatus.FAIL, "CRM URL Launch Failes"+e.getMessage());
        }

    }
    public static void Select_Customer() throws AWTException {//Activate_Benefry_CRM
        try {
            WebDriver driver = getLatestDriver();


            driver.findElement(By.xpath("//*[contains(text(),'Contacts')]")).click();
            waitFor(5000);
            driver.switchTo().frame("contentIFrame");
            driver.findElement(By.id("crmGrid_findCriteria")).sendKeys(getData("UserID"), Keys.ENTER);
            waitFor(5000);
            driver.findElement(By.xpath("//table[@id='gridBodyTable']//tr/td[3]//a/span")).click();
            waitFor(25000);

            Robot rt = new Robot();
            rt.keyPress(KeyEvent.VK_ENTER);
            rt.keyRelease(KeyEvent.VK_ENTER);
            waitFor(3000);

            rt.keyPress(KeyEvent.VK_ENTER);
            rt.keyRelease(KeyEvent.VK_ENTER);

            waitFor(1000);
            ReportHelper.logReportStatus(LogStatus.PASS, getData("UserID")+" is Selected Successfully");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "User Selection failed due to "+e.getMessage());
        }


    }*/
    public static void Select_benefeciaries_Details()
    {
        try{
            WebDriver driver=getLatestDriver();
            for(String sam:driver.getWindowHandles())
            {
                driver.switchTo().window(sam);
            }

            driver.switchTo().frame("contentIFrame");
            waitFor(3000);
            driver.findElement(By.xpath("//a[@id='nav_vrp_contact_beneficiary']")).click();
            for(String sam:driver.getWindowHandles())
            {
                driver.switchTo().window(sam);
            }

            waitFor(10000);
            driver.switchTo().frame("contentIFrame");
            waitFor(2000);
            driver.switchTo().frame("vrp_contact_beneficiaryFrame");
            waitFor(2000);

            List<WebElement> fstname=driver.findElements(By.xpath("//table[@id='gridBodyTable']//tbody//tr/td[9]"));
            List<WebElement> lstname=driver.findElements(By.xpath("//table[@id='gridBodyTable']//tbody/tr/td[10]"));
            for (int i = 0; i < fstname.size(); i++) {
                System.out.println(fstname.get(i).getText() + "//" + (getData("BeneFirstNam")) + "----" + lstname.get(i).getText() + "//" + (getData("BeneLastNam")));
                if (fstname.get(i).getText().equalsIgnoreCase(getData("BeneFirstNam")) && lstname.get(i).getText().equalsIgnoreCase(getData("BeneLastNam"))) {
                    int cnt = i + 1;
                    driver.findElement(By.xpath("//table[@id='gridBodyTable']//tr[" + cnt + "]/td[3]//a")).click();
                    driver.switchTo().defaultContent();

                    waitFor(2000);

                    ReportHelper.logReportStatus(LogStatus.PASS, "Beneficairy details are Displayed");


                    break;

                }
            }
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Beneficairy details Display failed due to"+e.getMessage());
        }
    }
    public static void Select_benefeciaries_Active() {
        try {
            WebDriver driver = getLatestDriver();
            for (String sam : driver.getWindowHandles()) {
                driver.switchTo().window(sam);
            }

            waitFor(2000);

            driver.switchTo().frame("contentIFrame");

            System.out.println(driver.getPageSource());

            driver.findElement(By.xpath("//a[@id='vrp_beneficiary|NoRelationship|Form|Mscrm.Form.vrp_beneficiary.MainTab.Actions.Activate-Large']//img")).click();
            ReportHelper.logReportStatus(LogStatus.PASS, " Beneficairy details for " + getData("BeneFirstNam") + " is made Active from CRM");
            driver.close();
        }catch(Exception e)
        {
            ReportHelper.logReportStatus(LogStatus.FAIL, " Beneficary activation failed due to "+e.getMessage());
        }
    }
   /* for(String sam:driver.getWindowHandles())
        {
            driver.switchTo().window(sam);
        }
        waitFor(2000);
        driver.switchTo().frame("contentIFrame");
        waitFor(2000);
        driver.switchTo().frame("vrp_contact_beneficiaryFrame");
        waitFor(2000);*/
    // System.out.println(driver.findElement(By.xpath("//table[@id='gridBodyTable']//tr["+cnt+"]/td[17]//a")).getText());


    public static void benefeciaries_Validate() {
        try{
            WebDriver driver = getLatestDriver();
            for (String sam : driver.getWindowHandles()) {
                driver.switchTo().window(sam);
            }

            driver.switchTo().frame("contentIFrame");
            waitFor(3000);
            driver.findElement(By.xpath("//a[@id='nav_vrp_contact_beneficiary']")).click();
            for (String sam : driver.getWindowHandles()) {
                driver.switchTo().window(sam);
            }

            waitFor(10000);
            driver.switchTo().frame("contentIFrame");
            waitFor(2000);
            driver.switchTo().frame("vrp_contact_beneficiaryFrame");
            waitFor(2000);

            List<WebElement> fstname = driver.findElements(By.xpath("//table[@id='gridBodyTable']//tbody//tr/td[9]"));
            List<WebElement> lstname = driver.findElements(By.xpath("//table[@id='gridBodyTable']//tbody/tr/td[10]"));
            for (int i = 0; i < fstname.size(); i++) {
                System.out.println(fstname.get(i).getText() + "//" + (getData("BeneFirstNam")) + "----" + lstname.get(i).getText() + "//" + (getData("BeneLastNam")));
                if (fstname.get(i).getText().equalsIgnoreCase(getData("BeneFirstNam")) && lstname.get(i).getText().equalsIgnoreCase(getData("BeneLastNam"))) {
                    int cnt = i + 1;
                    driver.findElement(By.xpath("//table[@id='gridBodyTable']//tr[" + cnt + "]/td[3]//a")).click();
                    driver.switchTo().defaultContent();

                    waitFor(2000);
                    for (String sam : driver.getWindowHandles()) {
                        driver.switchTo().window(sam);
                    }

                    waitFor(2000);
                    String fname=driver.findElement(By.id("vrp_firstname")).getAttribute("value");
                    String lname=driver.findElement(By.id("vrp_lastname")).getAttribute("value");
                    System.out.println(fname+"   "+lname);

                    if(fname.equalsIgnoreCase(getData("BeneFirstNam")) && lname.equalsIgnoreCase(getData("BeneLastNam"))) {

                        ReportHelper.logReportStatus(LogStatus.PASS, "Validation of Beneficaries details in CRM is Successful");
                    }else {
                        ReportHelper.logReportStatus(LogStatus.FAIL, "Validation of Beneficaries details in CRM is Unsuccessful");
                    }
                    driver.close();
                    driver.close();
                    break;

                }
            }}catch(Exception e)
        {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Failed In Beneficiary  validation due to :"+e.getMessage());
        }
    }

    public static void RDI_Launch() {


        try {
            openUrl(getURL("RDI_IB~T2"));
            ReportHelper.logReportStatus(LogStatus.PASS, "Retail  URL lanunched Successfully");
        }catch(Exception e)
        {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Retail URL Launch Failes"+e.getMessage());
        }

    }
    public static void RDI_Onboard() {


        try {
            WebDriver driver=  getLatestDriver();
            System.out.println(driver.getPageSource());
            driver.switchTo().frame(driver.findElement(By.xpath("//frame[@src='AppCheck.aspx?rc=&culture=&startpage=&PID=']")));
            driver.findElement(By.xpath("//a[contains(.,'Apply now')]")).click();

            Select dropdown=new Select(driver.findElement(By.xpath("//div[@id='slideContainer']//select")));
            dropdown.selectByVisibleText(getData("CustomerTitle"));
            driver.findElement(By.xpath("//input[@id='txtIqamaNumber']")).sendKeys(getData("IQAMA"));
            String dob[]=getData("DOB").split("-");
            driver.findElement(By.xpath("//input[@id='txtDOBDay']")).sendKeys(dob[0]);
            driver.findElement(By.xpath("//input[@id='txtDOBMonth']")).sendKeys(dob[1]);
            driver.findElement(By.xpath("//input[@id='txtDOBYear']")).sendKeys(dob[2]);

            driver.findElement(By.xpath("//ul[@class='basicInfo']//input[@placeholder='example@email.com']")).sendKeys(getData("Email"));
            driver.findElement(By.xpath("//input[@id='txtResidenceTelephoneNumber']")).sendKeys(getData("ResidenceNumber"));
            driver.findElement(By.xpath("//input[@id='txtPrimaryMobile']")).sendKeys(getData("MobileNumber"));
            driver.findElement(By.xpath("//input[@placeholder='Please Enter Country']")).sendKeys(getData("Country"));
            driver.findElement(By.xpath(" //div[@class='autocomplete-suggestion'][@data-val='"+getData("Country").toUpperCase()+"']")).click();

            driver.findElement(By.xpath("//div[@class='Table Checkbox']//input")).click();


            driver.findElement(By.xpath("//div[@class='MobileVerifybtn Verifybtnbutton1']//ul/li/a[contains(text(),'Verify')]")).click();
            String otp=FetchOTP.getOTP();
            driver.findElement(By.xpath("//input[@id='txtOTP']")).sendKeys(otp);

            driver.findElement(By.xpath("//div[@class='buttoncontrol']/ul/li/a[contains(text(),'Next')]")).click();


///account Registarion
            waitTillElementIsVisible( driver.findElement(By.xpath("//label[contains(text(),'Salary')]")));
            driver.findElement(By.xpath("//label[contains(text(),'Salary')]")).click();
            Select occupation=new Select(driver.findElement(By.xpath("//div[@id='dvEmployee']//select")));
            occupation.selectByVisibleText(getData("Occupation"));
            driver.findElement(By.xpath("//div[@id='dvEmployee']//input[@id='txtAutoComplete']")).sendKeys(getData("EmployerName"));
            driver.findElement(By.xpath(" //div[@class='autocomplete-suggestion'][@data-val='"+getData("EmployerName")+"']")).click();

            Select monthlyIncome=new Select(driver.findElement(By.xpath("//div[@id='slideContainer']/ul/li[5]/select")));
            monthlyIncome.selectByIndex(Integer.parseInt(getData("salary_slot")));


            Select education=new Select(driver.findElement(By.xpath("//div[@id='slideContainer']/ul/li/label[contains(text(),'Level of education')]/following::li[1]/select")));
            education.selectByVisibleText(getData("Education"));

            Select Martial=new Select(driver.findElement(By.xpath(" //div[@id='slideContainer']/ul/li/label[contains(text(),'Martial Status')]/following::li[1]/select")));
            Martial.selectByVisibleText(getData("MaritalStatus"));

            driver.findElement(By.xpath(" //div[@id='slideContainer']/ul/li/label[contains(text(),'Number of Dependents')]/following::li[1]/input")).sendKeys(getData("NumberofDependent"));
            driver.findElement(By.xpath("//label[contains(text(),'Savings')]")).click();

            List<WebElement> ele=driver.findElements(By.xpath("//div[@class='radioButtonList']//label[contains(text(),'No')]"));
            for(WebElement ele1:ele)
            {
                ele1.click();
            }
            driver.findElement(By.xpath("//div[@class='onboardingTandCCon']//input[@type='checkbox']")).click();
            driver.findElement(By.xpath("//a[contains(text(),'Submit')]")).click();




            ReportHelper.logReportStatus(LogStatus.PASS, "Retail Onboading is successfull");
        }catch(Exception e)
        {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Retail Onboading Failes due to "+e.getMessage());
        }

    }



    public static void PF_Onboarding()  {
        try{

            initPageObjects();
            getLatestDriver();
            switchDFrame(1);
            click(po_RDI_IB.Button_Products);
            click(po_RDI_IB.Button_PF);
            click(po_RDI_IB.Link_ApplyPF);

            int text;
            WebDriverWait wait = new WebDriverWait(getLatestDriver(), 5);
/*    boolean str=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("'//a[contains(text(),'Resume Application')]'"))).isEnabled();
//text=getLatestDriver().findElements(By.xpath("'//a[contains(text(),'Resume Application')]'")).size();
if(str=false)
{*/
            //click(po_RDI_IB.Button_resumePF);

            click(po_RDI_IB.Button_ApplyPF);
/*}
 click(po_RDI_IB.Button_ApplyPF);
  */        /*  try{


            }catch(Exception e)
            {
                click(po_RDI_IB.Button_resumePF);
            }*/

          /*  if (elemExist(po_RDI_IB.Button_ApplyPF) == true) {
                click(po_RDI_IB.Button_ApplyPF);
            } else {

            }*/

            waitTillElementIsVisible(po_RDI_IB.Checkpage);
            System.out.println(getData("EmployerName"));
           /* sendKeys(po_RDI_IB.TxtBox_EmployerName,getData("EmployerName"));

            click("//*[@class='autocomplete-suggestion'][@data-val='"+getData("EmployerName")+"']");*/

            sendKeys(po_RDI_IB.TxtBox_PF_Amount,getData("PF_Amount"));
            Select tenure=new Select(po_RDI_IB.TxtBox_PF_Tenure);
            tenure.selectByVisibleText(getData("PF_Tenure"));
            click(po_RDI_IB.BTN_Apply);
            waitFor(3000);

            getLatestDriver().findElement(By.xpath("//a[contains(text(),'"+getData("Purpose")+"')]")).click();
            getLatestDriver().findElement(By.xpath("//a[contains(text(),'"+getData("PeriodInJob")+"')]")).click();
            getLatestDriver().findElement(By.xpath("//a[contains(text(),'"+getData("WorkExperiece")+"')]")).click();
            getLatestDriver().findElement(By.xpath("//a[contains(text(),'"+getData("MaritalStatus")+"')]")).click();
            getLatestDriver().findElement(By.xpath("//a[contains(text(),'"+getData("Education")+"')]")).click();
            getLatestDriver().findElement(By.xpath("//a[contains(text(),'"+getData("LivingArrangements")+"')]")).click();
            waitFor(1000);
            getLatestDriver().findElement(By.xpath("//div[@class='salaried-container tab-content'][2]//input")).clear();
            getLatestDriver().findElement(By.xpath("//div[@class='salaried-container tab-content'][2]//input")).sendKeys(getData("MonthlySalary"));
            getLatestDriver().findElement(By.xpath("//a[contains(text(),'"+getData("SalaryACcOpenenedPeriod")+"')]")).click();
            Button_GoalArrowDown.click();
            waitFor(2000);
            Button_GoalArrowDown.click();
            waitFor(2000);

            Button_GoalArrowDown.click();
            waitFor(2000);
            Button_GoalArrowDown.click();
            waitFor(2000);
            click(po_RDI_IB.BTN_Submit);
            waitTillElementIsVisible(po_RDI_IB.SuccessMessage);

            String sucessmsg=po_RDI_IB.SuccessMessage.getText();
            if(sucessmsg.equalsIgnoreCase("we have successfully received your application! We will contact you within two working days. "))
            {
                logReportStatus(LogStatus.PASS,"PF onboarding application succcessfully processed");

            }else {
                logReportStatus(LogStatus.FAIL,"PF onboarding is failed due to:"+sucessmsg);
            }


        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"FCY Account - Move Money failed due to '" +e.getMessage()+"'");
        }

    }

    public static void CreditCard_creation()  {
        try{

            initPageObjects();
            getLatestDriver();
            switchDFrame(1);
            click(po_RDI_IB.Button_Products);
            click(po_RDI_IB.CreditCard);
            waitFor(2000);
            //click(po_RDI_IB.CreditCard_apply);
            waitFor(2000);
            Button_GoalArrowDown.click();
            waitFor(2000);
            Button_GoalArrowDown.click();
            waitFor(2000);
            Button_GoalArrowDown.click();
            waitFor(2000);
            Button_GoalArrowDown.click();


            //   click(po_RDI_IB.Link_ApplyPF);
            click(po_RDI_IB.Button_resumePF);



            waitFor(5000);
            // waitTillElementIsVisible(po_RDI_IB.Checkpage);
            // System.out.println(getData("EmployerName"));
            sendKeys(po_RDI_IB.TxtBox_EmployerName,getData("EmployerName"));

            //click("//*[@class='autocomplete-suggestion'][@data-val='"+getData("EmployerName")+"']");

            click(po_RDI_IB.BTN_Apply);
            waitFor(3000);

            //    getLatestDriver().findElement(By.xpath("//a[contains(text(),'"+getData("Purpose")+"')]")).click();
            getLatestDriver().findElement(By.xpath("//a[contains(text(),'"+getData("PeriodInJob")+"')]")).click();
            getLatestDriver().findElement(By.xpath("//a[contains(text(),'"+getData("WorkExperiece")+"')]")).click();
            getLatestDriver().findElement(By.xpath("//a[contains(text(),'"+getData("MaritalStatus")+"')]")).click();
            getLatestDriver().findElement(By.xpath("//a[contains(text(),'"+getData("Education")+"')]")).click();
            getLatestDriver().findElement(By.xpath("//a[contains(text(),'"+getData("LivingArrangements")+"')]")).click();
            waitFor(1000);
            //getLatestDriver().findElement(By.xpath("//div[@class='salaried-container tab-content'][2]//input")).clear();

            sendKeys(po_RDI_IB.TXTBankwherepaid,getData("BankwherePaid"));
            getLatestDriver().findElement(By.xpath("//div[@class='salaried-container tab-content'][2]//input")).sendKeys(getData("MonthlySalary"));

            for(int i=0;i<15;i++)
            {

                Button_GoalArrowDown.click();
                waitFor(2000);

            }


            getLatestDriver().findElement(By.xpath("//a[contains(text(),'"+getData("SalaryACcOpenenedPeriod")+"')]")).click();


            getLatestDriver().findElement(By.xpath("//a[contains(text(),'"+getData("PaymentInstruction")+"')]")).click();

            click(po_RDI_IB.BTN_YES);
            click(po_RDI_IB.BTN_Submit);



            waitTillElementIsVisible(po_RDI_IB.SuccessMessage);

            String sucessmsg=po_RDI_IB.SuccessMessage.getText();
            if(sucessmsg.equalsIgnoreCase("we have successfully received your application! We will contact you within two working days. "))
            {
                logReportStatus(LogStatus.PASS,"PF onboarding application succcessfully processed");

            }else {
                logReportStatus(LogStatus.FAIL,"PF onboarding is failed due to:"+sucessmsg);
            }








        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL,"FCY Account - Move Money failed due to '" +e.getMessage()+"'");
        }

    }










    /**********************************************************************************************************************************/
    /*
     * Function Name : Booking_TermDeposit
     * Description    : Enters required details for term deposit and clicks on continue button.
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/
    public static void Booking_TermDeposit(){
        try{
            int iCol=0;
            int j=0;
            String Interest="";
            String MaturityAmt="";
            WebElement RateofInterest=null;
            WebElement MaturityInstructionsbutton=null;
            WebElement AccTransferFundFrom=null;
            WebElement AccTransferFundTo=null;
            initPageObjects();
            getLatestDriver().switchTo().defaultContent();
            switchDFrame(1);

            Select Currency=new Select(po_RDI_IB.Select_Currency);
            Currency.selectByValue(getData("Currency"));

            waitFor(1000);

            String[] Term_Period={"30 Days","90 Days","180 Days","360 Days","720 Days"};

            for (int i=1;i<=Term_Period.length;i++){
                if (Term_Period[i].contains(getData("TermPeriodDays"))){
                    iCol=i+1;
                    break;
                }
            }

            j=Integer.parseInt(getData("BatchNumber"))+1;

            RateofInterest= getLatestDriver().findElement(By.xpath("//*[contains(@id,'ratesMatrix')]/tbody/tr["+j+"]/td["+iCol+"]/a"));
            Interest=RateofInterest.getText();
            saveTestDataToDb("InterestRate",Interest);
            RateofInterest.click();

            waitFor(2000);

            po_RDI_IB.List_TransferFundFrom.click();
            waitFor(1000);
            AccTransferFundFrom=getLatestDriver().findElement(By.xpath("//*[@id='UserAccounts']//div[@class='selectize-dropdown single']//div[@class='selectize-dropdown-content']/div/div[text()='"+getData("TransferFromAccountName")+"']"));
            waitFor(2000);
            AccTransferFundFrom.click();

            sendKeys(po_RDI_IB.Input_AmountTD,getData("DepositAmount"));
            waitFor(1000);

            if (elemExist(po_RDI_IB.WebElement_ErrorMsg1) || elemExist(po_RDI_IB.WebElement_ErrorMsg1)) {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Valid Deposit Amount not entered");
            }else{
                forceScreenShot=true;
                ReportHelper.logReportStatus(LogStatus.INFO,"Valid Deposit Amount is entered");
            }

            if (getData("MaturityInstruction").equalsIgnoreCase("TransferProfit")){
                MaturityInstructionsbutton=po_RDI_IB.Button_TransferProfit;
            }else if (getData("MaturityInstruction").equalsIgnoreCase("ReinvestPrincipalProfit")){
                MaturityInstructionsbutton=po_RDI_IB.Button_ReinvestPrincipalProfit;
            }else {
                MaturityInstructionsbutton=po_RDI_IB.Button_TransferPrincipalProfit;
            }

            MaturityInstructionsbutton.click();

            waitFor(2000);

            po_RDI_IB.List_TransferFundTo.click();

            for (int count=1;count<=8;count++){
                po_RDI_IB.WebElement_DownArrow.click();
                waitFor(1000);
            }

            AccTransferFundTo=getLatestDriver().findElement(By.xpath("//*[@id='MaturityAccounts']//div[@class='selectize-dropdown single']//div[@class='selectize-dropdown-content']/div/div[text()='"+getData("TransferToAccountName")+"']"));
            waitFor(2000);
            AccTransferFundTo.click();

            po_RDI_IB.Chkbox_TermsandConditions.click();

            forceScreenShot=true;
            ReportHelper.logReportStatus(LogStatus.INFO,"Term Deposit details are entered successfully");

            po_RDI_IB.Button_Continue.click();

            waitFor(1000);

            if (elemExist(po_RDI_IB.WebElement_IntendedPurchase)){
                ReportHelper.logReportStatus(LogStatus.PASS,"Term Deposit details was successfully filled in 'Book Your Murabha deposit' page and Navigated successfully to Intended Purchase page");
            }else{
                ReportHelper.logReportStatus(LogStatus.FAIL,"Navigation to Intended Purchase page failed.");
            }

        }
        catch (Exception e){
            ReportHelper.logReportStatus(LogStatus.FAIL,"Booking term deposit failed in booking term deposit page due to '"+e.getMessage()+"'");
        }
    }
    /**********************************************************************************************************************************/
    /*
     * Function Name : IntendedPurchase_TermDeposit
     * Description    : Validates term deposit values populated and clicks on continue button.
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/
    public static void IntendedPurchase_TermDeposit(){
        try{
            String PurchasePrice="";
            String MurabahaProfitRate="";
            String DeferredSalesPrice="";
            String CommoditiesDesc="";

            initPageObjects();
            getLatestDriver().switchTo().defaultContent();
            switchDFrame(1);

            PurchasePrice=po_RDI_IB.WebElement_PurchasePrice.getText();
            MurabahaProfitRate=po_RDI_IB.WebElement_MurabahaProfitRate.getText();
            DeferredSalesPrice=po_RDI_IB.WebElement_DeferredSalePrice.getText();
            CommoditiesDesc=po_RDI_IB.WebElement_CommodityDescription.getText();
            saveTestDataToDb("Commodity",CommoditiesDesc);
            if (PurchasePrice.replace(",","").contains(getData("DepositAmount"))){
                ReportHelper.logReportStatus(LogStatus.PASS,"Purchase amount was displayed as Deposit amount:'"+PurchasePrice+"' as expected");
            }else {
                forceScreenShot=true;
                ReportHelper.logReportStatus(LogStatus.INFO,"Purchase amount was not displayed as Deposit amount and is displayed as"+PurchasePrice);
            }

            if (Double.parseDouble(MurabahaProfitRate.replace("%",""))==Double.parseDouble(getData("InterestRate").replace("%",""))){
                ReportHelper.logReportStatus(LogStatus.PASS,"Interest Rate was displayed as Murabaha Profit Rate:'"+MurabahaProfitRate+"' as expected");
            }else {
                forceScreenShot=true;
                ReportHelper.logReportStatus(LogStatus.INFO,"Interest Rate was not displayed as Murabaha Profit Rate and is displayed as"+MurabahaProfitRate);
            }

            saveTestDataToDb("MaturityAmount",DeferredSalesPrice);

            po_RDI_IB.Button_Continue.click();

            waitFor(3000);

            if (elemExist(po_RDI_IB.WebElement_OffertoSellCommodities)){
                ReportHelper.logReportStatus(LogStatus.PASS,"After validating Intended Purchase page, navigated to Offer to Sell Commodities page successfully");
            }else{
                ReportHelper.logReportStatus(LogStatus.FAIL,"Navigation to Offer to Sell Commodities page failed.");
            }

        }
        catch(Exception e){
            ReportHelper.logReportStatus(LogStatus.FAIL,"Validating term deposit values in Intend purchase page failed due to '"+e.getMessage()+"'");
        }
    }
    /**********************************************************************************************************************************/
    /*
     * Function Name : Offer_To_SellCommodities
     * Description    : Validates term deposit values populated and clicks on Sell or delivery button.
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/
    public static void Offer_To_SellCommodities(){
        try{
            String PurchasePrice="";
            String CommoditiesDesc="";
            String PurchaseSuccessMsg="";

            initPageObjects();
            getLatestDriver().switchTo().defaultContent();
            switchDFrame(1);

            PurchasePrice=po_RDI_IB.WebElement_PurchasePrice.getText();
            CommoditiesDesc=po_RDI_IB.WebElement_CommodityDescription.getText();

            if (CommoditiesDesc.contains(getData("Commodity"))){
                ReportHelper.logReportStatus(LogStatus.PASS,"Description of Commodities was displayed as '"+CommoditiesDesc+"', as expected");
            }else {
                forceScreenShot=true;
                ReportHelper.logReportStatus(LogStatus.INFO,"Description of Commodities was not displayed as expected and is displayed as"+CommoditiesDesc);
            }

            if (PurchasePrice.replace(",","").contains(getData("DepositAmount"))){
                ReportHelper.logReportStatus(LogStatus.PASS,"Purchase amount was displayed as Deposit amount:'"+PurchasePrice+"' as expected");
            }else {
                forceScreenShot=true;
                ReportHelper.logReportStatus(LogStatus.INFO,"Purchase amount was not displayed as Deposit amount and is displayed as"+PurchasePrice);
            }

            po_RDI_IB.Button_Continue.click();

            waitFor(3000);

            if (elemExist(po_RDI_IB.Button_Sell) && elemExist(po_RDI_IB.Button_Delivery)) {
                PurchaseSuccessMsg=po_RDI_IB.WebElement_PurchaseSuccessMessage.getText();
                ReportHelper.logReportStatus(LogStatus.PASS,"After clicking 'Accept' button, Sell and Delivery buttons were displayed and Success message was displayed as :"+PurchaseSuccessMsg);
            }else{
                ReportHelper.logReportStatus(LogStatus.FAIL,"After clicking 'Accept' button, Sell and Delivery buttons were not displayed");
            }

            if (getData("PurchaseType").equalsIgnoreCase("SELL")){
                po_RDI_IB.Button_Sell.click();
            }else {
                po_RDI_IB.Button_Delivery.click();
            }

            waitFor(3000);

            if (elemExist(po_RDI_IB.WebElement_BankOffer)){
                ReportHelper.logReportStatus(LogStatus.PASS,"After Validating term deposit details in Offer to sell commodities page and Clicking on '"+getData("PurchaseType")+"', navigated to Bank's Offer to purchase page successfully");
            }else{
                ReportHelper.logReportStatus(LogStatus.FAIL,"Navigation to Bank's Offer to purchase page failed.");
            }
        }
        catch (Exception e){
            ReportHelper.logReportStatus(LogStatus.FAIL,"Validating term deposit values in Offer to Sell Commodities failed due to '"+e.getMessage()+"'");
        }
    }
    /**********************************************************************************************************************************/
    /*
     * Function Name : BankOffer_To_Purchase
     * Description    : Validates term deposit values populated and clicks on accept button.
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/
    public static void BankOffer_To_Purchase(){
        try{
            String PurchasePrice="";
            String MurabahaProfitRate="";
            String DeferredSalesPrice="";
            String CommoditiesDesc="";
            String SuccessMsg="";

            initPageObjects();
            getLatestDriver().switchTo().defaultContent();
            switchDFrame(1);

            PurchasePrice=po_RDI_IB.WebElement_PurchasePrice.getText();
            MurabahaProfitRate=po_RDI_IB.WebElement_MurabahaProfitRate.getText();
            DeferredSalesPrice=po_RDI_IB.WebElement_DeferredSalePrice.getText();
            CommoditiesDesc=po_RDI_IB.WebElement_CommodityDescription.getText();

            if (CommoditiesDesc.contains(getData("Commodity"))){
                ReportHelper.logReportStatus(LogStatus.PASS,"Description of Commodities was displayed as '"+CommoditiesDesc+"', as expected");
            }else {
                forceScreenShot=true;
                ReportHelper.logReportStatus(LogStatus.INFO,"Description of Commodities was not displayed as expected and is displayed as"+CommoditiesDesc);
            }

            if (PurchasePrice.replace(",","").contains(getData("DepositAmount"))){
                ReportHelper.logReportStatus(LogStatus.PASS,"Purchase amount was displayed as Deposit amount:'"+PurchasePrice+"' as expected");
            }else {
                forceScreenShot=true;
                ReportHelper.logReportStatus(LogStatus.INFO,"Purchase amount was not displayed as Deposit amount and is displayed as"+PurchasePrice);
            }

            if (Double.parseDouble(MurabahaProfitRate.replace("%",""))==Double.parseDouble(getData("InterestRate").replace("%",""))){
                ReportHelper.logReportStatus(LogStatus.PASS,"Interest Rate was displayed as Murabaha Profit Rate:'"+MurabahaProfitRate+"' as expected");
            }else {
                forceScreenShot=true;
                ReportHelper.logReportStatus(LogStatus.INFO,"Interest Rate was not displayed as Murabaha Profit Rate and is displayed as"+MurabahaProfitRate);
            }

            if (DeferredSalesPrice.replace(",","").contains(getData("MaturityAmount"))){
                ReportHelper.logReportStatus(LogStatus.PASS,"Maturity amount was displayed as Deferred Sales Price:'"+DeferredSalesPrice+"' as expected");
            }else {
                forceScreenShot=true;
                ReportHelper.logReportStatus(LogStatus.INFO,"Maturity amount was not displayed as Deferred Sales Price and is displayed as"+DeferredSalesPrice);
            }

            po_RDI_IB.Button_Continue.click();

            waitFor(10000);

            switchDFrame(1);

            if (elemExist(po_RDI_IB.WebElement_TDSuccessMsg)){
                SuccessMsg=po_RDI_IB.WebElement_TDSuccessMsg.getText();
                ReportHelper.logReportStatus(LogStatus.PASS,"Murabaha Deposit was successfully created with Purchase type as '"+getData("PurchaseType")+"' and Success message was displayed as:"+SuccessMsg);
            }else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Murabaha Deposit creation was not successfull");
            }

            for (int count=1;count<=5;count++){
                po_RDI_IB.WebElement_DownArrow.click();
                waitFor(1000);
            }

            po_RDI_IB.Button_ConfirmOK.click();

            waitFor(3000);

            if (elemExist(po_RDI_IB.WebElement_HomeAccounts)){
                ReportHelper.logReportStatus(LogStatus.PASS,"When clicked 'OK' button, after successful Murahaba Deposit account creation, Home page was displayed as expected");
            }else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Navigation to Home page failed");
            }
        }
        catch (Exception e){
            ReportHelper.logReportStatus(LogStatus.FAIL,"Validating term deposit values in Bank Offer to purchase page failed due to '"+e.getMessage()+"'");
        }
    }
    /**********************************************************************************************************************************/
    /*
     * Function Name : Select_TermDeposit
     * Description    : Selects the term deposit in the home page.
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/
    public static void Select_TermDeposit(){
        try{

            initPageObjects();
            getLatestDriver().switchTo().defaultContent();
            switchDFrame(1);

            List <WebElement> ListTermDeposit=getLatestDriver().findElements(By.xpath("//*[contains(text(),'Murabaha deposit')]/following::div//*[contains(text(),'"+getData("Currency")+"')]/following::p[contains(text(),'"+getData("DepositAmount")+"')]"));
            List <WebElement> AccountBalance=getLatestDriver().findElements(By.xpath("//*[contains(text(),'"+getData("AccountName")+"')]/following::div[@class='accountsRight']/div/p[2]"));

            saveTestDataToDb("AccountBalance",AccountBalance.get(0).getText().replace(" ",""));

            if (ListTermDeposit.size()>0) {

                forceScreenShot=true;
                ReportHelper.logReportStatus(LogStatus.PASS,"Murabaha account for the currency '"+getData("Currency")+"' and Deposit Amount '"+getData("DepositAmount")+"' is present");

                ListTermDeposit.get(0).click();

                waitFor(5000);

                if (elemExist(po_RDI_IB.WebElement_TermDepositDetails)) {
                    ReportHelper.logReportStatus(LogStatus.PASS,"Murabaha account for the currency '"+getData("Currency")+"' and Deposit Amount '"+getData("DepositAmount")+"' was selected and navigation to Murabaha Deposit details page was successful");
                }
                else {
                    ReportHelper.logReportStatus(LogStatus.FAIL,"Navigation to Murabaha Deposit details page failed");
                }

            }else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"No Murabaha account present for the currency '"+getData("Currency")+"' and Deposit Amount '"+getData("DepositAmount")+"'");
            }
        }
        catch (Exception e){
            ReportHelper.logReportStatus(LogStatus.FAIL,"Selection of Murabaha account, for cancellation, failed due to '"+e.getMessage()+"'");
        }
    }

    /**********************************************************************************************************************************/
    /*
     * Function Name : MurabahaDepositDetails
     * Description    : Validates term deposit value and cancels the term deposit.
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/
    public static void MurabahaDepositDetails(){
        try{
            String DepositAmount="";
            String EstimatedValue="";
            String PresentValue="";
            WebElement eleEstimatedValue=null;
            WebElement elePresentValue=null;

            initPageObjects();
            getLatestDriver().switchTo().defaultContent();
            switchDFrame(1);

            DepositAmount=po_RDI_IB.WebElement_DepositAmount.getText();
            if (DepositAmount.equals(getData("DepositAmount"))) {
                ReportHelper.logReportStatus(LogStatus.INFO,"Term Deposit Amount is displayed as expected, "+DepositAmount);
            }
            else {
                forceScreenShot=true;
                ReportHelper.logReportStatus(LogStatus.INFO,"Term Deposit Amount is not displayed as expected and is displayed as"+DepositAmount);
            }

            eleEstimatedValue=getLatestDriver().findElement(By.xpath("//*[contains(text(),'estimated value at maturity')]/following::td[2]/*[contains(text(),'"+getData("Currency")+"')]"));
            elePresentValue=getLatestDriver().findElement(By.xpath("//*[contains(text(),'Value Until Yesterday')]/following::td[2]/*[contains(text(),'"+getData("Currency")+"')]"));

            if (elemExist(eleEstimatedValue)&&elemExist(elePresentValue)){
                EstimatedValue=eleEstimatedValue.getText();
                PresentValue=elePresentValue.getText();
                saveTestDataToDb("PresentValue",PresentValue);
                ReportHelper.logReportStatus(LogStatus.PASS,"Term Deposit values, Estimated value :'"+EstimatedValue+"', Present value :'"+DepositAmount+"' are displayed as expected");
            }
            else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Term Deposit values are not displayed");
            }

            po_RDI_IB.WebElement_CancelMurabahaDeposit.click();

            waitFor(2000);

            if (elemExist(po_RDI_IB.Button_CancelMurabahaDeposit)){
                ReportHelper.logReportStatus(LogStatus.PASS,"After selecting Cancel Murabaha Deposit option, Cancel Murabaha Deposit button is displayed");
                po_RDI_IB.Button_CancelMurabahaDeposit.click();
                waitFor(2000);
            }
            else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"After selecting Cancel Murabaha Deposit option, Cancel Murabaha Deposit button is not displayed");
            }

            if (elemExist(po_RDI_IB.WebElement_CancelTermDepositPayPenalty)){
                ReportHelper.logReportStatus(LogStatus.PASS,"After Clicking Cancel Murabaha Deposit option, Cancel Term Deposit and Pay penalty page is displayed");
            }
            else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"After Clicking Cancel Murabaha Deposit option, Cancel Term Deposit and Pay penalty page is not displayed");
            }
        }
        catch(Exception e){
            ReportHelper.logReportStatus(LogStatus.FAIL,"Validation of Murabaha account details, for cancellation, failed due to '"+e.getMessage()+"'");
        }

    }
    /**********************************************************************************************************************************/
    /*
     * Function Name : ConfirmMurabahaDepositCancellation
     * Description    : Confirms MurabahaDepositCancellation
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/
    public static void ConfirmMurabahaDepositCancellation(){
        try{

            initPageObjects();
            getLatestDriver().switchTo().defaultContent();
            switchDFrame(1);

            po_RDI_IB.Button_ConfirmCancelTermDeposit.click();
            String CurrentBalance="";

            waitFor(5000);

            if (elemExist(po_RDI_IB.WebElement_HomeAccounts)){
                ReportHelper.logReportStatus(LogStatus.PASS,"When 'Confirm' button is clicked, after successful Murahaba Deposit account cancellation, Home page was displayed as expected");
            }else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Navigation to Home page failed");
            }

            List <WebElement> AccountBalance=getLatestDriver().findElements(By.xpath("//*[contains(text(),'"+getData("AccountName")+"')]/following::div[@class='accountsRight']/div/p[2]"));
            CurrentBalance=AccountBalance.get(0).getText().replace(" ","").replace(",","");

            if (Double.parseDouble(CurrentBalance)==Double.parseDouble(getData("AccountBalance").replace(",",""))+
                    Double.parseDouble(getData("PresentValue").replace(getData("Currency")+" ","").replace(",","")))
            {
                ReportHelper.logReportStatus(LogStatus.PASS,"After Term Deposit Cancellation, the Account balance of the Account credited is updated from '"+getData("AccountBalance")+"' to '"+CurrentBalance+"");
            }else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"After Term Deposit Cancellation, the Account balance of the Account credited is not updated as expected, and displayed as '"+CurrentBalance+"");
            }
        }
        catch (Exception e){
            ReportHelper.logReportStatus(LogStatus.FAIL,"Confirmation of Murabaha account cancellation, failed due to '"+e.getMessage()+"'");
        }
    }
    /**********************************************************************************************************************************/
    /*
     * Function Name : MurabahaEmergencyWithdraw
     * Description    : Select Emergency Funds for withdrawal
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/
    public static void MurabahaEmergencyWithdraw(){
        try{
            String DepositAmount="";

            initPageObjects();
            getLatestDriver().switchTo().defaultContent();
            switchDFrame(1);

            DepositAmount=po_RDI_IB.WebElement_DepositAmount.getText();
            if (DepositAmount.equals(getData("DepositAmount"))) {
                ReportHelper.logReportStatus(LogStatus.INFO,"Term Deposit Amount is displayed as expected, "+DepositAmount);
            }
            else {
                forceScreenShot=true;
                ReportHelper.logReportStatus(LogStatus.INFO,"Term Deposit Amount is not displayed as expected and is displayed as"+DepositAmount);
            }

            po_RDI_IB.WebElement_EmergencyFund.click();

            waitFor(3000);

            if (elemExist(po_RDI_IB.Input_EmergencyFund) && elemExist(po_RDI_IB.Button_TransfertoRelevantAccount)){
                ReportHelper.logReportStatus(LogStatus.PASS,"After selecting Emergency Fund Withdraw option, Emergency Fund Withdraw text box and Transfer to relevant account button are displayed");
                po_RDI_IB.Input_EmergencyFund.clear();
                waitFor(1000);
                po_RDI_IB.Input_EmergencyFund.sendKeys(getData("EmergencyFund"));
                waitFor(2000);
                po_RDI_IB.Button_TransfertoRelevantAccount.click();
            }
            else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"After selecting Cancel Murabaha Deposit option, Emergency Fund Withdraw text box and Transfer to relevant account button are not displayed");
            }

            waitFor(3000);

            if (elemExist(po_RDI_IB.WebElement_EmergencyFundsWithdraw)){
                ReportHelper.logReportStatus(LogStatus.PASS,"After entering emergency fund as '"+getData("EmergencyFund")+"' and Transfer to relevant account button, Emergency Funds Withdraw page is displayed");
            }
            else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"After entering emergency fund as '"+getData("EmergencyFund")+"' and Transfer to relevant account button, Emergency Funds Withdraw page is not displayed");
            }

        }
        catch (Exception e){
            ReportHelper.logReportStatus(LogStatus.FAIL,"Entering Emergency Fund failed due to '"+e.getMessage()+"'");
        }
    }
    /**********************************************************************************************************************************/
    /*
     * Function Name : ConfirmMurabahaDepositEmergencyWithdraw
     * Description    : Confirms Murabaha Deposit Emergency Withdraw
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/
    public static void ConfirmMurabahaDepositEmergencyWithdraw(){
        try{

            initPageObjects();
            getLatestDriver().switchTo().defaultContent();
            switchDFrame(1);

            po_RDI_IB.Button_ConfirmCancelTermDeposit.click();
            String CurrentBalance="";

            waitFor(5000);

            if (elemExist(po_RDI_IB.WebElement_HomeAccounts)){
                ReportHelper.logReportStatus(LogStatus.PASS,"When 'Confirm' button is clicked, after successful Murahaba Deposit Emergency Withdraw, Home page was displayed as expected");
            }else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Navigation to Home page failed");
            }

            List <WebElement> AccountBalance=getLatestDriver().findElements(By.xpath("//*[contains(text(),'"+getData("AccountName")+"')]/following::div[@class='accountsRight']/div/p[2]"));
            CurrentBalance=AccountBalance.get(0).getText().replace(" ","").replace(",","");

            if (Double.parseDouble(CurrentBalance)==Double.parseDouble(getData("AccountBalance").replace(",",""))+Double.parseDouble(getData("EmergencyFund")))
            {
                ReportHelper.logReportStatus(LogStatus.PASS,"After Term Deposit Emergency withdraw, the Account balance of the Account credited is updated from '"+getData("AccountBalance")+"' to '"+CurrentBalance+"");
            }else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"After Term Deposit Emergency withdraw, the Account balance of the Account credited is not updated as expected, and displayed as '"+CurrentBalance+"");
            }
        }
        catch (Exception e){
            ReportHelper.logReportStatus(LogStatus.FAIL,"Confirmation of Murabaha account cancellation, failed due to '"+e.getMessage()+"'");
        }
    }
    /**********************************************************************************************************************************/
    /*
     * Function Name : EmergencyCashDetails
     * Description    : Fills details for emergency cash
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/
    public static void EmergencyCashDetails() {
        try{

            initPageObjects();
            getLatestDriver().switchTo().defaultContent();
            switchDFrame(1);

            po_RDI_IB.Input_EmergencyCash.clear();

            po_RDI_IB.Input_EmergencyCash.sendKeys(getData("EmergencyCash"));

            forceScreenShot=true;
            ReportHelper.logReportStatus(LogStatus.INFO,"Emergency Cash details entered successfully");

            po_RDI_IB.Button_EmegencyWithdrawalOk.click();

            waitFor(3000);

            if (elemExist(po_RDI_IB.Input_EmegencyCashPin)){
                ReportHelper.logReportStatus(LogStatus.PASS,"After entering Emergency Cash details and clicking ok, Emergency Cash PIN page was displayed as expected");
            }else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"After entering Emergency Cash details and clicking ok, Emergency Cash PIN page was not displayed as expected");
            }

        }
        catch (Exception e){
            ReportHelper.logReportStatus(LogStatus.FAIL,"Filling up Emergency Cash Details, failed due to '"+e.getMessage()+"'");
        }
    }
    /**********************************************************************************************************************************/
    /*
     * Function Name : EmergencyCashPINDetails
     * Description    : Fills details for emergency cash PIN
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/
    public static void EmergencyCashPINDetails(){
        try {
            initPageObjects();
            getLatestDriver().switchTo().defaultContent();
            switchDFrame(1);

            po_RDI_IB.Input_EmegencyCashPin.sendKeys(getData("CashPIN"));

            po_RDI_IB.Input_EmegencyCashRePin.sendKeys(getData("CashPIN"));

            forceScreenShot=true;
            ReportHelper.logReportStatus(LogStatus.INFO,"Emergency Cash details entered successfully");

            po_RDI_IB.Button_EmegencyWithdrawalOk.click();

            waitFor(3000);

            if(elemExist(po_RDI_IB.Element_EmegencyCashReference)){
                ReportHelper.logReportStatus(LogStatus.PASS,"After entering Emergency Cash PIN details and clicking ok, Emergency Cash Reference Number page was displayed as expected");
            }else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"After entering Emergency Cash PIN details and clicking ok, Emergency Cash Reference Number page was not displayed as expected");
            }

        }
        catch (Exception e){
            ReportHelper.logReportStatus(LogStatus.FAIL,"Filling up Emergency Cash PIN Details, failed due to '"+e.getMessage()+"'");
        }
    }
    /**********************************************************************************************************************************/
    /*
     * Function Name : EmergencyCashWithdrawalDetails
     * Description    : Retrieves Reference number details
     * Designed Date:
     * Updated Date :
     * @throws  Exception
     *********************************************************************************************************************************/
    public static void EmergencyCashWithdrawalDetails(){
        try{
            initPageObjects();
            getLatestDriver().switchTo().defaultContent();
            switchDFrame(1);
            String EmergencyCashRefNo="";

            if(elemExist(po_RDI_IB.Element_EmegencyCashReferenceNumber)){
                EmergencyCashRefNo=po_RDI_IB.Element_EmegencyCashReferenceNumber.getText();
                saveTestDataToDb("ReferenceNumber",EmergencyCashRefNo);
                ReportHelper.logReportStatus(LogStatus.PASS,"Emergency Cash Reference Number is generated and displayed as :"+EmergencyCashRefNo);
            }else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Emergency Cash Reference Number is not generated as expected");
            }

            po_RDI_IB.Button_EmegencyCashDone.click();

            waitFor(5000);

            if (elemExist(po_RDI_IB.WebElement_HomeAccounts)){
                ReportHelper.logReportStatus(LogStatus.PASS,"When 'Done' button is clicked, after successful Emergency Cash Reference Number generation, Home page was displayed as expected");
            }else {
                ReportHelper.logReportStatus(LogStatus.FAIL,"Navigation to Home page failed");
            }
        }
        catch (Exception e){
            ReportHelper.logReportStatus(LogStatus.FAIL,"Retrieving Emergency Cash Reference Number Details, failed due to '"+e.getMessage()+"'");
        }
    }

}
