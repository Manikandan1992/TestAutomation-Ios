package POM.functions;

import FrameWork.helpers.ReportHelper;
import FrameWork.library.Constant;
import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

import static FrameWork.helpers.Helper.getData;
import static FrameWork.library.Util.*;

public class InternationalfundTransfer {


    public static void selectBeneficary() {

        try {
            AppiumDriver<MobileElement> driver = getAppiumDriver();

            selectBenficaryAndEnterAmountAndPurpose();

            Thread.sleep(2000);
            MeemKSALogin_Ios.clickContinueBtn();
            click("//XCUIElementTypeButton[@label='Confirm']", "Confirm");

            Thread.sleep(15000);


            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblSuccessTitle']", Constant.transferMsg);


            String referenceNo = getText("//XCUIElementTypeStaticText[@name='lblAccDetailIBAN']");
            ReportHelper.logReportStatus(LogStatus.PASS, "The International fund transfer reference num is" + referenceNo);


        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to perform International Transfer" + e.getMessage());
        }
    }


    public static void internationalInsufficentBalance(){

        try {
            String beneficaryName = getData("BenficaryName");


            click("//XCUIElementTypeStaticText[@label='Select a beneficiary']", "Select beneficary");
            Thread.sleep(2000);

            click("//XCUIElementTypeTextField[@name='txtSmartSearchBeneficiary']", "");
            sendkeys("//XCUIElementTypeTextField[@name='txtSmartSearchBeneficiary']", beneficaryName);


            click("//XCUIElementTypeStaticText[@label='" + beneficaryName + "']", "Beneficary clicked");
            clear("//*[@name='txtAmount']", "Amount Value cleared");
            sendkeys("//*[@name='txtAmount']", getData("TransferAmount"));
            MeemKSALogin_Ios.clickDoneBtn();


            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblErrorAmount']", "Insufficient balance.");
            ReportHelper.logReportStatus(LogStatus.PASS, "The insufficient balance  validation for International Fund transfer has been verified");
        }catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to validate Insufficient balance for International Transfer" + e.getMessage());
        }

    }


    public static void selectBenficaryAndEnterAmountAndPurpose(){

        try {
            String beneficaryName = getData("BenficaryName");


            click("//XCUIElementTypeStaticText[@label='Select a beneficiary']", "Select beneficary");
            Thread.sleep(2000);

            click("//XCUIElementTypeTextField[@name='txtSmartSearchBeneficiary']", "");
            sendkeys("//XCUIElementTypeTextField[@name='txtSmartSearchBeneficiary']", beneficaryName);


            click("//XCUIElementTypeStaticText[@label='" + beneficaryName + "']", "Beneficary clicked");
            clear("//*[@name='txtAmount']", "Amount Value cleared");
            sendkeys("//*[@name='txtAmount']", getData("TransferAmount"));
            MeemKSALogin_Ios.clickDoneBtn();
            FuncSwipe();
            click("//XCUIElementTypeOther[@name='lstBxPurpose']", "Purpose");


            // MobileElement element1 = driver.findElement(By.xpath("//XCUIElementTypePickerWheel"));
            //element1.setValue("FAMILY");

            setValue("//XCUIElementTypePickerWheel", Constant.IntPurpose);
            MeemKSALogin_Ios.clickDoneBtn();
            Thread.sleep(2000);
            FuncSwipe();


            click("//XCUIElementTypeOther[@name='lstBxSubPurpose']", "Sub Purpose");
            ReportHelper.logReportStatus(LogStatus.PASS, "The sub purpose button clicked");

            setValue("//XCUIElementTypePickerWheel", Constant.IntSubPurpose);
            MeemKSALogin_Ios.clickDoneBtn();
        }catch(Exception e){

            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to perform International Transfer" + e.getMessage());
        }
    }
}
