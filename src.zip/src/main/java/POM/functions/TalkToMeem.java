package POM.functions;

import FrameWork.helpers.ReportHelper;
import FrameWork.library.Constant;
import POM.pageobjects.MeemKSA_login;
import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import static FrameWork.helpers.ReportHelper.logReportStatusInBlue;
import static FrameWork.library.Util.*;
import static FrameWork.listeners.po_BaseClass.driver;
import static POM.functions.MeemKSALogin_Ios.clickBurgerMenu;
import static POM.functions.MeemKSALogin_Ios.clickDoneBtn;
import static POM.functions.MeemKSALogin_Ios.clickLogout;
import static org.openqa.selenium.support.PageFactory.initElements;

public class TalkToMeem {

    public static void initPageObjects() {
        try {
            initElements(new AppiumFieldDecorator(driver), MeemKSA_login.class);
            logReportStatusInBlue(LogStatus.INFO, "Method: " + Thread.currentThread().getStackTrace()[2].getMethodName());
            getAppiumDriver();
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to load Page elemnets");

        }
    }

    public static void loginandSettingsclick() {
        try {
            getAppiumDriver();

            waitForPageToLoad("//XCUIElementTypeTextField[@name='txtUsername']");
            sendkeys("//XCUIElementTypeTextField[@name='txtUsername']", "1048795213");
            //waitForPageToLoad("//XCUIElementTypeButton[@label='Done'] ");
            clickDoneBtn();
            sendkeys("//XCUIElementTypeSecureTextField[@name='txtPassword']", "abcd1234");
            clickDoneBtn();
            click("//XCUIElementTypeButton[@name='btnLogin']", "Login");
            Thread.sleep(30000);
            clickBurgerMenu();
            click("//XCUIElementTypeButton[@label='H']", "Settings button");


        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to login or unable to settings button" + e.getMessage());
        }
    }

    public static void clickTalktoMeem() {

        click("//XCUIElementTypeStaticText[@label='K']", "Talk to Meem");
    }


    public static void newComplaint() {

        try {

            loginandSettingsclick();
            clickTalktoMeem();
            click("//XCUIElementTypeStaticText[@label='COMPLAINTS']", "Complaint ");
            click("//XCUIElementTypeStaticText[@label='R']", "click NewComplaint");
            click("//XCUIElementTypeStaticText[@label='New Complaint']", "New Complaint");
            Thread.sleep(3000);

            sendkeys("//*[@value='Subject']", "Card blocked");
            MeemKSALogin_Ios.clickDoneBtn();


            sendkeys("//XCUIElementTypeTextView[@name='txtArMsg']", "The card has been deactivated");
            MeemKSALogin_Ios.clickDoneBtn();

            click("//XCUIElementTypeButton[@label='Send']", "Send");
            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblSuccessTitle']", Constant.complaintSucessMSG);
            ReportHelper.logReportStatus(LogStatus.PASS, "The new complaint registered successfully");
            MeemKSALogin_Ios.clickHomeBtn();
            MeemKSALogin_Ios.clickBurgerMenu();
            clickLogout();


        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to raise a new complaint" + e.getMessage());


        }
    }

    public static void deleteComplaint(){
        try{
            loginandSettingsclick();
            clickTalktoMeem();
            click("//XCUIElementTypeStaticText[@label='COMPLAINTS']", "Complaint ");
           click(" //*[@label='RE: Card blocked']","Complaint Msg");
            click("//XCUIElementTypeStaticText[@label='Remove']","Remove");
            click("//XCUIElementTypeStaticText[@label='TRASH BOX']","TRASH BOX");
            elementIsDisplayed("//XCUIElementTypeStaticText[@label='RE: Card blocked']","Card blocked");
            ReportHelper.logReportStatus(LogStatus.PASS, "The complaint has been deleted and verified in Trash Box");
            click("//XCUIElementTypeStaticText[@label='B']", "Back Button");
            click("//XCUIElementTypeStaticText[@label='B']", "Back Button");
            clickBurgerMenu();
            clickLogout();


        }catch(Exception e){
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to delete a new complaint" + e.getMessage());
        }
    }

    public static void newEnquiry() {
        try {
            loginandSettingsclick();

            clickTalktoMeem();
            click("//XCUIElementTypeStaticText[@label='R']", "click New Mesage");
            click("//XCUIElementTypeStaticText[@label='New Message']", "New Message");
            Thread.sleep(3000);
            sendkeys("//*[@value='Subject']", "Card Missed");
            MeemKSALogin_Ios.clickDoneBtn();


            sendkeys("//XCUIElementTypeTextView[@name='txtArMsg']", "Card Missed");
            MeemKSALogin_Ios.clickDoneBtn();

            click("//XCUIElementTypeButton[@label='Send']", "Send");
            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblSuccessTitle']", Constant.enquirySucessMSG);
            ReportHelper.logReportStatus(LogStatus.PASS, "The new enquiry registered successfully");
            MeemKSALogin_Ios.clickHomeBtn();
            MeemKSALogin_Ios.clickBurgerMenu();
            clickLogout();

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to raise a new enquiry" + e.getMessage());

        }
    }

    public static void deleteMail() {
        try {
            loginandSettingsclick();

            clickTalktoMeem();

            click("//XCUIElementTypeStaticText[@label='Card Missed']", "click Mesage");
            click("//XCUIElementTypeStaticText[@label='Remove']","Remove");
            Thread.sleep(3000);
            click("//XCUIElementTypeStaticText[@label='TRASH BOX']","TRASH BOX");
            elementIsDisplayed("//XCUIElementTypeStaticText[@label='Card Missed']","Card Missed");
            ReportHelper.logReportStatus(LogStatus.PASS, "The Mail has been deleted and verified in Trash Box");

            //click("//XCUIElementTypeStaticText[@label='B']", "Back Button");
            //click("//XCUIElementTypeStaticText[@label='B']", "Back Button");
            //clickBurgerMenu();
            //clickLogout();



        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to delete a mail" + e.getMessage());

        }
    }
}
