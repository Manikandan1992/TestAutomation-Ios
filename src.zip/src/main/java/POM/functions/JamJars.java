package POM.functions;

import FrameWork.helpers.ReportHelper;
import FrameWork.library.Constant;
import POM.pageobjects.MeemKSA_login;
import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static FrameWork.helpers.Helper.getData;
import static FrameWork.helpers.ReportHelper.logReportStatusInBlue;
import static FrameWork.library.Util.*;
import static FrameWork.listeners.po_BaseClass.driver;
import static POM.functions.MeemKSALogin_Ios.clickDoneBtn;
import static POM.functions.TermDeposit.clickSuggestedProducts;
import static org.openqa.selenium.support.PageFactory.initElements;

public class JamJars {

    public static void initPageObjects() {
        try {
            initElements(new AppiumFieldDecorator(driver), MeemKSA_login.class);
            logReportStatusInBlue(LogStatus.INFO, "Method: " + Thread.currentThread().getStackTrace()[2].getMethodName());
            getAppiumDriver();
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to load Page elemnets");

        }
    }

    public static void  clickjamJar() {
        try {
            click("//*[@label='Jam Jars'] ", "Jams Jars");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click Jam Jars ");
        }
    }



    public static void  jamJarCreation(){

        try{
        MeemKSALogin_Ios.MeemKSA_iosLogin();
        MeemKSALogin_Ios.clickBurgerMenu();
        clickSuggestedProducts();
        clickjamJar();

        click("//XCUIElementTypeButton[@name='btnAdd']", "Add  Button");
        System.out.println(driver.getPageSource());
            clear("//XCUIElementTypeTextField[@value='Name']","");
        sendkeys("//XCUIElementTypeTextField[@value='Name']",getData("FirstName"));
        clear("//XCUIElementTypeTextField[@name='txtTSA']","");
        sendkeys("//XCUIElementTypeTextField[@name='txtTSA']",getData("TransferAmount"));
        clickDoneBtn();
        clear("//XCUIElementTypeTextField[@name='txtGoalAlert']","");
        sendkeys("//XCUIElementTypeTextField[@name='txtGoalAlert']","4");
        clickDoneBtn();
        FuncSwipe1();
        click("//XCUIElementTypeButton[@name='btnEmail']","Email");
        Thread.sleep(2000);

        click("//XCUIElementTypeTextField[@name='txtSelectedFromDate']", "");

            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd");
            LocalDateTime now = LocalDateTime.now();
            String datavalue = dtf.format(now);
            int tmrwdate = Integer.parseInt(datavalue) + 1;
            String tmrwdateValue = String.valueOf(tmrwdate);
            System.out.println(tmrwdate);

            click("//*[@label='" +tmrwdateValue+ "']", "Date Selected");
            click("//*[@label='Confirm Date']", "Confirm Date");

            //click("//XCUIElementTypeTextField[@name='txtSelectedToDate']", "To Date");
            waitForPageToLoad("//XCUIElementTypeTextField[@name='txtSelectedToDate']");
            click("//XCUIElementTypeTextField[@name='txtSelectedToDate']", "");
            System.out.println("Date");
            Thread.sleep(2000);
            click("//*[@label='Change the month']","");

            setValue("//XCUIElementTypePickerWheel", "February");
            clickDoneBtn();
            click("//*[@label='Change the year']","Year changed");
            setValue("//XCUIElementTypePickerWheel", "2020");
            clickDoneBtn();
            click("//*[@label='"+19+ "']", "Date Selected");

            click("//*[@label='Confirm Date']", "Confirm Date");
            ReportHelper.logReportStatus(LogStatus.PASS,"The From and To date has been selected in Jam Jar Screen");

            click("//XCUIElementTypeButton[@label='Monthly']","Frequency");
            click("//XCUIElementTypeButton[@label='Continue']","Continue");
            click("//XCUIElementTypeButton[@label='Confirm']","Confirm");
            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblSuccessTitle']",Constant.jamJarSuccessMsg);
            click("//XCUIElementTypeButton[@name='btnGotoHome']","Go to Jam Jars List");
            elementIsDisplayed("//*[contains(@label,'"+getData("FirstName")+"')]",getData("FirstName"));
            ReportHelper.logReportStatus(LogStatus.PASS,"Jam Jar Created and Verified successfully");
            } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to create  Jam Jars "+e.getMessage());
        }

    }
}

