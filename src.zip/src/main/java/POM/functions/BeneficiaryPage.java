package POM.functions;

import FrameWork.helpers.ReportHelper;
import FrameWork.library.Constant;
import POM.pageobjects.MeemKSA_login;
import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.commons.lang3.RandomStringUtils;

import static FrameWork.helpers.Helper.getData;
import static FrameWork.helpers.ReportHelper.logReportStatusInBlue;
import static FrameWork.library.Util.*;
import static FrameWork.listeners.po_BaseClass.driver;
import static POM.functions.MeemKSALogin_Ios.clickConfirmBtn;
import static POM.functions.MeemKSALogin_Ios.clickContinueBtn;
import static org.openqa.selenium.support.PageFactory.initElements;

public class BeneficiaryPage {

    public static void initPageObjects() {
        try {
            initElements(new AppiumFieldDecorator(driver), MeemKSA_login.class);
            logReportStatusInBlue(LogStatus.INFO, "Method: " + Thread.currentThread().getStackTrace()[2].getMethodName());
            getAppiumDriver();
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to load Page elemnets");

        }

    }

    public static void addBeneficiary() {

        try {
            MeemKSALogin_Ios.MeemKSA_iosLogin();
            MeemKSALogin_Ios.clickBurgerMenu();
            MeemKSALogin_Ios.clickBeneficiaryBtn();
            Thread.sleep(5000);
            clickAddBeneficaryBtn();
            clickInternational();
            enterIBANNumber();

            //System.out.println(driver.getPageSource());
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to add beneficary" + e.getMessage());
        }
    }

    public static void InternationalBenDeletion() {
        try {
            MeemKSALogin_Ios.MeemKSA_iosLogin();
            MeemKSALogin_Ios.clickBurgerMenu();
            MeemKSALogin_Ios.clickBeneficiaryBtn();
            //clickAddBeneficaryBtn();
            click("//XCUIElementTypeStaticText[contains(@label,'"+getData("BenficaryName")+"')]", "Beneficary clicked");
            //click("//XCUIElementTypeStaticText[@label='" + beneficaryName + "']", "Beneficary clicked");

            click("//XCUIElementTypeStaticText[@label='Delete']", "delete clicked");
            clickContinueBtn();
            clickConfirmBtn();
            elementIsDisplayed("//*[@name='lblClosureTitle']",Constant.beneDelMsg);

            ReportHelper.logReportStatus(LogStatus.PASS, "The International  beneficary has been deleted succesfully");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to delete International  beneficary" + e.getMessage());

        }
    }

    public static void invalidBeneficary() {

        try {
            MeemKSALogin_Ios.MeemKSA_iosLogin();
            MeemKSALogin_Ios.clickBurgerMenu();
            MeemKSALogin_Ios.clickBeneficiaryBtn();
            Thread.sleep(5000);
            clickAddBeneficaryBtn();
            clickWithinMeem();
            sendkeys("//XCUIElementTypeTextField[@name='txtIBAN']", getData("IBAN"));
            Thread.sleep(3000);
            MeemKSALogin_Ios.clickDoneBtn();
            click("//XCUIElementTypeButton[@label='Verify']", "Verify Button");
            elementIsDisplayed("//*[@name='lblVerificationMsg']",Constant.InValidLoginMsg);
            ReportHelper.logReportStatus(LogStatus.PASS, "The IBAN invalid mesasge has been verified");
            MeemKSALogin_Ios.clickHomeBtn();
            MeemKSALogin_Ios.clickBurgerMenu();
            MeemKSALogin_Ios.clickLogout();

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to validate Invalid beneficary Messgae" + e.getMessage());
        }
    }





    public static void addBeneficiary_Domestic() {

        try {
            MeemKSALogin_Ios.MeemKSA_iosLogin();
            MeemKSALogin_Ios.clickBurgerMenu();
            MeemKSALogin_Ios.clickBeneficiaryBtn();
            Thread.sleep(5000);
            clickAddBeneficaryBtn();
            clickWithKSA();
            WithKSABeneficary();

            //System.out.println(driver.getPageSource());
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to add beneficary" + e.getMessage());
        }
    }

    public static void addBeneficiary_WithinMeem() {

        try {
            MeemKSALogin_Ios.MeemKSA_iosLogin();
            MeemKSALogin_Ios.clickBurgerMenu();
            MeemKSALogin_Ios.clickBeneficiaryBtn();
            Thread.sleep(5000);
            clickAddBeneficaryBtn();
            clickWithinMeem();
            WithinMeemBenCreation();

            //System.out.println(driver.getPageSource());
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to add beneficary" + e.getMessage());
        }
    }

    public static void clickAddBeneficaryBtn() {

        click("//XCUIElementTypeButton[@name='btnAdd']", "Add Beneficary Button");


    }

    public static void clickWithinMeem() {
        click("//XCUIElementTypeStaticText[@label='Within meem']", "Within meem Beneficary clicked");
    }


    public static void clickWithKSA() {
        click("//XCUIElementTypeStaticText[@label='Local Banks']", "Within Bahrain Beneficary clicked");
    }

    public static void clickInternational() {
        click("//XCUIElementTypeStaticText[@label='International']", "International Beneficary clicked");
    }


    public static void enterIBANNumber() throws InterruptedException {
        try {

            String firstName = getData("FirstName");
            String lastName = getData("SecondName");
            String currency=getData("Currency");
            System.out.println("pass");
            Thread.sleep(3000);
            System.out.println(getData("IBAN"));
            sendkeys("//XCUIElementTypeTextField[@value='IBAN / Account number']", getData("IBAN"));
            Thread.sleep(3000);
            MeemKSALogin_Ios.clickDoneBtn();
            click("//XCUIElementTypeButton[@label='Verify']", "Verify Button");
            click("//XCUIElementTypeButton[@name='btnContinue']", "Continue Button");

            sendkeys("//XCUIElementTypeTextField[@name='txtFirstName']", firstName);
            sendkeys("//XCUIElementTypeTextField[@name='txtSecondName']", RandomStringUtils.randomAlphabetic(3));
            sendkeys("//XCUIElementTypeTextField[@name='txtLastName']", lastName);
            MeemKSALogin_Ios.clickDoneBtn();
            click("//XCUIElementTypeStaticText[@name='lblCurrencyValue']", "currency");
            click("//XCUIElementTypeStaticText[@label='"+currency+"']", "Foreign  Currency");
            System.out.println(driver.getPageSource());
            FuncSwipe();
            sendkeys("//XCUIElementTypeTextField[@name='txtSwiftCode']", getData("Swiftcode"));
            MeemKSALogin_Ios.clickDoneBtn();
            FuncSwipe1();
            sendkeys("//XCUIElementTypeTextField[@name='txtResAddress']", "Detroit");
            MeemKSALogin_Ios.clickDoneBtn();
            click("//XCUIElementTypeButton[@name='btnContinue']", "Continue Button");

            click("//*[@label='Add Beneficiary']", "Add Beneficary Button");
            Thread.sleep(20000);
            elementIsDisplayed("//XCUIElementTypeStaticText[@label='You have successfully created a new beneficiary']", Constant.beneSuccessMsg);
            ReportHelper.logReportStatus(LogStatus.PASS, Constant.beneSuccessMsg);

        } catch (Exception e) {

            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to Add a Beneficiary" + e.getMessage());
        }


    }

    public static void WithKSABeneficary() {
        try {
            String firstName = getData("FirstName");
            String secondName = getData("SecondName");
            Thread.sleep(3000);
            System.out.println(getData("IBAN"));
            sendkeys("//XCUIElementTypeTextField[@name='txtIBAN']", getData("IBAN"));
            Thread.sleep(3000);
            MeemKSALogin_Ios.clickDoneBtn();
            click("//XCUIElementTypeButton[@label='Verify']", "Verify Button");
            Thread.sleep(3000);
            sendkeys("//XCUIElementTypeTextField[@name='txtFirstName']", firstName);
            sendkeys("//XCUIElementTypeTextField[@name='txtSecondName']", secondName);
            //MeemKSALogin_Ios.clickDoneBtn();
            sendkeys("//XCUIElementTypeTextField[@name='txtLastName']", "D");
            MeemKSALogin_Ios.clickDoneBtn();
            clickContinueBtn();
            click("//XCUIElementTypeButton[@label='Add Beneficiary']", "Add Beneficary Button");
            Thread.sleep(20000);
            System.out.println(driver.getPageSource());
            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblClosureTitle']", Constant.beneSuccessMsg);
            ReportHelper.logReportStatus(LogStatus.PASS, Constant.beneSuccessMsg);

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to Add a Bahrain Beneficiary" + e.getMessage());
        }

    }


    public static void domestic_benDeletion() {
        try {
            String beneficaryName = getData("BenficaryName");
            MeemKSALogin_Ios.MeemKSA_iosLogin();
            MeemKSALogin_Ios.clickBurgerMenu();
            MeemKSALogin_Ios.clickBeneficiaryBtn();
            click("//XCUIElementTypeStaticText[@label='" + beneficaryName + "']", "Beneficary clicked");
            System.out.println(driver.getPageSource());
            click("//XCUIElementTypeStaticText[@label='Delete']", "delete clicked");
            clickContinueBtn();
            click("//*[@label='Confirm']","Confirm");
            elementIsDisplayed("//*[@value='The beneficiary has been deleted']",Constant.beneDelMsg);

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to delete domestic Beneficiary" + e.getMessage());
        }
    }




    public static void WithinMeemBenCreation() {

        try {

            System.out.println(getData("IBAN"));
            Thread.sleep(2000);
            sendkeys("//XCUIElementTypeTextField[@name='txtIBAN']", getData("IBAN"));
            MeemKSALogin_Ios.clickDoneBtn();
            click("//XCUIElementTypeButton[@label='Verify']", "Verify Button");

            clickContinueBtn();
            click("//XCUIElementTypeButton[@label='Add Beneficiary']", "Add Beneficary Button");
            Thread.sleep(30000);
            elementIsDisplayed("//XCUIElementTypeStaticText[@label='You have successfully created a new beneficiary']", Constant.beneSuccessMsg);
            ReportHelper.logReportStatus(LogStatus.PASS, Constant.beneSuccessMsg);

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to create Within Meem Beneficary" + e.getMessage());

        }
    }




        public static void WithinMeemBenDeletion() {

            try {

                String beneficaryName = getData("BenficaryName");
                MeemKSALogin_Ios.MeemKSA_iosLogin();
                MeemKSALogin_Ios.clickBurgerMenu();
                MeemKSALogin_Ios.clickBeneficiaryBtn();
                Thread.sleep(2000);
                System.out.println(beneficaryName);
                System.out.println(driver.getPageSource());

                click("//XCUIElementTypeStaticText[contains(@label,'"+beneficaryName+"')]", "Beneficary clicked");
                //click("//XCUIElementTypeStaticText[@label='" + beneficaryName + "']", "Beneficary clicked");

                click("//XCUIElementTypeStaticText[@label='Delete']", "delete clicked");
                clickContinueBtn();
                click("//XCUIElementTypeButton[@label='Confirm']", "Confirm");
                elementIsDisplayed("//XCUIElementTypeStaticText[@label='The beneficiary has been deleted']",Constant.beneDelMsg);
                ReportHelper.logReportStatus(LogStatus.PASS, Constant.beneDelMsg);

            } catch (Exception e) {
                ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to Within Meem  Beneficiary" + e.getMessage());
            }

    }

}

