package POM.functions;

import FrameWork.helpers.DriverHelper;
import POM.pageobjects.po_GTX;
import POM.pageobjects.po_UBS;
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import java.text.DecimalFormat;

import static FrameWork.helpers.Helper.getData;
import static FrameWork.helpers.ReportHelper.logReportStatus;
import static FrameWork.helpers.ReportHelper.logReportStatusInBlue;
import static FrameWork.library.Util.*;
import static FrameWork.listeners.po_BaseClass.drvr;
import static org.openqa.selenium.support.PageFactory.initElements;

public class fn_GTX_login {
   public static DecimalFormat dformat=new DecimalFormat("0.00");
    public static void initPageObjects() throws Exception {
        initElements(drvr, po_GTX.class);
        logReportStatusInBlue(LogStatus.INFO, "Method: " + Thread.currentThread().getStackTrace()[2].getMethodName());
        getLatestDriver();
    }

    public static void all_Login_GTX() throws Exception {

        String loginType = DriverHelper.environmentURL;
        //String loginUserType = loginType.split("~")[0] + "~" + loginType.split("~")[1];
        String application = loginType.split("~")[1];
        String urlType = loginType.split("~")[2];

        fn_allLogin.login_GTX(loginType, application + "~" + urlType);
    }

    public static void search() {
        try {
            waitFor(2000);
            initPageObjects();
            getLatestDriver();
            WebDriver driver = getLatestDriver();
            Actions builder = new Actions(driver);
            builder.moveToElement(po_GTX.GTX_landing_msg_menu).perform();
            waitFor(1000);
            click(po_GTX.GTX_landing_search);
             System.out.println("done!!");
            sendKeys(po_GTX.GTX_TRN_number, getData("UBS_ReferenceNumber"));
            click(po_GTX.GTX_search_btn);
            String key="Off";
            for (int i = 0; i < po_GTX.GTX_Types.size(); i++) {
                System.out.println(po_GTX.GTX_Types.get(i).getText() + po_GTX.GTX_status.get(i).getText());

                if (po_GTX.GTX_Types.get(i).getText().equals("103") && po_GTX.GTX_status.get(i).getText().equals("VERIFIED")) {//WAIT VERIF
                    logReportStatus(LogStatus.PASS, "TRN number Type and status is validated ");

                    po_GTX.GTX_refernce.get(i).click();
                    waitFor(2000);
                    po_GTX.ExpandTab.click();
                    key="On";
                }


            }
            if(key.equalsIgnoreCase("On"))
            {

            } else{
                logReportStatus(LogStatus.FAIL, "TRN Type and status is not populated as expected");
            }
        } catch (Exception e) {
            logReportStatus(LogStatus.FAIL, "TRN Type and status is not populated as expected");
        }
    }
    //international
public static void validation1()

    {
        System.out.println("GTX Refernce"+ po_GTX.GTX_referencenumber.getText());

        System.out.println("Debit currency: "+po_GTX.Currency.get(0).getText());
        System.out.println("Credit Currency: "+po_GTX.Currency.get(1).getText());
        System.out.println("Debit Amount: "+po_GTX.Amount.get(0).getText());
        System.out.println("Credit Amount: "+po_GTX.Amount.get(1).getText());
        System.out.println("Beneficary Account: "+po_GTX.Account.get(1).getText());

        System.out.println(" GTX_Remitance: "+po_GTX.GTX_Remitance.getText());

        System.out.println(" GTX Charges: "+po_GTX.GTX_Charges.getText());

        if(getData("UBS_ReferenceNumber").equalsIgnoreCase(po_GTX.GTX_referencenumber.getText())&& getData("CreditCurrency").equalsIgnoreCase(po_GTX.Currency.get(1).getText()) && getData("DebitCurrency").equalsIgnoreCase(po_GTX.Currency.get(0).getText())&& dformat.format(getData("PaymentAmount")).equalsIgnoreCase(dformat.format(po_GTX.Amount.get(0).getText()))&& getData("BeneficiaryAccount").equalsIgnoreCase(po_GTX.Account.get(1).getText()))
        {
            logReportStatus(LogStatus.PASS, "GTX Data are validated against the application Successfully");
        }else {
            logReportStatus(LogStatus.FAIL, "GTX Data are not matched against the application");
        }


}
//domestic
    public static void validation2()

    {
        System.out.println("GTX Refernce"+ po_GTX.GTX_referencenumber.getText());

        System.out.println("Debit currency: "+po_GTX.Currency.get(0).getText());
       // System.out.println("Credit Currency: "+po_GTX.Currency.get(1).getText());
        System.out.println("Debit Amount: "+po_GTX.Amount.get(0).getText());
       // System.out.println("Credit Amount: "+po_GTX.Amount.get(1).getText());
        System.out.println("Beneficary Account: "+po_GTX.Account.get(1).getText());

        System.out.println(" GTX_Remitance: "+po_GTX.GTX_Remitance.getText());

        System.out.println(" GTX Charges: "+po_GTX.GTX_Charges.getText());
if(getData("UBS_ReferenceNumber").equalsIgnoreCase(po_GTX.GTX_referencenumber.getText()) && getData("PaymentCurrency").equalsIgnoreCase(po_GTX.Currency.get(0).getText())&& dformat.format(getData("PaymentAmount")).equalsIgnoreCase(dformat.format(po_GTX.Amount.get(0).getText()))&& getData("BeneficiaryAccount").equalsIgnoreCase(po_GTX.Account.get(1).getText()))
{
    logReportStatus(LogStatus.PASS, "GTX Data are validated against the application Successfully");
}else {
    logReportStatus(LogStatus.FAIL, "GTX Data are not matched against the application");
}


    }

    public static void GTX_logout() {

        click(po_GTX.GTX_logout);
        logReportStatus(LogStatus.PASS, "Log out Successfully");

    }


    //builder.moveToElement(po_GTX.GTX_landing_search).click().perform();


}
