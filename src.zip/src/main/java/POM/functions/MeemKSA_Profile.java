package POM.functions;

import FrameWork.helpers.ReportHelper;
import FrameWork.library.Constant;
import POM.pageobjects.MeemKSA_login;
import com.relevantcodes.extentreports.LogStatus;
import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import javax.xml.bind.SchemaOutputResolver;

import static FrameWork.helpers.Helper.getData;
import static FrameWork.helpers.ReportHelper.logReportStatusInBlue;
import static FrameWork.library.Util.*;
import static FrameWork.listeners.po_BaseClass.driver;
import static POM.functions.MeemKSALogin_Ios.clickBurgerMenu;
import static POM.functions.MeemKSALogin_Ios.clickContinueBtn;
import static POM.functions.MeemKSALogin_Ios.clickDoneBtn;
import static POM.functions.TalkToMeem.loginandSettingsclick;
import static org.openqa.selenium.support.PageFactory.initElements;

public class MeemKSA_Profile {

    public static void initPageObjects() {
        try {
            initElements(new AppiumFieldDecorator(driver), MeemKSA_login.class);
            logReportStatusInBlue(LogStatus.INFO, "Method: " + Thread.currentThread().getStackTrace()[2].getMethodName());
            getAppiumDriver();
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to load Page elemnets");

        }
    }


    public static void profileUpdate() {
        try {

            String profileUpdateMsg = "Your personal details have been successfully updated";
            AppiumDriver<MobileElement> appiumDriver = getAppiumDriver();

            MeemKSALogin_Ios.MeemKSA_iosLogin();
            MeemKSALogin_Ios.clickBurgerMenu();

            click("//XCUIElementTypeButton[@label='H']", "Settings button");

            click("//XCUIElementTypeStaticText[@label='Profile Management']", "Profile Managment");
            Thread.sleep(5000);
            //System.out.println(driver.getPageSource());
            click("//XCUIElementTypeStaticText[@name='segList_1_1_lblToolsMenuItem']", "Profile");
            // click("//XCUIElementTypeStaticText[@name='segList_1_1_lblToolsMenuItem']", "Profile");
            System.out.println(driver.getPageSource());
            click("//XCUIElementTypeStaticText[@value='More Information']", "More information");
            FuncSwipe();
            FuncSwipe();
            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblOther']", "Other");
            System.out.println(driver.getPageSource());
            Boolean other = appiumDriver.findElementByXPath("//XCUIElementTypeButton[@name='btnOtherYes']").isEnabled();
            System.out.println(other);
            if (other == false) {

                waitForPageToLoad("//XCUIElementTypeButton[@name='btnOtherYes']");
                MobileElement yes = appiumDriver.findElementByXPath("//XCUIElementTypeButton[@name='btnOtherYes']");
                yes.click();
                sendkeys("//*[value='Please specify other source of income']", "business");
                MeemKSALogin_Ios.clickDoneBtn();
                ReportHelper.logReportStatus(LogStatus.PASS, "Other Information has been been changed successfully");
            }
            if (other == true) {
                waitForPageToLoad("//XCUIElementTypeButton[@name='btnOtherNo']");
                MobileElement yes = appiumDriver.findElementByXPath("//XCUIElementTypeButton[@name='btnOtherNo']");
                yes.click();
                ReportHelper.logReportStatus(LogStatus.PASS, "Other Information has been been changed successfully");

            }
            click("//XCUIElementTypeButton[@name='btnContinue']", "Save");
            click("//XCUIElementTypeButton[@label='Confirm Changes']", "Confirm Changes");
            Thread.sleep(20000);


            System.out.println(driver.getPageSource());
            elementIsDisplayed("//*[@name='lblSuccessTitle']", profileUpdateMsg);
            ReportHelper.logReportStatus(LogStatus.PASS, "Profile has been updated successfully");

        } catch (Exception e) {

            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to update profile" + e.getMessage());
        }


    }


    public static void updatePassword() {

        try {
            loginandSettingsclick();
            click("//XCUIElementTypeStaticText[@label='Profile Management']", "Profile Managment");
            click("//XCUIElementTypeStaticText[@name='segList_1_3_lblToolsMenuItem']", "Security Settings");
            click("//XCUIElementTypeStaticText[@label='Change Password']", "Change Password");
            sendkeys("//*[@value='Old Password']", "abcd1234");
            MeemKSALogin_Ios.clickDoneBtn();
            System.out.println(getData("PasswordUpdate"));
            sendkeys("//*[@value='New password']", getData("PasswordUpdate"));
            MeemKSALogin_Ios.clickDoneBtn();
            sendkeys("//*[@value='Repeat new password']", getData("PasswordUpdate"));
            MeemKSALogin_Ios.clickDoneBtn();
            clickContinueBtn();
            Thread.sleep(15000);
            elementIsDisplayed("//*[@name='lblSuccessTitle']", Constant.updatedPwdMSG);
            ReportHelper.logReportStatus(LogStatus.PASS, "The new password has been updated sucessfully");
            //MeemKSALogin_Ios.clickHomeBtn();
            //MeemKSALogin_Ios.clickBurgerMenu();
            //MeemKSALogin_Ios.clickLogout();


        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to update password" + e.getMessage());
        }


    }

    public static void updatePasswordAsOld() {

        try {

            waitForPageToLoad("//XCUIElementTypeTextField[@name='txtUsername']");
            sendkeys("//XCUIElementTypeTextField[@name='txtUsername']", "1048795213");
            //waitForPageToLoad("//XCUIElementTypeButton[@label='Done'] ");
            clickDoneBtn();
            sendkeys("//XCUIElementTypeSecureTextField[@name='txtPassword']", "abcd1234");
            clickDoneBtn();
            click("//XCUIElementTypeButton[@name='btnLogin']", "Login");
            Thread.sleep(30000);
            clickBurgerMenu();
            click("//XCUIElementTypeButton[@label='H']", "Settings button");

            click("//XCUIElementTypeStaticText[@label='Profile Management']", "Profile Managment");
            click("//XCUIElementTypeStaticText[@name='segList_1_3_lblToolsMenuItem']", "Security Settings");
            click("//XCUIElementTypeStaticText[@label='Change Password']", "Change Password");
            sendkeys("//*[@value='Old Password']", "abcd1234");
            MeemKSALogin_Ios.clickDoneBtn();
            System.out.println(getData("PasswordUpdate"));
            sendkeys("//*[@value='New password']", "abcd1234");
            MeemKSALogin_Ios.clickDoneBtn();
            sendkeys("//*[@value='Repeat new password']", "abcd1234");
            MeemKSALogin_Ios.clickDoneBtn();

            elementIsDisplayed("//*[@name='lblPasswordErr']", Constant.pwdErrMSG);
            ReportHelper.logReportStatus(LogStatus.PASS, "The update  password as old Message  been verified");


        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to update password as old" + e.getMessage());
        }


    }

    public static void limitUpdate() {

        try {
            MeemKSALogin_Ios.MeemKSA_iosLogin();
            clickBurgerMenu();
            click("//XCUIElementTypeButton[@label='H']", "Settings button");

            click("//XCUIElementTypeStaticText[@label='Profile Management']", "Profile Managment");
            click("//XCUIElementTypeStaticText[@label='Security Settings']", "Security Settings");
            click("//XCUIElementTypeStaticText[@label='Update Transactions Limit']", "Update Transactions Limit");
            Thread.sleep(5000);
            FuncSwipe();
            Thread.sleep(5000);
            FuncSwipe();
            clear("//XCUIElementTypeTable//XCUIElementTypeCell[4]//XCUIElementTypeTextField[@name='txtDailyLimitMax']", "");
            clickDoneBtn();
            sendkeys("//XCUIElementTypeTable//XCUIElementTypeCell[4]//XCUIElementTypeTextField[@name='txtDailyLimitMax']", getData("TransferAmount"));
            clickContinueBtn();
            Thread.sleep(30000);
            System.out.println(driver.getPageSource());


        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to update the Limit" + e.getMessage());
        }
    }


    public static void pwdChangeWithUserName() {
        try {
            MeemKSALogin_Ios.MeemKSA_iosLogin();
            clickBurgerMenu();
            click("//XCUIElementTypeButton[@label='H']", "Settings button");
            click("//XCUIElementTypeStaticText[@label='Profile Management']", "Profile Managment");
            click("//XCUIElementTypeStaticText[@label='Security Settings']", "Security Settings");
            click("//XCUIElementTypeStaticText[@label='Change Password']","Change Password");
            waitForPageToLoad("//XCUIElementTypeSecureTextField[@value='Old Password']");

            sendkeys("//XCUIElementTypeSecureTextField[@value='Old Password']",getData("Password"));
            sendkeys("//XCUIElementTypeSecureTextField[@value='New password']",getData("UserName")+"A@");
            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblNewPwdErr']",Constant.pwdErrMSG);

            String input=getData("UserName");
            char[] reverseString=input.toCharArray();
            for(int i=reverseString.length-1;i>=0;i--){
                System.out.print(reverseString[i]);
            }

            Thread.sleep(2000);
            clickDoneBtn();

            Thread.sleep(5000);
            click("//XCUIElementTypeSecureTextField[@value='New password']","");
            //clear("//XCUIElementTypeSecureTextField[@value='New password']","");
            pressDeleteKey();
            sendkeys("//XCUIElementTypeSecureTextField[@value='New password']",reverseString+"A@");
            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblNewPwdErr']",Constant.pwdErrMSG);

            ReportHelper.logReportStatus(LogStatus.PASS, "The password contains Username Error Msg has been verified for both forward and reverse");







        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to validate the  password contains Username Msg" + e.getMessage());
        }
    }
}
