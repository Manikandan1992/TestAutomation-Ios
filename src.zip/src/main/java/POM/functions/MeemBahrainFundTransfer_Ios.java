package POM.functions;

import FrameWork.helpers.ReportHelper;
import POM.pageobjects.MeemKSA_login;
import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import static FrameWork.helpers.Helper.getData;
import static FrameWork.helpers.ReportHelper.logReportStatusInBlue;
import static FrameWork.library.Util.click;
import static FrameWork.library.Util.getAppiumDriver;
import static FrameWork.listeners.po_BaseClass.driver;
import static org.openqa.selenium.support.PageFactory.initElements;

public class MeemBahrainFundTransfer_Ios {


    public static void initPageObjects() {
        try {
            initElements(new AppiumFieldDecorator(driver), MeemKSA_login.class);
            logReportStatusInBlue(LogStatus.INFO, "Method: " + Thread.currentThread().getStackTrace()[2].getMethodName());
            getAppiumDriver();
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to load Page elemnets");

        }

    }

    public static void International_fundTransfer() {

        MeemKSALogin_Ios.MeemKSA_iosLogin();
        MeemKSALogin_Ios.clickBurgerMenu();
        MeemKSALogin_Ios.clickTransferBtn();
        clickInternational();
        InternationalfundTransfer.selectBeneficary();

    }

    public static void International_fundTransfer_FCY() {

        MeemKSALogin_Ios.MeemKSA_iosLogin();
        MeemKSALogin_Ios.clickBurgerMenu();
        MeemKSALogin_Ios.clickTransferBtn();
        clickInternational();
        String fromAccountValue = getData("FromAccount");
        System.out.println(fromAccountValue);

        click("//XCUIElementTypeStaticText[@name='lblAccNo']", "fromAccount");
       // click("//XCUIElementTypeStaticText[@value='From account']", "fromAccount");
        System.out.println("From Account clicked");

        //System.out.println(driver.getPageSource());
        click("//XCUIElementTypeStaticText[@value='"+fromAccountValue+"']", "fromAccountValue");
        //click("//XCUIElementTypeStaticText[@value='BH84 **** 0717']", "fromAccountValue");

        InternationalfundTransfer.selectBeneficary();

       // BH84  **** 0717
        //BH84 **** 0717

    }


    public static void InternationalInsufficientBalance() {

        MeemKSALogin_Ios.MeemKSA_iosLogin();
        MeemKSALogin_Ios.clickBurgerMenu();
        MeemKSALogin_Ios.clickTransferBtn();
        clickInternational();
        InternationalfundTransfer.internationalInsufficentBalance();

    }
    public static void  WithinOwnAccountsTransfer()
    {
        MeemKSALogin_Ios.MeemKSA_iosLogin();
        MeemKSALogin_Ios.clickBurgerMenu();
        MeemKSALogin_Ios.clickTransferBtn();
        clickOwnAccounts();
        FundTransfer.WithOWNAccounts();
    }

    public static void  WithinOwnAccountsTransferFCYTOOnepAck()
    {
        MeemKSALogin_Ios.MeemKSA_iosLogin();
        MeemKSALogin_Ios.clickBurgerMenu();
        MeemKSALogin_Ios.clickTransferBtn();
        clickOwnAccounts();
        FundTransfer.WithOWNAccounts();
    }

    public static void  WithinOwnAccountsTransferFCYFCY(){
        WithinOwnAccountsTransfer();
    }

    public static void  WithinOwnAccountsInsufficientBalance()
    {
        MeemKSALogin_Ios.MeemKSA_iosLogin();
        MeemKSALogin_Ios.clickBurgerMenu();
        MeemKSALogin_Ios.clickTransferBtn();
        clickOwnAccounts();
        FundTransfer.ownTransfer_InSufficientbalance();
    }

    public static void WithinMeemTransfer()
    {
        MeemKSALogin_Ios.MeemKSA_iosLogin();
        MeemKSALogin_Ios.clickBurgerMenu();
        MeemKSALogin_Ios.clickTransferBtn();
        clickWithinMeem();
        FundTransfer.WithinMeemTransfer();
    }

    public static void WithinMeemTransferFCY_BHD()
    {
        //MeemKSALogin_Ios.MeemBahrain_iosLogin();
        MeemKSALogin_Ios.clickBurgerMenu();
        MeemKSALogin_Ios.clickTransferBtn();
        clickWithinMeem();
        FundTransfer.WithinMeemTransfer();
    }



    public static void WithinBahrainFawariInvalidBal()
    {
        //MeemKSALogin_Ios.MeemBahrain_iosLogin();
        MeemKSALogin_Ios.clickBurgerMenu();
        MeemKSALogin_Ios.clickTransferBtn();
        clickWithinKSA();
        FundTransfer.fawariTransferInsufficientBal();
    }



    public static void WithinKSA()
    {
        MeemKSALogin_Ios.MeemKSA_iosLogin();
        MeemKSALogin_Ios.clickBurgerMenu();
        MeemKSALogin_Ios.clickTransferBtn();
        clickWithinKSA();
        FundTransfer.WithinKSATransfer();
    }


    public static void clickOwnAccounts() {
        try {
            click("//XCUIElementTypeStaticText[@value='Own Accounts']", "OWn Accounts");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click Own Accounts button");
        }
    }

    public static void clickInternational() {
        try {
            click("//XCUIElementTypeStaticText[@value='International']", "International");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click International button");
        }
    }

    public static void clickWithinMeem() {
        try {
            click("//XCUIElementTypeStaticText[@value='Within meem']", "Within Meem");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click International button");
        }
    }



    public static void clickWithinKSA() {
        try {
            click("//XCUIElementTypeStaticText[@value='Within KSA']", "Within KSA");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click Within Bahrain button");
        }
    }

    public static void clickPerformFavoriteTransfer() {
        try {
            click("//XCUIElementTypeStaticText[@value='Perform Favorite Transfer']", "Perform Favorite Transfer");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click Perform Favorite Transfer button");
        }


    }

    public static void clickAddBeneficiaryName() {
        try {
            click("//XCUIElementTypeStaticText[@label='Add a Beneficiary']", "Add a Beneficiary");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click Add a Beneficiary button");
        }


    }

    public static void clickSetStandingInstruction() {
        try {
            click("//XCUIElementTypeStaticText[@label='Set Standing Instructions']", "Set Standing Instructions");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click Set Standing Instructions button");
        }


    }
}



