package POM.functions;

import FrameWork.helpers.ReportHelper;
import FrameWork.library.Constant;
import POM.pageobjects.MeemKSA_login;
import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import static FrameWork.helpers.Helper.getData;
import static FrameWork.helpers.ReportHelper.logReportStatusInBlue;
import static FrameWork.library.Util.*;
import static FrameWork.listeners.po_BaseClass.driver;
import static POM.functions.MeemKSALogin_Ios.*;
import static org.openqa.selenium.support.PageFactory.initElements;

public class TermDeposit {

    public static void initPageObjects() {
        try {
            initElements(new AppiumFieldDecorator(driver), TermDeposit.class);
            logReportStatusInBlue(LogStatus.INFO, "Method: " + Thread.currentThread().getStackTrace()[2].getMethodName());
            getAppiumDriver();
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to load Page elemnets");

        }
    }


    public static void termDepositERFund(){
        try{
            MeemKSALogin_Ios.MeemKSA_iosLogin();
            clickBurgerMenu();
            clickProducts();
            clickDeposits();
            clickMurabhaDeposits();
            click("//XCUIElementTypeStaticText[@name='lblERFund']","ER Fund");
            waitForPageToLoad("//XCUIElementTypeStaticText[@label='Emergency fund from Murabaha']");
            click("//XCUIElementTypeTextField[@name='txtERAmount']","");
            clear("//XCUIElementTypeTextField[@name='txtERAmount']","");
            sendkeys("//XCUIElementTypeTextField[@name='txtERAmount']",getData("TransferAmount"));
            clickDoneBtn();
            MeemKSALogin_Ios.clickContinueBtn();
            click("//*[@label='Confirm']","Confirm");

            Thread.sleep(10000);
            //System.out.println(driver.getPageSource());
            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblSuccessTitle']",Constant.EMERGENCYFUNDFromTDSuccessMSG);

            //System.out.println(driver.getPageSource());
            ReportHelper.logReportStatus(LogStatus.PASS," Term Deposit with ER Fund has been created");



        }catch(Exception e){
            ReportHelper.logReportStatus(LogStatus.FAIL,"Unable to create Term Deposit with ER Fund"+e.getMessage());
        }
    }



    public static void clickDeposits() {

        try {
            waitForPageToLoad("//XCUIElementTypeStaticText[@label='Deposits']");

            click("//XCUIElementTypeStaticText[@label='Deposits']","Deposits");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click Deposits");
        }
    }

    public static void clickMurabhaDeposits() {

        try {

            click("//XCUIElementTypeStaticText[@label='Murabaha deposit']","Murabaha deposit");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click Murabha Deposits");
        }
    }

    public static void termDepositinSARCreation(){

        try{

            String currency=getData("Currency");
            String Days=getData("Days")+"lblDays";
            MeemKSALogin_Ios.MeemKSA_iosLogin();
            clickBurgerMenu();
            clickSuggestedProducts();
            clickMurabahaDeposit();
            applyBtn();
            click("//XCUIElementTypeOther[@name='listCurrency']", "Choose Currency");
            Thread.sleep(2000);
            setValue("//XCUIElementTypePickerWheel",currency);
            Thread.sleep(2000);
            System.out.println(Days);
            Thread.sleep(2000);
            click("//XCUIElementTypeButton[@label='OK']","Ok");
            waitForPageToLoad("//*[@name='"+Days+"']");
            click("//*[@name='"+Days+"']","Number of selected");


            click("//XCUIElementTypeTable//XCUIElementTypeCell[1]//XCUIElementTypeStaticText[contains(@label,'SAR 1,000 to 100,000')]","Best Rate");
            FuncSwipe1();

            click("//XCUIElementTypeStaticText[@name='lblChevToAccount']", "fromAccount");
           // click("//XCUIElementTypeStaticText[@name='lblChevToAccount']", "fromAccount");
            System.out.println("PASS");

            String fromAccountValue = getData("FromAccount");
            //System.out.println(driver.getPageSource());

            click("//XCUIElementTypeStaticText[@label='" + fromAccountValue + "']", "fromAccountValue");
            //click("//XCUIElementTypeStaticText[@label='" + fromAccountValue + "']", "fromAccountValue");
            clear("//XCUIElementTypeTextField[@name='txtAmnt']", "Amount value");
            sendkeys("//*[@name='txtAmnt']", getData("TransferAmount"));
            clickDoneBtn();
            clickContinueBtn();
            click("//XCUIElementTypeStaticText[contains(@label,'Reinvest principal (purchase Price) and transfer profit')]","Reinvest principal and Transfer Profit");
            clickTandC();
            clickAccept();


            click("//XCUIElementTypeButton[@label='Book Murabaha deposit']","Book button");
            clickContinueBtn();
            clickConfirm();
            Thread.sleep(2000);
            clickConfirm();
            //System.out.println(driver.getPageSource());
            clickConfirm();
            Thread.sleep(40000);
            waitForPageToLoad("//*[@name='lblSuccessTitle']");
            elementIsDisplayed("//*[@name='lblSuccessTitle']", Constant.termDepositSuccessMSg);
            System.out.println(driver.getPageSource());
            click("//*[@name='btnContinue'] ", "Go to Home");
            clickBurgerMenu();
            click("//XCUIElementTypeStaticText[@label='Products']","Products");
            click("//XCUIElementTypeStaticText[@label='Deposits']","Deposits");
            System.out.println(driver.getPageSource());
           String daysAndCurrency=iosGetText("//*[@label='SAR / 180 / 1%']");
           String CurrencyAndDays=currency+" / "+getData("Days");
            if(daysAndCurrency.contains(CurrencyAndDays)){
                ReportHelper.logReportStatus(LogStatus.PASS,"The Days and Currency is Validated");

            }
            String CurrencyDaysAndPercent=currency+" / "+getData("Days")+" / 1%";
            System.out.println(CurrencyAndDays);
            click("//*[@label='"+CurrencyDaysAndPercent+"']","");
            click("//XCUIElementTypeStaticText[@name='lblViewDeposit']","View Details");
            System.out.println(driver.getPageSource());




            }catch(Exception e){
            ReportHelper.logReportStatus(LogStatus.FAIL,"Unable to create Term Deposit with SAR Currency");
        }
    }

    public static void clickConfirm() {
        try {
            click("//XCUIElementTypeButton[@label='Confirm']", "Confirm");
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click Confirm button");

        }
    }

    public static void clickTandC() {
        try {
            click("//XCUIElementTypeButton[@label='Terms & Conditions']", "Terms & Conditions");
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click Terms and Conditions button");

        }
    }

    public static void clickAccept() {
        try {
            click("//XCUIElementTypeButton[@label='Accept']", "Accept");
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click Accept button");

        }
    }


    public static void clickSuggestedProducts(){

        try{
            click("//XCUIElementTypeStaticText[@label='Suggested Products']","Suggested Products);");

        }catch(Exception e){
            ReportHelper.logReportStatus(LogStatus.FAIL,"Unable to click Suggested products in Burger Mewnu");
        }
    }


    public static void clickMurabahaDeposit(){

        try{
            waitForPageToLoad("//XCUIElementTypeStaticText[@label='Murabaha Deposit']");
            click("//XCUIElementTypeStaticText[@label='Murabaha Deposit']","Murabaha Deposit");

        }catch(Exception e){
            ReportHelper.logReportStatus(LogStatus.FAIL,"Unable to click Murabaha Deposit in Suggested products");
        }
    }




    public static void applyBtn(){

        try{
            click("//XCUIElementTypeButton[@label='Apply']","Apply");

        }catch(Exception e){
            ReportHelper.logReportStatus(LogStatus.FAIL,"Unable to click Apply button");
        }
    }

}
