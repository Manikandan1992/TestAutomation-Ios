package POM.functions;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

public class Test {
    public static void main(String[] args) {


        Map<String, String> currentWeekMap = new HashMap<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd");

        LocalDate today = LocalDate.now();

        LocalDate newDay = today.plusDays(1);
        String dayOfWeek = newDay.getDayOfWeek().toString();
        String formattedDate = newDay.format(formatter);
        currentWeekMap.put(dayOfWeek, formattedDate);


        String date = currentWeekMap.values().toString().replaceAll("[\\[\\],]", "");
        System.out.println(date);
    }
}
