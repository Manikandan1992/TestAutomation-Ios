package POM.functions;

import FrameWork.helpers.ReportHelper;
import FrameWork.library.Constant;
import POM.pageobjects.MeemKSA_login;
import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.By;

import static FrameWork.helpers.Helper.getData;
import static FrameWork.helpers.ReportHelper.logReportStatusInBlue;
import static FrameWork.library.Constant.transferMsg;
import static FrameWork.library.Util.*;
import static FrameWork.listeners.po_BaseClass.driver;
import static POM.functions.MeemBahrainFundTransfer_Ios.clickPerformFavoriteTransfer;
import static POM.functions.MeemBahrainFundTransfer_Ios.clickWithinKSA;
import static POM.functions.MeemKSALogin_Ios.*;
import static org.openqa.selenium.support.PageFactory.initElements;

public class FundTransfer {
    public static void initPageObjects() {
        try {
            initElements(new AppiumFieldDecorator(driver), MeemKSA_login.class);
            logReportStatusInBlue(LogStatus.INFO, "Method: " + Thread.currentThread().getStackTrace()[2].getMethodName());
            getAppiumDriver();
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to load Page elemnets");

        }
    }


    public static void WithOWNAccounts() {

        try {
            String transferMsg = "Your transfer was done successfully.";
            String fromAccountValue = getData("FromAccount");
            System.out.println(fromAccountValue);
            String toAccount = getData("ToAccount");
            // click("//XCUIElementTypeStaticText[@name='lblSelect']", "fromAccount");
            click("//XCUIElementTypeStaticText[@name='lblAccNo']", "fromAccount");
            System.out.println("PASS");

            click("//XCUIElementTypeStaticText[@label='" + fromAccountValue + "']", "fromAccountValue");
            //click("//XCUIElementTypeStaticText[@label='" + fromAccountValue + "']", "fromAccountValue");
            click("//XCUIElementTypeStaticText[@label='Select a account']", "Select Account");
            click("//XCUIElementTypeStaticText[@label='" + toAccount + "']", toAccount);
            clear("//XCUIElementTypeTextField[@name='txtAmount']", "Amount value");
            sendkeys("//*[@name='txtAmount']", getData("TransferAmount"));
            clickDoneBtn();
            MeemKSALogin_Ios.clickContinueBtn();
            click("//XCUIElementTypeButton[@label='Confirm']", "Confirm");

            elementIsDisplayed("//XCUIElementTypeStaticText[contains(@label,'" + transferMsg + "')]", transferMsg);

            String referenceNo = getText("//XCUIElementTypeStaticText[@name='lblAccDetailIBAN']");
            ReportHelper.logReportStatus(LogStatus.PASS, "The fund transfer reference num is" + referenceNo);


        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to perform OWN Account Transfer" + e.getMessage());
        }
    }

    public static void ownTransfer_InSufficientbalance() {
        try {
            String fromAccountValue = getData("FromAccount");
            System.out.println(fromAccountValue);
            String toAccount = getData("ToAccount");
            click("//XCUIElementTypeStaticText[@name='lblSelect']", "fromAccount");
            System.out.println("PASS");

            click("//XCUIElementTypeStaticText[@label='" + fromAccountValue + "']", "fromAccountValue");
            click("//XCUIElementTypeStaticText[@label='" + fromAccountValue + "']", "fromAccountValue");
            click("//XCUIElementTypeStaticText[@label='Select a account']", "Select Account");
            click("//XCUIElementTypeStaticText[@label='" + toAccount + "']", toAccount);
            clear("//XCUIElementTypeTextField[@name='txtAmount']", "Amount value");
            sendkeys("//*[@name='txtAmount']", getData("TransferAmount"));
            clickDoneBtn();
            MeemKSALogin_Ios.clickContinueBtn();
            elementIsDisplayed("//*[@name='lblErrorAmount']", "Insufficient balance.");
            ReportHelper.logReportStatus(LogStatus.PASS, "The OWN Account Transfer Insufficient Balance Message has been verified");
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to verify  OWN Account Transfer InsufficientBalance Message" + e.getMessage());
        }
    }


    public static void WithinMeemTransfer() {
        try {
            AppiumDriver<MobileElement> appiumDriver = getAppiumDriver();
            String beneficaryName = getData("BenficaryName");
            String transferMsg = "Your transfer was done successfully";
            String fromAccountValue = getData("FromAccount");
            System.out.println(fromAccountValue);
            String toAccount = getData("ToAccount");
            //click("//XCUIElementTypeStaticText[@name='lblSelect']", "fromAccount");
            click("//XCUIElementTypeStaticText[@name='lblAccNo']", "fromAccount");
            System.out.println("PASS");

            click("//XCUIElementTypeStaticText[@label='" + fromAccountValue+ "']", "fromAccountValue");
            //click("//XCUIElementTypeStaticText[@label='" + fromAccountValue + "']", "fromAccountValue");

            click("//XCUIElementTypeStaticText[@label='Select a beneficiary']", "Select beneficary");
            Thread.sleep(2000);

            click("//XCUIElementTypeTextField[@name='txtSmartSearchBeneficiary']", "Select beneficary");
            sendkeys("//XCUIElementTypeTextField[@name='txtSmartSearchBeneficiary']", beneficaryName);


            //
            clickDoneBtn();
            click("//XCUIElementTypeStaticText[contains(@value,'" + beneficaryName + "')]", "Beneficary clicked");
            clear("//*[@name='txtAmount']", "Amount Value cleared");
            sendkeys("//*[@name='txtAmount']", getData("TransferAmount"));
            clickDoneBtn();
            FuncSwipe();
            click("//*[@value='Select a purpose']", "Purpose");
            setValue("//XCUIElementTypePickerWheel", "Family");
            clickDoneBtn();
            FuncSwipe();
            click("//XCUIElementTypeOther[@value='Select a subpurpose']", "Purpose");
            setValue("//XCUIElementTypePickerWheel", "Family support");


            clickDoneBtn();


            MeemKSALogin_Ios.clickContinueBtn();
            click("//XCUIElementTypeButton[@label='Confirm']", "Confirm");

            elementIsDisplayed("//XCUIElementTypeStaticText[contains(@label,'" + transferMsg + "')]", transferMsg);
            //elementIsDisplayed("//XCUIElementTypeStaticText[contains(@label,'"+transferMsg+"')]", transferMsg);

            String referenceNo = getText("//XCUIElementTypeStaticText[@name='lblAccDetailIBAN']");
            ReportHelper.logReportStatus(LogStatus.PASS, "The fund transfer reference num is" + referenceNo);
            ReportHelper.logReportStatus(LogStatus.PASS, "The Within Meem transfer has done successfully");
            //click("//XCUIElementTypeButton[@label='Go To home'] ", "Go to home");
            //clickBurgerMenu();
            //clickLogout();


        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to perform Within Meem  Transfer" + e.getMessage());
        }


    }


    public static void WithinKSATransfer() {

        try {
            AppiumDriver<MobileElement> driver = getAppiumDriver();
            String beneficaryName = getData("BenficaryName");


            click("//XCUIElementTypeStaticText[@label='Select a beneficiary']", "Select beneficary");
            Thread.sleep(2000);

            click("//XCUIElementTypeTextField[@name='txtSmartSearchBeneficiary']", "");
            sendkeys("//XCUIElementTypeTextField[@name='txtSmartSearchBeneficiary']", beneficaryName);


            click("//XCUIElementTypeStaticText[@label='" + beneficaryName + "']", "Beneficary clicked");
            clear("//*[@name='txtAmount']", "Amount Value");
            sendkeys("//*[@name='txtAmount']", getData("TransferAmount"));
            clickDoneBtn();
            FuncSwipe();
            click("//XCUIElementTypeOther[@name='lstBxPurpose']", "Purpose");

            FuncSwipe();
            // MobileElement element1 = driver.findElement(By.xpath("//XCUIElementTypePickerWheel"));
            //element1.setValue("FAMILY");

            setValue("//XCUIElementTypePickerWheel", Constant.domesticPurpose);
            clickDoneBtn();
            Thread.sleep(2000);


            click("//XCUIElementTypeOther[@name='lstBxSubPurpose']", "Sub Purpose");
            ReportHelper.logReportStatus(LogStatus.PASS, "The sub purpose button clicked");

            setValue("//XCUIElementTypePickerWheel", Constant.domesticSubPurpose);
            clickDoneBtn();
            Thread.sleep(2000);
            MeemKSALogin_Ios.clickContinueBtn();


            elementIsDisplayed("//XCUIElementTypeStaticText[@label='Please review your selection']", Constant.reviewMsg);

            click("//XCUIElementTypeButton[@label='Confirm']", "Confirm");

            Thread.sleep(3000);
            //clickDoneBtn();


            //  MeemKSALogin_Ios.clickContinueBtn();
            //Thread.sleep(3000);

            // System.out.println(driver.getPageSource());
            //successMsgWithinKSA();
            elementIsDisplayed("//XCUIElementTypeStaticText[contains(@label,'" + transferMsg + "')]", transferMsg);

            String referenceNo = getText("//XCUIElementTypeStaticText[@name='lblAccDetailIBAN']");
            ReportHelper.logReportStatus(LogStatus.PASS, "The fund transfer reference num is" + referenceNo);


        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to perform Within Bahrain Transfer" + e.getMessage());

        }
    }


    public static void fawariPlusTransfer() {

        try {
            MeemKSALogin_Ios.MeemKSA_iosLogin();
            MeemKSALogin_Ios.clickBurgerMenu();
            MeemKSALogin_Ios.clickTransferBtn();
            clickWithinKSA();
            String beneficaryName = getData("BenficaryName");
            System.out.println(beneficaryName);


            click("//XCUIElementTypeStaticText[@label='Select a beneficiary']", "Select beneficary");
            Thread.sleep(2000);

            // click("//XCUIElementTypeTextField[@name='txtSmartSearchBeneficiary']", "");
            System.out.println(driver.getPageSource());
            sendkeys("//XCUIElementTypeTextField[@name='txtSmartSearchBeneficiary']", beneficaryName);


            click("//XCUIElementTypeStaticText[@label='" + beneficaryName + "']", "Beneficary clicked");

            click("//XCUIElementTypeButton[@name='btnFawriPlus']", "Fawari Plus ");
            clear("//*[@name='txtAmount']", "Amount Value");
            sendkeys("//*[@name='txtAmount']", getData("TransferAmount"));
            clickDoneBtn();
            FuncSwipe();
            click("//XCUIElementTypeOther[@name='lstBxPurpose']", "Purpose");

            FuncSwipe();
            // MobileElement element1 = driver.findElement(By.xpath("//XCUIElementTypePickerWheel"));
            //element1.setValue("FAMILY");

            setValue("//XCUIElementTypePickerWheel", Constant.domesticPurpose);
            clickDoneBtn();
            Thread.sleep(2000);


            click("//XCUIElementTypeOther[@name='lstBxSubPurpose']", "Sub Purpose");
            ReportHelper.logReportStatus(LogStatus.PASS, "The sub purpose button clicked");

            setValue("//XCUIElementTypePickerWheel", Constant.domesticSubPurpose);
            clickDoneBtn();
            Thread.sleep(2000);
            MeemKSALogin_Ios.clickContinueBtn();


            elementIsDisplayed("//XCUIElementTypeStaticText[@label='Please review your selection']", Constant.reviewMsg);

            MeemKSALogin_Ios.clickContinueBtn();

            Thread.sleep(20000);


            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblSuccessTitle']", transferMsg);


            String referenceNo = getText("//XCUIElementTypeStaticText[@name='lblAccDetailIBAN']");
            ReportHelper.logReportStatus(LogStatus.PASS, "The Fawari Plus fund transfer reference num is" + referenceNo);


        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to perform Within Bahrain Transfer" + e.getMessage());

        }
    }


    public static void fawariTransferInsufficientBal() {

        try {
            String beneficaryName = getData("BenficaryName");


            click("//XCUIElementTypeStaticText[@label='Select a beneficiary']", "Select beneficary");
            Thread.sleep(2000);

            click("//XCUIElementTypeTextField[@name='txtSmartSearchBeneficiary']", "");
            sendkeys("//XCUIElementTypeTextField[@name='txtSmartSearchBeneficiary']", beneficaryName);


            click("//XCUIElementTypeStaticText[@label='" + beneficaryName + "']", "Beneficary clicked");
            clear("//*[@name='txtAmount']", "Amount Value");
            sendkeys("//*[@name='txtAmount']", getData("TransferAmount"));
            clickDoneBtn();
            FuncSwipe();
            click("//XCUIElementTypeOther[@name='lstBxPurpose']", "Purpose");

            FuncSwipe();
            setValue("//XCUIElementTypePickerWheel", Constant.domesticPurpose);
            clickDoneBtn();
            Thread.sleep(2000);


            click("//XCUIElementTypeOther[@name='lstBxSubPurpose']", "Sub Purpose");
            ReportHelper.logReportStatus(LogStatus.PASS, "The sub purpose button clicked");

            setValue("//XCUIElementTypePickerWheel", Constant.domesticSubPurpose);
            clickDoneBtn();
            MeemKSALogin_Ios.clickContinueBtn();
            elementIsDisplayed("//*[@name='lblValidationErr']", "Insufficient balance.");
            ReportHelper.logReportStatus(LogStatus.PASS, "The insufficient balance  validation error has been verified");
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to validate Fawari transfer with Insuffient balance" + e.getMessage());


        }

    }


    public static void successMsgWithinKSA() {
        try {

            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblSuccessTitle']", Constant.successMsg);

        } catch (Exception e) {

            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to review the fawari transfer msg  " + e.getMessage());
        }
    }

    public static void clickAddFavoriteTransfer() {
        try {
            click("//XCUIElementTypeStaticText[@label='Add as Favorite Transfer')", "Add as Favorite Transfer");
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click Add Favorite Transfer" + e.getMessage());
        }
    }

    public static void addFavoriteTransferBtn() {

        try {
            //System.out.println(driver.getPageSource());
            click("//XCUIElementTypeButton[@name='btnCb1']", "Add as Favorite Transfer");
            Thread.sleep(2000);
            //System.out.println(driver.getPageSource());
            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblInfoDesc']", Constant.favouriteMsg);

            click("//XCUIElementTypeButton[@label='OK']", "OK");
            ReportHelper.logReportStatus(LogStatus.PASS, "The Transfer has been added as Favourite transfer");
            click("//XCUIElementTypeButton[@label='Go to home'] ", "Go to home");
            MeemKSALogin_Ios.clickBurgerMenu();
            MeemKSALogin_Ios.clickLogout();
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.PASS, "Unable to add this transaction  as Favourite transfer");
        }

    }


    public static void FavoriteTransfer() {

        MeemBahrainFundTransfer_Ios.International_fundTransfer();

        addFavoriteTransferBtn();
    }


    public static void initiatefavoriteTransfer() {

        try {
            String favoriteTransferValue = getData("BenficaryName");

            MeemKSALogin_Ios.MeemKSA_iosLogin();
            MeemKSALogin_Ios.clickBurgerMenu();
            MeemKSALogin_Ios.clickTransferBtn();
            clickPerformFavoriteTransfer();
            elementIsDisplayed("//*[@label='Favorite Transfers']", "Favorite Transfers");

            click("//*[@label='" + favoriteTransferValue + "']", "Favorite Customer");
            click("//XCUIElementTypeStaticText[@label='Perform']", "Perform");
            Thread.sleep(7000);
            MeemKSALogin_Ios.clickContinueBtn();
            MeemKSALogin_Ios.clickContinueBtn();
            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblSuccessTitle']", transferMsg);


            String referenceNo = getText("//XCUIElementTypeStaticText[@name='lblAccDetailIBAN']");
            ReportHelper.logReportStatus(LogStatus.PASS, "The fund transfer reference num is" + referenceNo);
            click("//XCUIElementTypeButton[@label='Go to home'] ", "Go to home");
            MeemKSALogin_Ios.clickBurgerMenu();
            MeemKSALogin_Ios.clickLogout();
            ReportHelper.logReportStatus(LogStatus.PASS, "Performed Favorite transfer");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to perform Favorite transfer" + e.getMessage());
        }
    }


    public static void deleteFavoriteTransfer() {

        try {
            String favoriteTransferValue = getData("BenficaryName");

            MeemKSALogin_Ios.MeemKSA_iosLogin();
            MeemKSALogin_Ios.clickBurgerMenu();
            MeemKSALogin_Ios.clickTransferBtn();
            clickPerformFavoriteTransfer();
            elementIsDisplayed("//*[@label='Favorite Transfers']", "Favorite Transfers");

            click("//*[@label='" + favoriteTransferValue + "']", "Favorite Customer");
            click("//XCUIElementTypeStaticText[@label='Remove']", "Remove");

            click("//XCUIElementTypeStaticText[@label='Remove from favorites']", "Remove from favorites");
            Thread.sleep(7000);
            click("//XCUIElementTypeButton[@label='Yes']", "Yes");

            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblSuccessTitle']", Constant.favoriteDelMSG);


            click("//XCUIElementTypeButton[@label='Go to Home'] ", "Go to Home");
            MeemKSALogin_Ios.clickBurgerMenu();
            MeemKSALogin_Ios.clickLogout();
            ReportHelper.logReportStatus(LogStatus.PASS, "Deleted Favorite transfer");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to delete Favorite transfer" + e.getMessage());
        }

    }

    //*[@value='Customize Amount']


    public static void emergencyCash() {
        try {
            MeemKSALogin_Ios.MeemKSA_iosLogin();
            MeemKSALogin_Ios.clickBurgerMenu();
            clickEmergencyCash();
            sendkeys("//*[@value='Customize Amount']", getData("TransferAmount"));
            clickDoneBtn();
            clickContinueBtn();
            sendkeys("//XCUIElementTypeSecureTextField[@name='txtPin1']", getData("PIN"));
            clickDoneBtn();
            sendkeys("//XCUIElementTypeSecureTextField[@name='txtPin2']", getData("PIN"));
            clickDoneBtn();
            clickContinueBtn();
            System.out.println(driver.getPageSource());
            elementIsDisplayed("//*[@label='Your PIN will expire in 24h']", Constant.EMERGENCYCASHREVIEWMSG);
            clickConfirmBtn();

            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblSuccessTitle']", Constant.EMERGENCYCASHSuccessMSG);
            String emeregencyRefno = iosGetText("//XCUIElementTypeStaticText[@name='lblRefNo']");
            ReportHelper.logReportStatus(LogStatus.PASS, "The Emeregency Cash reference No is:" + emeregencyRefno.substring(6));

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to initiate  Emergency Cash" + e.getMessage());
        }


    }
}






