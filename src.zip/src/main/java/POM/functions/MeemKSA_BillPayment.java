package POM.functions;

import FrameWork.helpers.ReportHelper;
import FrameWork.library.Constant;
import POM.pageobjects.MeemKSA_login;
import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.commons.lang.RandomStringUtils;

import static FrameWork.helpers.Helper.getData;
import static FrameWork.helpers.ReportHelper.logReportStatusInBlue;
import static FrameWork.library.Util.*;
import static FrameWork.listeners.po_BaseClass.driver;
import static POM.functions.MeemBahrain_StandingInstruction.selectDate;
import static POM.functions.MeemKSALogin_Ios.clickConfirmBtn;
import static POM.functions.MeemKSALogin_Ios.clickContinueBtn;
import static POM.functions.MeemKSALogin_Ios.clickDoneBtn;
import static org.openqa.selenium.support.PageFactory.initElements;

public class MeemKSA_BillPayment {


    public static void initPageObjects() {
        try {
            initElements(new AppiumFieldDecorator(driver), MeemKSA_login.class);
            logReportStatusInBlue(LogStatus.INFO, "Method: " + Thread.currentThread().getStackTrace()[2].getMethodName());
            getAppiumDriver();
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to load Page elemnets");

        }

    }

    public static void addOffline_billPayment() {

        try {
            MeemKSALogin_Ios.MeemKSA_iosLogin();
            MeemKSALogin_Ios.clickBurgerMenu();
            MeemKSALogin_Ios.clickBillPayments();
            Thread.sleep(30000);
            // System.out.println(driver.getPageSource());
            addBillButton();
            Thread.sleep(2000);
            selectBiller();
            offlineBiller();


        } catch (Exception e) {

            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to perform bill payment" + e.getMessage());
        }
    }

    public static void clickStandingInstructions(){
        try{
            click("//XCUIElementTypeStaticText[@label='Standing Instructions'] ", "Standing Instructions");
    }catch (Exception e){

        }
    }


    public static void billPayment_StandingInstructions() {

        try {
            MeemKSALogin_Ios.MeemKSA_iosLogin();
            MeemKSALogin_Ios.clickBurgerMenu();
            MeemKSALogin_Ios.clickBillPayments();
            clickStandingInstructions();

            addBillButton();
            Thread.sleep(2000);
            selectBiller();
            offlineBiller();


        } catch (Exception e) {

            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to perform bill payment" + e.getMessage());
        }
    }

    public static void addOnline_billPayment() {

        try {
            MeemKSALogin_Ios.MeemKSA_iosLogin();
            MeemKSALogin_Ios.clickBurgerMenu();
            MeemKSALogin_Ios.clickBillPayments();

            addBillButton();
            clickGroup();
            click("//XCUIElementTypeTextField[@value='Search for a group']","");
            sendkeys("//XCUIElementTypeTextField[@value='Search for a group']",getData("Group"));
            clickDoneBtn();
            click("//XCUIElementTypeStaticText[contains(@label,'"+getData("Group")+"')]","Group");
            clickBiller();
            sendkeys("//XCUIElementTypeTextField[@value='Search for a biller']",getData("Biller"));
            clickDoneBtn();
            click("//XCUIElementTypeStaticText[contains(@label,'"+getData("Biller")+"')]","Biller");
            clickService();
            sendkeys("//XCUIElementTypeTextField[@value='Search for a service']",getData("Service"));
            clickDoneBtn();
            click("//XCUIElementTypeStaticText[contains(@label,'"+getData("Service")+"')]","Service");
            sendkeys("//XCUIElementTypeTextField[@value='Service Line Number']",getData("TelephoneNumber"));
            clickDoneBtn();
            sendkeys("//XCUIElementTypeTextField[@value='Beneficiary ID']","1002461372");


            clickDoneBtn();
            FuncSwipe1();
            click("//XCUIElementTypeOther[@value='Beneficiary ID Type']","");
            setValue("//XCUIElementTypePickerWheel","National ID");
            clickDoneBtn();
            sendkeys("//XCUIElementTypeTextField[@value='Alias']",getData("NickName"));
            Thread.sleep(2000);
            clickDoneBtn();
            clickContinueBtn();
            Thread.sleep(35000);
            System.out.println(driver.getPageSource());




        } catch (Exception e) {

            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to add Online bill payment" + e.getMessage());
        }
    }

    public static void singleOnlinepayment() {

        try {
            MeemKSALogin_Ios.MeemKSA_iosLogin();
            MeemKSALogin_Ios.clickBurgerMenu();
            MeemKSALogin_Ios.clickBillPayments();
            Thread.sleep(30000);
            clickOnlineBtn();
            clickPayBtn();


        } catch (Exception e) {

            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to add Online bill payment" + e.getMessage());
        }
    }

    public static void singleOffLinepayment() {

        try {
            MeemKSALogin_Ios.MeemKSA_iosLogin();
            MeemKSALogin_Ios.clickBurgerMenu();
            MeemKSALogin_Ios.clickBillPayments();
            Thread.sleep(30000);
            clickOfflineBtn();
            clickPayBtn();


        } catch (Exception e) {

            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to add Online bill payment" + e.getMessage());
        }
    }


    public static void deleteBiller() {

        try {
            MeemKSALogin_Ios.MeemKSA_iosLogin();
            MeemKSALogin_Ios.clickBurgerMenu();
            MeemKSALogin_Ios.clickBillPayments();
            Thread.sleep(30000);
            clickDeleteBtn();


        } catch (Exception e) {

            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to add Online bill payment" + e.getMessage());
        }
    }


    public static void addBillButton() {
        waitForPageToLoad("//XCUIElementTypeButton[@label='T']");

        click("//XCUIElementTypeButton[@label='T']", "Add biller button");
    }

    public static void clickGroup() {
        waitForPageToLoad("//XCUIElementTypeStaticText[@name='lblChevBiller']");

        click("//XCUIElementTypeStaticText[@name='lblChevGroup']", "Select the Group");
    }

    public static void clickBiller() {
        waitForPageToLoad("//XCUIElementTypeStaticText[@name='lblChevBiller']");

        click("//XCUIElementTypeStaticText[@name='lblChevBiller']", "Select the Biller");
    }



    public static void clickService() {
        waitForPageToLoad("//XCUIElementTypeStaticText[@name='lblChevService']");

        click("//XCUIElementTypeStaticText[@name='lblChevService']", "Select the Service");
    }



    public static void selectBiller() {

        try {
            click("//XCUIElementTypeStaticText[@label='Select the biller']", "Select the biller");
            System.out.println(driver.getPageSource());
          //  sendkeys("//XCUIElementTypeTextField[@name='txtSmartSearch']",getData("billerValue"));

            String billerValue = getData("Biller");
            System.out.println(billerValue);
            sendkeys("//XCUIElementTypeTextField[@name='txtSmartSearch']",getData("Biller"));

            click("//XCUIElementTypeStaticText[@value='" + billerValue + "']", billerValue);


            click("//*[@label='Pay Partial']", "Pay Partial");
            System.out.println(driver.getPageSource());
            clear("/XCUIElementTypeTextField[@name='txtAmount']","");
            sendkeys("//XCUIElementTypeTextField[@name='txtAmount']",getData("TransferAmount"));
            FuncSwipe1();
            sendkeys("//XCUIElementTypeTextField[@name='txtCeilingAmount']",getData("TransferAmount"));
            click("//XCUIElementTypeButton[@name='btnMonthly']","Frequency");
            click("//XCUIElementTypeStaticText[@name='txtFromDate']", "");
            //click("//XCUIElementTypeStaticText[@name='lblFromDateChev']","");


            click("//*[@label='" + selectDate() + "']", "Date Selected");
            click("//*[@label='Confirm Date']", "Confirm Date");
            clickContinueBtn();



        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to select Biller in Biller screen" + e.getMessage());
        }
    }


    public static void onlineBiller() {

        try {

            String service = getData("Service");


            click("//*[@value='Choose Service']", "Choose Service");


            setValue("//XCUIElementTypePickerWheel", getData("Service"));

            String batelcoNumber = RandomStringUtils.randomNumeric(8);

            sendkeys("//*[@value='Nickname']", getData("NickName") + RandomStringUtils.randomAlphabetic(1));
            clickDoneBtn();
            sendkeys("//*[@value='BATELCO Subscriber ID']", batelcoNumber);
            clickDoneBtn();
            // sendkeys("//*[@value='TLN - Telephone number']", getData("TelephoneNumber"));
            //MeemKSALogin_Ios.clickDoneBtn();

            System.out.println(driver.getPageSource());

            click("//*[@value='Select ID type']", "ID type");
            setValue("//XCUIElementTypePickerWheel", "CPR - Personal Number");

            sendkeys("//XCUIElementTypeTextField[@value='CPR - Personal Number']", "123456789");
            clickDoneBtn();


            Thread.sleep(5000);
            FuncSwipe();

            click("//*[@value='Select ID type']", "ID type");
            setValue("//XCUIElementTypePickerWheel", "CPR - Personal Number");

            sendkeys("//XCUIElementTypeTextField[@value='CPR - Personal Number']", "123456789");
            clickDoneBtn();


            //   click("//*[@value='Select ID type']", "ID type");
            // setValue("//XCUIElementTypePickerWheel", "CPR - Personal Number");

            //  sendkeys("//XCUIElementTypeTextField[@value='CPR - Personal Number']", "123456789");
            // MeemKSALogin_Ios.clickDoneBtn();
            // sendkeys("//*[@value='Invoice Number']","12345");
            // MeemKSALogin_Ios.clickDoneBtn();
            //sendkeys("//*[@value='Customer Name']", "Arun"+RandomStringUtils.randomAlphabetic(1));
//            MeemKSALogin_Ios.clickDoneBtn();

//            sendkeys("//*[@value='Artist Name']", "Arun"+RandomStringUtils.randomAlphabetic(1));
//            MeemKSALogin_Ios.clickDoneBtn();
//            sendkeys("//*[@value='Hair Stylist Name']", "Bharat"+RandomStringUtils.randomAlphabetic(1));
//            MeemKSALogin_Ios.clickDoneBtn();
            MeemKSALogin_Ios.clickContinueBtn();
            Thread.sleep(20000);
            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblSuccessTitle']", Constant.billermsg);
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to add online biller" + e.getMessage());
        }


    }


    public static void offlineBiller() {

        try {

            String service = getData("Service");

            click("//*[@value='Choose Service']", "Choose Service");


            Thread.sleep(2000);
            System.out.println(driver.getPageSource());
            setValue("//XCUIElementTypePickerWheel", getData("Service"));

            String cprNumber = RandomStringUtils.randomNumeric(9);

            sendkeys("//*[@value='Nickname']", getData("NickName") + RandomStringUtils.randomAlphabetic(1));
            clickDoneBtn();
           /* sendkeys("//*[@value='CPR - Personal Number']",cprNumber);
            MeemKSALogin_Ios.clickDoneBtn();*/
            sendkeys("//*[@value='TLN - Telephone number']", getData("TelephoneNumber"));
            clickDoneBtn();
            sendkeys("//*[@value='Invoice Number']", "12345");
            clickDoneBtn();
            sendkeys("//*[@value='Invoice Number']", "12345");
            clickDoneBtn();
            //sendkeys("//*[@value='Customer Name']", "Arun"+RandomStringUtils.randomAlphabetic(1));
//            MeemKSALogin_Ios.clickDoneBtn();

//            sendkeys("//*[@value='Artist Name']", "Arun"+RandomStringUtils.randomAlphabetic(1));
//            MeemKSALogin_Ios.clickDoneBtn();
//            sendkeys("//*[@value='Hair Stylist Name']", "Bharat"+RandomStringUtils.randomAlphabetic(1));
//            MeemKSALogin_Ios.clickDoneBtn();
            MeemKSALogin_Ios.clickContinueBtn();
            Thread.sleep(20000);
            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblSuccessTitle']", Constant.billermsg);
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to add online biller" + e.getMessage());
        }


    }


    public static void clickOnlineBtn() {

        click("//XCUIElementTypeStaticText[@label='Online']", "Online");
    }

    public static void clickOfflineBtn() {

        click("//XCUIElementTypeStaticText[@label='Offline']", "Offline");
    }


    public static void clickPayBtn() {
        String beneficaryName = getData("BenficaryName");

        click("//XCUIElementTypeStaticText[@label='" + beneficaryName + "']", "Beneficary clicked");

        click("//XCUIElementTypeStaticText[@label='Pay']", "Pay");

        enterAmount();


    }

    public static void clickDeleteBtn() {
        String beneficaryName = getData("BenficaryName");

        click("//XCUIElementTypeStaticText[@label='" + beneficaryName + "']", "Beneficary clicked");

        click("//XCUIElementTypeStaticText[@label='Delete']", "Delete");

        elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblConfirmationDesc']", Constant.deleteMsg);


        click("//XCUIElementTypeButton[@label='Yes']", "Yes");

        ReportHelper.logReportStatus(LogStatus.PASS, "The biller " + beneficaryName + " is deleted");

    }

    public static void enterAmount() {
        try {
            clear("//XCUIElementTypeTextField[@name='0txtPBTextBox']", "Amount");
            sendkeys("//XCUIElementTypeTextField[@name='0txtPBTextBox']", getData("TransferAmount"));
            clickDoneBtn();
            MeemKSALogin_Ios.clickContinueBtn();
            click("//XCUIElementTypeButton[@name='btnContinue']", "Confirm");

            Thread.sleep(3000);
            System.out.println(driver.getPageSource());
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to enter Amount" + e.getMessage());
        }


    }

    public static void multipleOnlineandOffilePayments() {
        try {
            MeemKSALogin_Ios.MeemKSA_iosLogin();
            MeemKSALogin_Ios.clickBurgerMenu();
            MeemKSALogin_Ios.clickBillPayments();
            Thread.sleep(30000);
            String beneficaryNames = getData("BenficaryName");
            String beneficaryName[]=beneficaryNames.split(";");
            click("//XCUIElementTypeStaticText[@label='" + beneficaryName[0] + "']", "Beneficary clicked");

            click("//XCUIElementTypeStaticText[@label='" + beneficaryName[1] + "']", "Beneficary clicked");
            click("//XCUIElementTypeStaticText[@label='Pay']", "Pay");

            clear("//XCUIElementTypeTextField[@name='0txtPBTextBox']","Amount");
            sendkeys("//XCUIElementTypeTextField[@name='0txtPBTextBox']","2");
            clickDoneBtn();
            clear("//XCUIElementTypeTextField[@name='1txtPBTextBox']","Amount");
            sendkeys("//XCUIElementTypeTextField[@name='1txtPBTextBox']",getData("TransferAmount"));
            clickDoneBtn();
            clickContinueBtn();
            clickConfirmBtn();
            Thread.sleep(20000);

            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblSuccessTitle']","Your Bills Status");


            click("//XCUIElementTypeStaticText[@name='segBillsStatus_1_2_lblSelected']","Online Biller");
            String referenceNum=iosGetText("//XCUIElementTypeStaticText[@name='segBillsStatus_1_2_lblDesc']");
            ReportHelper.logReportStatus(LogStatus.PASS,"The reference Num is "+referenceNum.substring(6));
            System.out.println("Online biller validated");
            click("//XCUIElementTypeStaticText[@name='segBillsStatus_1_1_lblSelected']","Offline Biller");
            System.out.println(driver.getPageSource());
            String referenceNum1=iosGetText("//XCUIElementTypeStaticText[@name='segBillsStatus_1_1_segBillsStatus_1_2_lblDesc']");
            ReportHelper.logReportStatus(LogStatus.PASS,"The reference Num is "+referenceNum1.substring(27));
            ReportHelper.logReportStatus(LogStatus.PASS,"The multiple offline and Online bill payments done successfully");







        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to perform Multiple Bill payment" + e.getMessage());
        }


    }
}




