package POM.functions;

import FrameWork.helpers.ReportHelper;
import FrameWork.library.Constant;
import POM.pageobjects.MeemKSA_login;
import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.apache.commons.lang.RandomStringUtils;

import static FrameWork.helpers.Helper.getData;
import static FrameWork.helpers.ReportHelper.logReportStatusInBlue;
import static FrameWork.library.Util.*;
import static FrameWork.listeners.po_BaseClass.driver;
import static org.openqa.selenium.support.PageFactory.initElements;

public class MeemKSALogin_Ios {

    public static void initPageObjects() {
        try {
            initElements(new AppiumFieldDecorator(driver), MeemKSA_login.class);
            logReportStatusInBlue(LogStatus.INFO, "Method: " + Thread.currentThread().getStackTrace()[2].getMethodName());
            getAppiumDriver();
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to load Page elemnets");

        }

    }

    /**
     * This is used for Meem bahrain ios Login
     *
     * @throws Exception
     */


    public static void MeemKSA_iosLogin() {
        try {
            initPageObjects();
            getAppiumDriver();

            waitForPageToLoad("//XCUIElementTypeTextField[@name='txtUsername']");
            clear("//XCUIElementTypeTextField[@name='txtUsername']","");
            System.out.println("Username is "+getData("UserName"));
            sendkeys("//XCUIElementTypeTextField[@name='txtUsername']", getData("UserName"));
            //waitForPageToLoad("//XCUIElementTypeButton[@label='Done'] ");
            clickDoneBtn();
            sendkeys("//XCUIElementTypeSecureTextField[@name='txtPassword']",getData("Password"));
            clickDoneBtn();
            click("//XCUIElementTypeButton[@name='btnLogin']", "Login");
            waitForPageToLoad("//XCUIElementTypeButton[@label='S']");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.PASS, "Unable to login " + e.getMessage());

        }

    }

    public static void invalidLogin() {
        try {
            String userName = "1048795213";
            String password = "erty1234";
            waitForPageToLoad("//XCUIElementTypeTextField[@name='txtUsername']");
            sendkeys("//XCUIElementTypeTextField[@name='txtUsername']", userName);
            clickDoneBtn();
            sendkeys("//XCUIElementTypeSecureTextField[@name='txtPassword']", password);
            clickDoneBtn();
            click("//XCUIElementTypeButton[@name='btnLogin']", "Login");
            Thread.sleep(5000);
            elementIsDisplayed("//*[@name='lblInfoDesc']", Constant.InValidLoginMsg);
            click("//XCUIElementTypeButton[@label='OK']", "OK");
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to validate Invalid Login Message " + e.getMessage());
        }
    }


    public static void MeemKSA_iosLoginValidation() {
        try {
            String userName = "1050587318";
            String password = "abcd1234";
            initPageObjects();
            getAppiumDriver();

            waitForPageToLoad("//XCUIElementTypeTextField[@name='txtUsername']");
            sendkeys("//XCUIElementTypeTextField[@name='txtUsername']", userName);
            clickDoneBtn();
            sendkeys("//XCUIElementTypeSecureTextField[@name='txtPassword']", password);
            clickDoneBtn();
            click("//XCUIElementTypeButton[@name='btnLogin']", "Login");
            Thread.sleep(30000);
            clickBurgerMenu();
            clickLogout();

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to validate login " + e.getMessage());

        }
    }


    public static void InValidOTP() {
        try {
            String userName = "1048795213";
            String password = "abcd1234";
            initPageObjects();
            getAppiumDriver();

            waitForPageToLoad("//XCUIElementTypeTextField[@name='txtUsername']");
            sendkeys("//XCUIElementTypeTextField[@name='txtUsername']", userName);
            //waitForPageToLoad("//XCUIElementTypeButton[@label='Done'] ");
            clickDoneBtn();
            sendkeys("//XCUIElementTypeSecureTextField[@name='txtPassword']", password);
            clickDoneBtn();
            click("//XCUIElementTypeButton[@name='btnLogin']", "Login");
            Thread.sleep(10000);
            enterInvalidConfirmationCode();
            MeemKSALogin_Ios.clickDoneBtn();
            MeemKSALogin_Ios.clickContinueBtn();

            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblVerificationMsg']", Constant.authenticationErrorMsg);
            MeemKSALogin_Ios.clickHomeBtn();


        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.PASS, "Unable to validate login " + e.getMessage());

        }
    }


    public static void clickLogout() {

        try {
            click("//XCUIElementTypeButton[@label='Logout'] ", "Logout");
            //ReportHelper.logReportStatus(LogStatus.PASS, "The Logout button clicked succesfully");
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click Logout button");

        }
    }


    public static void clickDoneBtn() {

        try {
            click("//XCUIElementTypeButton[@label='Done'] ", "Done");
            //ReportHelper.logReportStatus(LogStatus.PASS, "The done button clicked succesfully");
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click done button");

        }
    }

    public static void clickConfirmBtn() {
        try {

            click("//*[@label='Confirm']", "Confirm");
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click Confirm button" + e.getMessage());

        }
    }


    public static void clickHomeBtn() {

        try {
            click("//XCUIElementTypeButton[@label='Go To Home'] ", "Go to Home");
            ReportHelper.logReportStatus(LogStatus.PASS, "The Home button clicked succesfully");
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click Home button");

        }
    }

    public static void enterInvalidConfirmationCode() {

        try {
            String invalidOtp = RandomStringUtils.randomNumeric(4);
            sendkeys("//*[@value='Confirmation Code'] ", invalidOtp);
            ReportHelper.logReportStatus(LogStatus.PASS, "Entered Invalid ");
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click Home button");

        }
    }


    public static void clickContinueBtn() {
        try {
           // waitForPageToLoad("/XCUIElementTypeButton[@label='Continue']");
            click("//*[@label='Continue']", "Continue");
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click Continue button");

        }
    }


    public static void clickBurgerMenu() {

        try {
            click("//XCUIElementTypeButton[@label='S'] ", "Burger menu");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click burger button");
        }
    }

    public static void clickProducts() {

        try {
            click("//XCUIElementTypeStaticText[@label='Products'] ", "Products");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click Products");
        }
    }


    public static void clickEmergencyCash() {

        try {
            click("//XCUIElementTypeStaticText[@name='lblEmergencyCash'] ", "Emergency Cash");

        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click Emergency Cash");
        }
    }

    public static void clickTransferBtn() {
        try {


            click("//XCUIElementTypeStaticText[@label='Transfers'] ", "Transfer button");
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click transfer button");
        }
    }


    public static void clickBeneficiaryBtn() {
        try {

            click("//XCUIElementTypeStaticText[@label='Beneficiary Management'] ", "Beneficiary button");
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click Beneficary button");
        }
    }


    public static void clickBillPayments() {
        try {

            click("//XCUIElementTypeStaticText[@label='Bill Payments'] ", "Bill Payments");
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click Bill Payments button");
        }
    }


    public static void Forgotbutton() {
        try {

            click("//XCUIElementTypeButton[@name='btnForgot'] ", "Forgot");
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to click forgot button");
        }
    }



    public static void UserNameANDPIN() {
        try {
             waitForPageToLoad("//*[@name='txtUsername']");

            sendkeys("//XCUIElementTypeTextField[@name='txtUsername']",getData("UserName"));
            sendkeys("//XCUIElementTypeTextField[@name='txtATMCardNum']",getData("Cardnumber"));
            clickDoneBtn();
           // System.out.println(driver.getPageSource());
            sendkeys("//XCUIElementTypeSecureTextField[@name='txtATMCardPin']",getData("PIN"));
            clickDoneBtn();
            clickContinueBtn();
            Thread.sleep(10000);
            sendkeys("//XCUIElementTypeSecureTextField[@name='txtNewPassword']",getData("Password"));
            clickDoneBtn();
            sendkeys("//XCUIElementTypeSecureTextField[@name='txtReEnterNewPassword']",getData("Password"));
            ReportHelper.logReportStatus(LogStatus.PASS,"The new Password has been entered");
            clickDoneBtn();
            clickContinueBtn();
            waitForPageToLoad("//XCUIElementTypeStaticText[@name='lblClosureTitle']");
            elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblClosureTitle']",Constant.resetPWDSUCESSMSG);
            click("//XCUIElementTypeButton[@name='btnContinue']", "Log in");
            //MeemKSALogin_Ios.MeemKSA_iosLogin();


        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to enter userName and four digit number"+e.getMessage());
        }
    }




    public static void ForgotPassword(){

        try{

            Forgotbutton();
            UserNameANDPIN();
            //clickBurgerMenu();
            //clickLogout();

        }catch(Exception e){
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to update forgot Password "+e.getMessage());
        }
    }





}
