package POM.functions;

import FrameWork.helpers.ReportHelper;
import FrameWork.library.Constant;
import POM.pageobjects.MeemKSA_login;
import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.By;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import static FrameWork.helpers.Helper.getData;
import static FrameWork.helpers.ReportHelper.logReportStatusInBlue;
import static FrameWork.library.Util.*;
import static FrameWork.library.Util.sendkeys;
import static FrameWork.listeners.po_BaseClass.driver;
import static POM.functions.MeemKSALogin_Ios.clickContinueBtn;
import static POM.functions.MeemKSALogin_Ios.clickDoneBtn;
import static org.openqa.selenium.support.PageFactory.initElements;

public class MeemBahrain_StandingInstruction {

    public static void initPageObjects() {
        try {
            initElements(new AppiumFieldDecorator(driver), MeemKSA_login.class);
            logReportStatusInBlue(LogStatus.INFO, "Method: " + Thread.currentThread().getStackTrace()[2].getMethodName());
            getAppiumDriver();
        } catch (Exception e) {
            ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to load Page elemnets");

        }
    }


    public static void StandingInstruction() throws InterruptedException {

        MeemKSALogin_Ios.MeemKSA_iosLogin();
        MeemKSALogin_Ios.clickBurgerMenu();
        MeemKSALogin_Ios.clickTransferBtn();
        MeemBahrainFundTransfer_Ios.clickSetStandingInstruction();
        addStandingInstructionBtn();


    }


    public static void addStandingInstructionBtn() throws InterruptedException {


        click("//XCUIElementTypeButton[@label='T']", "Add button clicked");


        String transferType = getData("TransferType");
        click("//XCUIElementTypeOther[@name='lstBoxStandingOrderType']", "SELECT TyPE OF INSTRUCTION");

        switch (transferType) {

            case "Own Accounts":
                String fromAccountValue = getData("FromAccount");
                System.out.println(fromAccountValue);
                String toAccount = getData("ToAccount");

                setValue("//XCUIElementTypePickerWheel", transferType);
                MeemKSALogin_Ios.clickDoneBtn();
                clickContinueBtn();
                click("//XCUIElementTypeStaticText[@name='lblAccNo']", "fromAccount");
                click("//XCUIElementTypeStaticText[@label='" + fromAccountValue + "']", "fromAccountValue");
                click("//XCUIElementTypeStaticText[@label='Select a account']", "Select Account");
                click("//XCUIElementTypeStaticText[@label='" + toAccount + "']", toAccount);
                System.out.println(driver.getPageSource());

                clear("//XCUIElementTypeTextField[@name='txtAmount']", "Amount value");
                sendkeys("//*[@name='txtAmount']", getData("TransferAmount"));
                MeemKSALogin_Ios.clickDoneBtn();
                FuncSwipe();
                Thread.sleep(4000);
                click("//*[@label='Weekly']", "Select Frequency");
                Thread.sleep(4000);
                click("//XCUIElementTypeStaticText[@name='txtFromDate']", "");
                //click("//XCUIElementTypeStaticText[@name='lblFromDateChev']","");

                //System.out.println(driver.getPageSource());
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd");
                LocalDateTime now = LocalDateTime.now();
                String datavalue = dtf.format(now);
                int tmrwdate = Integer.parseInt(datavalue);
                String tmrwdateValue = String.valueOf(tmrwdate);
                System.out.println(tmrwdate);



                click("//*[@label='" + tmrwdateValue + "']", "Date Selected");


                //setValue("//XCUIElementTypePickerWheel", selectDate());
                click("//*[@label='Confirm Date']", "Confirm Date");
                //MeemKSALogin_Ios.clickDoneBtn();


                //FuncSwipe();
                // sendkeys("//*[@value='Number of Transfers']", getData("NoOf Transfers"));
                //MeemKSALogin_Ios.clickDoneBtn();
                clickContinueBtn();
                click("//XCUIElementTypeButton[@label='Confirm']", "Confirm");
                Thread.sleep(10000);
                System.out.println(driver.getPageSource());
                ReportHelper.logReportStatus(LogStatus.PASS, "Standing instruction Within Own transfer has been created");
                elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblSuccessTitle']", Constant.standInstSuccessMsg);
                ReportHelper.logReportStatus(LogStatus.PASS, "Standing instruction Own  Accounts has been created");

                break;

            case "Within meem":
                try {
                    String beneficaryName = getData("BenficaryName");
                    String fromAccountValue1 = getData("FromAccount");

                    setValue("//XCUIElementTypePickerWheel", transferType);
                    MeemKSALogin_Ios.clickDoneBtn();
                    clickContinueBtn();
                    click("//XCUIElementTypeStaticText[@name='lblAccNo']", "fromAccount");

                    click("//XCUIElementTypeStaticText[@label='" + fromAccountValue1 + "']", "fromAccountValue");
                    Thread.sleep(2000);
                    click("//*[@label='Select a beneficiary']", "Select beneficary");
                    sendkeys("//XCUIElementTypeTextField[@name='txtSmartSearchBeneficiary']", beneficaryName);


                    click("//XCUIElementTypeStaticText[contains(@value,'" + beneficaryName + "')]", "Beneficary clicked");
                    clear("//*[@name='txtAmount']", "Amount Value cleared");
                    Thread.sleep(2000);
                    sendkeys("//*[@name='txtAmount']", getData("TransferAmount"));
                    clickDoneBtn();
                    Thread.sleep(4000);
                    FuncSwipe();
                    click("//*[@value='Select a purpose']", "Purpose");
                    setValue("//XCUIElementTypePickerWheel", "Family");
                    clickDoneBtn();
                    FuncSwipe();
                    click("//XCUIElementTypeOther[@value='Select a subpurpose']", "Purpose");
                    setValue("//XCUIElementTypePickerWheel", "Family support");


                    clickDoneBtn();

                    Thread.sleep(2000);
                    click("//*[@label='Weekly']", "Select Frequency");
                    Thread.sleep(4000);
                    click("//XCUIElementTypeStaticText[@name='txtFromDate']", "");
                    //click("//XCUIElementTypeStaticText[@name='lblFromDateChev']","");

                    DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("dd");
                    LocalDateTime now1 = LocalDateTime.now();
                    String datavalue1 = dtf1.format(now1);
                    int tmrwdate1 = Integer.parseInt(datavalue1);
                    String tmrwdateValue1 = String.valueOf(tmrwdate1);
                    System.out.println(tmrwdate1);

                    click("//*[@label='" + tmrwdateValue1 + "']", "Date Selected");


                    //setValue("//XCUIElementTypePickerWheel", selectDate());
                    click("//*[@label='Confirm Date']", "Confirm Date");
                    clickContinueBtn();
                    click("//XCUIElementTypeButton[@label='Confirm']", "Confirm");
                    elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblSuccessTitle']", Constant.standInstSuccessMsg);

                    ReportHelper.logReportStatus(LogStatus.PASS, "Standing instruction Within Meem has been created");
                } catch (Exception e) {
                    ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to create Standing instruction Within Meem" + e.getMessage());
                }


                break;
            case "Within KSA":
                try {

                    setValue("//XCUIElementTypePickerWheel", transferType);
                    clickDoneBtn();
                    clickContinueBtn();

                    String beneficaryName = getData("BenficaryName");
                    String fromAccountValue1 = getData("FromAccount");

                    //setValue("//XCUIElementTypePickerWheel", transferType);
                    Thread.sleep(3000);


                    click("//XCUIElementTypeStaticText[@name='lblAccNo']", "fromAccount");

                    click("//XCUIElementTypeStaticText[@label='" + fromAccountValue1 + "']", "fromAccountValue");
                    Thread.sleep(2000);
                    click("//*[@label='Select a beneficiary']", "Select beneficary");
                    sendkeys("//XCUIElementTypeTextField[@name='txtSmartSearchBeneficiary']", beneficaryName);
                    click("//XCUIElementTypeStaticText[contains(@value,'" + beneficaryName + "')]", "Beneficary clicked");
                    Thread.sleep(2000);

                    clear("//*[@name='txtAmount']", "Amount Value cleared");
                    Thread.sleep(2000);
                    sendkeys("//*[@name='txtAmount']", getData("TransferAmount"));
                    clickDoneBtn();
                    FuncSwipe1();
                    click("//XCUIElementTypeOther[@name='lstBxPurpose']", "Purpose");
                    setValue("//XCUIElementTypePickerWheel", Constant.domesticPurpose);
                    MeemKSALogin_Ios.clickDoneBtn();
                    Thread.sleep(2000);


                    click("//XCUIElementTypeOther[@name='lstBxSubPurpose']", "Sub Purpose");
                    ReportHelper.logReportStatus(LogStatus.PASS, "The sub purpose button clicked");

                    setValue("//XCUIElementTypePickerWheel", Constant.domesticSubPurpose);
                    MeemKSALogin_Ios.clickDoneBtn();
                    FuncSwipe();

                    Thread.sleep(2000);
                    click("//*[@label='Weekly']", "Select Frequency");
                    Thread.sleep(4000);
                    click("//XCUIElementTypeStaticText[@name='txtFromDate']", "");
                    //click("//XCUIElementTypeStaticText[@name='lblFromDateChev']","");

                    DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("dd");
                    LocalDateTime now1 = LocalDateTime.now();
                    String datavalue1 = dtf1.format(now1);
                    int tmrwdate1 = Integer.parseInt(datavalue1);
                    String tmrwdateValue1 = String.valueOf(tmrwdate1);
                    System.out.println(tmrwdate1);

                    click("//*[@label='" + tmrwdateValue1 + "']", "Date Selected");


                    //setValue("//XCUIElementTypePickerWheel", selectDate());
                    click("//*[@label='Confirm Date']", "Confirm Date");
                    clickContinueBtn();
                    click("//XCUIElementTypeButton[@label='Confirm']", "Confirm");
                    elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblSuccessTitle']", Constant.standInstSuccessMsg);
                    ReportHelper.logReportStatus(LogStatus.PASS, "Standing instruction Within KSA has been created");


                } catch (Exception e) {
                    ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to create Standing instruction Within KSA" + e.getMessage());
                }
                break;
            case "International":

                try {
                    setValue("//XCUIElementTypePickerWheel", transferType);
                    clickDoneBtn();
                    clickContinueBtn();

                    String beneficaryName = getData("BenficaryName");
                    String fromAccountValue1 = getData("FromAccount");
                    Thread.sleep(3000);


                    click("//XCUIElementTypeStaticText[@name='lblAccNo']", "fromAccount");

                    click("//XCUIElementTypeStaticText[@label='" + fromAccountValue1 + "']", "fromAccountValue");
                    Thread.sleep(2000);
                    click("//*[@label='Select a beneficiary']", "Select beneficary");
                    sendkeys("//XCUIElementTypeTextField[@name='txtSmartSearchBeneficiary']", beneficaryName);
                    click("//XCUIElementTypeStaticText[contains(@value,'" + beneficaryName + "')]", "Beneficary clicked");
                    clear("//*[@name='txtAmount']", "Amount Value cleared");
                    Thread.sleep(2000);
                    sendkeys("//*[@name='txtAmount']", getData("TransferAmount"));
                    MeemKSALogin_Ios.clickDoneBtn();
                    FuncSwipe1();
                    click("//XCUIElementTypeOther[@name='lstBxPurpose']", "Purpose");



                    setValue("//XCUIElementTypePickerWheel", Constant.IntPurpose);
                    MeemKSALogin_Ios.clickDoneBtn();
                    Thread.sleep(2000);


                    click("//XCUIElementTypeOther[@name='lstBxSubPurpose']", "Sub Purpose");
                    ReportHelper.logReportStatus(LogStatus.PASS, "The sub purpose button clicked");

                    setValue("//XCUIElementTypePickerWheel", Constant.IntSubPurpose);
                    MeemKSALogin_Ios.clickDoneBtn();

                    click("//*[@label='Weekly']", "Select Frequency");
                    Thread.sleep(4000);
                    click("//XCUIElementTypeStaticText[@name='txtFromDate']", "");
                    //click("//XCUIElementTypeStaticText[@name='lblFromDateChev']","");


                    click("//*[@label='" + selectDate() + "']", "Date Selected");
                    click("//*[@label='Confirm Date']", "Confirm Date");
                    clickContinueBtn();
                    click("//XCUIElementTypeButton[@label='Confirm']", "Confirm");
                    elementIsDisplayed("//XCUIElementTypeStaticText[@name='lblSuccessTitle']", Constant.standInstSuccessMsg);
                    ReportHelper.logReportStatus(LogStatus.PASS, "Standing instruction Within KSA has been created");


                } catch (Exception e) {
                    ReportHelper.logReportStatus(LogStatus.FAIL, "Unable to create Standing instruction International" + e.getMessage());
                }


                break;
        }


    }


    public static String selectDate() {

        Map<String, String> currentWeekMap = new HashMap<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd");

        LocalDate today = LocalDate.now();

        LocalDate newDay = today.plusDays(1);
        String dayOfWeek = newDay.getDayOfWeek().toString();
        String formattedDate = newDay.format(formatter);
        currentWeekMap.put(dayOfWeek, formattedDate);


        String date = currentWeekMap.values().toString().replaceAll("[\\[\\],]", "");

        return date;
    }
}


