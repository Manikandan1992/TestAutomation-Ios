import FrameWork.listeners.PreReq;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class Test {

    public static void main(String[] args) {


        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd");
        LocalDateTime now = LocalDateTime.now();
        String datavalue=dtf.format(now);
        int tmrwdate =Integer.parseInt(datavalue)+1;
        System.out.println(tmrwdate);


    int j=0;

        String names="sahi;Smith";
        String []name=names.split(";");
        System.out.println(name[0]);
        //for(int i=1; i<name.length;i++){
           // System.out.println(name[i]);

        String referenceNo="Ref No 399BPAT183120003".substring(7);
        System.out.println(referenceNo);



        }



    }

